package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.util.CreateFile;
import com.daap.ui.ATD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;

import java.util.ArrayList;
import java.util.List;

/**
 * Complex Class Detection Engine
 * Detects classes that are too large or too complex based on:
 * - Number of methods
 * - Number of fields
 * - Average method length (statements)
 * - Inheritance depth (DIT)
 */
public class ComplexClassDetectionEngine {

    private static final int MAX_METHODS = 20;        // 阈值：方法数上限
    private static final int MAX_FIELDS = 15;         // 阈值：字段数上限
    private static final int MAX_AVG_METHOD_LENGTH = 10; // 阈值：平均方法语句数上限
    private static final int MAX_DIT = 6;             // 继承深度上限（沿用MIM的DIT）

    private static int totalClassesAnalyzed = 0;
    private static int totalComplexClasses = 0;

    public static String smell = "COMPLEX_CLASS";

    public static void reset() {
        totalClassesAnalyzed = 0;
        totalComplexClasses = 0;
    }

    public ComplexClassDetectionEngine() {
    }

    public static void detect() {
        reset();

        ATD.writeMessage("C O M P L E X   C L A S S:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_COMPLEX_CLASS);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        System.out.println("====================== COMPLEX CLASS DETECTION STARTED -------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            totalClassesAnalyzed++;

            int methodCount = legacyClass.getMethodDeclarations().size();
            int fieldCount = legacyClass.getFieldDeclarations().size();
            double avgMethodLength = calculateAverageMethodLength(legacyClass);
            int dit = calculateDIT(legacyClass);

            boolean isComplex = false;

            // 检测标准
            if (methodCount > MAX_METHODS) {
                isComplex = true;
                ATD.writeMessage("Reason: Too many methods (" + methodCount + " > " + MAX_METHODS + ")\n");
            }
            if (fieldCount > MAX_FIELDS) {
                isComplex = true;
                ATD.writeMessage("Reason: Too many fields (" + fieldCount + " > " + MAX_FIELDS + ")\n");
            }
            if (avgMethodLength > MAX_AVG_METHOD_LENGTH) {
                isComplex = true;
                ATD.writeMessage("Reason: High average method length (" + String.format("%.2f", avgMethodLength) + " > " + MAX_AVG_METHOD_LENGTH + ")\n");
            }
            if (dit > MAX_DIT) {
                isComplex = true;
                ATD.writeMessage("Reason: Deep Inheritance Tree (DIT = " + dit + " > " + MAX_DIT + ")\n");
            }

            if (isComplex) {
                totalComplexClasses++;

                ATD.writeMessage("Class Name: " + legacyClass.getName()
                        + "\nPath: " + legacyClass.getPath()
                        + "\nMethods: " + methodCount
                        + ", Fields: " + fieldCount
                        + ", Avg Method Length: " + String.format("%.2f", avgMethodLength)
                        + ", DIT: " + dit
                        + "\n"
                );

                Constants.setHmap(legacyClass.getPath(), Constants.A_COMPLEX_CLASS);

                boolean exists = false;
                for (DetectedInstance di : detectedInstances) {
                    if (di.getName().equals(legacyClass.getName())) {
                        di.increment();
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                }

                // 可选：保存整个类的信息（或保存方法列表）
                try {
                    CreateFile.createFile(legacyClass.toString(), smell, totalComplexClasses + "", true);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                System.out.println("Complex Class Detected: " + legacyClass.getName());
            } else {
                // 非复杂类，记录到“无坏味”列表（可选）
                Constants.Nothing.add(legacyClass.getName());
                Constants.setNo(Constants.A_COMPLEX_CLASS, legacyClass.getName(), "Not complex");
            }
        }

        ATD.writeMessage("Total Complex Classes: " + totalComplexClasses + " / " + totalClassesAnalyzed);
        ATD.detectionDone();

        System.out.println("====================== COMPLEX CLASS DETECTION FINISHED -------------------");

        // 写入结果文档
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

    private static double calculateAverageMethodLength(LegacyClass legacyClass) {
        List<MethodDeclaration> methods = legacyClass.getMethodDeclarations();
        if (methods.isEmpty()) return 0.0;

        int totalStatements = 0;
        int methodCount = 0;

        for (MethodDeclaration method : methods) {
            try {
                if (method.getBody().isPresent()) {
                    int stmtCount = method.getBody().get().getStatements().size();
                    totalStatements += stmtCount;
                    methodCount++;
                }
            } catch (Exception e) {
                // ignore methods with no body or parsing errors
            }
        }

        return methodCount == 0 ? 0.0 : (double) totalStatements / methodCount;
    }

    private static int calculateDIT(LegacyClass legacyClass) {
        int depth = 0;
        LegacyClass current = legacyClass;

        while (current != null && current.getClassOrInterfaceDeclaration().getExtendedTypes().isNonEmpty()) {
            String parentName = current.getClassOrInterfaceDeclaration().getExtendedTypes().get(0).getNameAsString();
            current = findClassByName(parentName);
            if (current == null) break;
            depth++;
            if (depth > 100) break; // 防止无限循环
        }

        return depth;
    }

    private static LegacyClass findClassByName(String name) {
        for (LegacyClass lc : LegacySystem.getInstance().getAllClasses()) {
            if (lc.getName().equals(name)) {
                return lc;
            }
        }
        return null;
    }
}
