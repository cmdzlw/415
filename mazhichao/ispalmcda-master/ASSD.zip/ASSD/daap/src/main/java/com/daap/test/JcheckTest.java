package com.daap.test;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.util.Random;

public class JcheckTest {

    public static void main(String[] args) {
//        private JCheckBox Jcb;

        JFrame jf = new JFrame("测试窗口");
        jf.setSize(250, 250);
        jf.setLocationRelativeTo(null);
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        JPanel panel = new JPanel();

        JCheckBox checkBox01 = new JCheckBox("菠萝");
        JCheckBox checkBox02 = new JCheckBox("香蕉");
        JCheckBox checkBox03 = new JCheckBox("雪梨");
        JCheckBox checkBox04 = new JCheckBox("荔枝");
        JCheckBox checkBox05 = new JCheckBox("橘子");
        JCheckBox checkBox06 = new JCheckBox("苹果");

        checkBox01.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                Random ran=new Random();
                JCheckBox checkBox = (JCheckBox) e.getSource();
//                System.out.println(checkBox.getText() + " 是否选中: " + checkBox.isSelected());
                System.out.println( ((JCheckBox) e.getSource()).getText()+"nnanf");
            }
        });

        checkBox01.setSelected(true);

        panel.add(checkBox01);
        panel.add(checkBox02);
        panel.add(checkBox03);
        panel.add(checkBox04);
        panel.add(checkBox05);
        panel.add(checkBox06);

        jf.setContentPane(panel);
        jf.setVisible(true);
    }

}
