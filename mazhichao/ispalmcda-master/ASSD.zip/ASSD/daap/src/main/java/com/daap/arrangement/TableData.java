package com.daap.arrangement;

import com.daap.util.*;
import javax.swing.event.TableModelListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;
public class TableData  extends AbstractTableModel{
	/*
	 * 这里和刚才一样，定义列名和每个数据的值
	 */
	String[] columnNames = new String[Constants.SLIST.size()+1];
//				{ "ClassName", "MIM", "SFL" };//classname

	Object[][] data = new Object[Constants.HMAP.size()][columnNames.length];

	/**
	 * 构造方法，初始化二维数组data对应的数据
	 */
	public TableData()
	{
		int xi=1;
		columnNames[0]="Class";
		for(String s:Constants.SLIST){
			columnNames[xi++]=s;
		}

		//设置ClassName
		Object sn[] =  Constants.HMAP.keySet().toArray();
		for(int i=0;i<getRowCount();i++){
			data[i][0]= sn[i];
		}
		//设置每种坏味道的次数
		for(int i=0;i<getRowCount();i++){
			for(int j=1;j<getColumnCount();j++) {
				if(Constants.HMAP.get((String) data[i][0]).containsKey(columnNames[j]))//存在当前坏味道
					data[i][j] = Constants.HMAP.get((String) data[i][0]).get(columnNames[j]).toString();
				else
					data[i][j] = 0;
			}
		}
	}
	/**
	 * 得到列名
	 */
	@Override
	public String getColumnName(int column)
	{
		return columnNames[column];
	}

	/**
	 * 重写方法，得到表格列数
	 */
	@Override
	public int getColumnCount()
	{
		return columnNames.length;
	}

	/**
	 * 得到表格行数
	 */
	@Override
	public int getRowCount()
	{
		return data.length;
	}

	/**
	 * 得到数据所对应对象
	 */
	@Override
	public Object getValueAt(int rowIndex, int columnIndex)
	{
		return data[rowIndex][columnIndex];
	}

	/**
	 * 得到指定列的数据类型
	 */
	@Override
	public Class<?> getColumnClass(int columnIndex)
	{
		return data[0][columnIndex].getClass();
	}

	/**
	 * 指定设置数据单元是否可编辑.这里设置"姓名","学号"不可编辑
	 */
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex)
	{
		if (columnIndex < 2)
			return false;
		else
			return true;
	}

	/**
	 * 如果数据单元为可编辑，则将编辑后的值替换原来的值
	 */
	@Override
	public void setValueAt(Object aValue, int rowIndex, int columnIndex)
	{
		data[rowIndex][columnIndex] = aValue;
		/*通知监听器数据单元数据已经改变*/
//			fireTableCellUpdated(rowIndex, columnIndex);
	}

}
