package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.util.CreateFile;
import com.daap.ui.ATD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;

import java.util.ArrayList;
import java.util.List;

/**
 * Long Method 异味检测引擎
 * 判断标准：方法体语句数超过阈值（默认 30）
 */
public class LongMethodDetectionEngine {

    private static final int STATEMENT_THRESHOLD = 30; // 可配置

    private static int totalLongMethods = 0;
    private static int totalMethods = 0;

    public static String smell = "LONG_METHOD";

    public static void reset() {
        totalLongMethods = 0;
        totalMethods = 0;
    }

    public LongMethodDetectionEngine() {
    }

    public static void detect() {
        reset();

        ATD.writeMessage("L O N G   M E T H O D:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_LONG_METHOD);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        System.out.println("======================STARTED - Long Method Detection-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
                totalMethods++;

                // 跳过空方法（可选）
                if (isNullMethod(methodDeclaration)) {
                    continue;
                }

                // 获取语句列表
                List<Statement> statements = getStatements(methodDeclaration);
                int statementCount = statements != null ? statements.size() : 0;

                // 判断是否为 Long Method
                if (statementCount > STATEMENT_THRESHOLD) {
                    totalLongMethods++;

                    ATD.writeMessage("Class Name: " + legacyClass.getName() +
                            "\nPath: " + legacyClass.getPath() +
                            "\nMethod: " + methodDeclaration.getNameAsString() +
                            "\nStatement Count: " + statementCount + "\n");

                    Constants.setHmap(legacyClass.getPath(), Constants.A_LONG_METHOD);
                    Constants.setSmell(Constants.A_LONG_METHOD, legacyClass.getPath(), methodDeclaration.clone().toString());

                    // 记录检测实例
                    boolean exists = false;
                    for (DetectedInstance di : detectedInstances) {
                        if (di.getName().equals(legacyClass.getName())) {
                            di.increment();
                            exists = true;
                            break;
                        }
                    }
                    if (!exists) {
                        detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                    }

                    System.out.println("Long Method Detected in: " + legacyClass.getName() + " -> " + methodDeclaration.getNameAsString());
                    System.out.println("Statement Count: " + statementCount);

                    // 输出到文件
                    try {
                        CreateFile.createFile(methodDeclaration.clone().toString(), smell, totalLongMethods + "", true);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    // 非异味方法记录（可选）
                    try {
                        CreateFile.createFile(methodDeclaration.clone().toString(), smell, totalMethods + "", false);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    Constants.Nothing.add(methodDeclaration.clone().toString());
                    Constants.setNo(Constants.A_LONG_METHOD, legacyClass.getName(), methodDeclaration.clone().toString());
                }
            }
        }

        ATD.writeMessage("Total Long Methods Detected: " + totalLongMethods);
        ATD.writeMessage("Total Methods Analyzed: " + totalMethods);
        ATD.detectionDone();

        System.out.println("======================FINISHED - Long Method Detection-------------------");

        // 写入报告
        int srNo = 1;
        for (DetectedInstance di : detectedInstances) {
            Helper.writeDoc(resultDocument, di, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

    private static boolean isNullMethod(MethodDeclaration methodDeclaration) {
        try {
            return methodDeclaration.getBody().get().getStatements().isEmpty();
        } catch (Exception e) {
            return true; // 无 body 视为空方法
        }
    }

    private static List<Statement> getStatements(MethodDeclaration methodDeclaration) {
        try {
            return methodDeclaration.getBody().get().getStatements();
        } catch (Exception e) {
            return new ArrayList<>();
        }
    }
}