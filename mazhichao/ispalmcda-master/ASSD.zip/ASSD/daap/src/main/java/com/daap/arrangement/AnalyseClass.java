package com.daap.arrangement;

import com.daap.ui.ATD;
import com.daap.util.Constants;

import java.util.HashMap;

public class AnalyseClass {
    public static void xchange(){
        Object bf[] = Constants.HMAP.keySet().toArray();//获得路径
        String af[] = new String[bf.length];//
        {//转换
            for (int i=0;i< bf.length;i++) {
                if((bf[i].toString()).contains("/app/src/test/java/")||(bf[i].toString()).contains("/app/src/androidTest/java/")) {
                    Constants.HMAP.remove(bf[i].toString());
                    af[i]="";
                    continue;
                }
                StringBuffer sb = new StringBuffer(bf[i].toString());

                int index1 = sb.indexOf("/app/src/main/java/");
                int index2 = sb.indexOf("/app/src/main/java/") + 19;
                if(index1 > 0 && index1 < sb.length() - 1 && index2 > 0 && index2 < sb.length()){
                    sb.delete(sb.indexOf("/app/src/main/java/"), sb.indexOf("/app/src/main/java/") + 19);
                }
                int index3 = sb.lastIndexOf(".java");
                int index4 = sb.lastIndexOf(".java") + 5;
                if(index3 > 0 && index3 < sb.length() - 1 && index4 > 0 && index4 < sb.length()){
                    sb.delete(sb.lastIndexOf(".java"), sb.lastIndexOf(".java") + 5);
                }
                String sx = sb.toString().replace("/", ".");
                af[i] = sx;


            }
        }

        for(int i=0;i<bf.length;i++){
            if(Constants.HMAP.containsKey(bf[i].toString())) {
                HashMap<String, Integer> hm = Constants.HMAP.get(bf[i].toString());
                Constants.HMAP.remove(bf[i].toString());
                Constants.HMAP.put(af[i], hm);
            }
        }
    }

    public static void Analyse(){//筛选所选坏味道共存的类
        ATD.clearConsole();
        Object allClass[]= Constants.HMAP.keySet().toArray();
        boolean consoleISEmpty=true,allSmell;
        ATD.writeMessage("Class:");
        for(Object ac:allClass){//每个类
            allSmell=true;
            for(String s:Constants.SLIST) {//当前类的每个坏味道都存在
                if (!Constants.HMAP.get(ac).containsKey(s)){//进入此处就表示当前类不是包含所有类的了
                    allSmell=false;
                }
            }
            if(allSmell) {
                ATD.writeMessage(ac.toString());
                consoleISEmpty=false;
            }
        }
        if (consoleISEmpty){
            ATD.clearConsole();
            ATD.writeMessage("NO SUCH CLASS !Look at the pop-up window");
        }
    }


}
