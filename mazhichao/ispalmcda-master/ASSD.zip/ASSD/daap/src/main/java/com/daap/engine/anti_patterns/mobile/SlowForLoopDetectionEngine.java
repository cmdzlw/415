package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ATD;
import com.daap.util.CreateFile;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.ForeachStmt;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import javax.xml.transform.sax.SAXTransformerFactory;
import java.util.*;

/**
 * Created by Azhar on 9/21/2017.
 */
public class SlowForLoopDetectionEngine {

    private static int total = 0;
    private static boolean isSFL = false;
    private static int ISSFL = 0;
    private static int NOTSFL = 0;
    public static String smell = "SFL";


    public static void reset(){
        total = 0;
        isSFL = false;
        ISSFL = 0;
        NOTSFL = 0;
    }


    public static void detect() {
        reset();
//        XWPFDocument doc;
//        XWPFTable table;
//        doc = new XWPFDocument();
//        table = doc.createTable();
//        table.getRow(0).getCell(0).setText("Sr. No");
//        table.getRow(0).createCell().setText("Class");
////        table.getRow(0).createCell().setText("Method");
//        table.getRow(0).createCell().setText("Path");

        total = 0;
//        ASD.clearConsole();
        ATD.writeMessage("Slow For Loop:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_SLOW_FOR_LOOP);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();
        System.out.println("======================STARTED-------------------");

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {

            ArrayList<ForStmt> forStmts = new ArrayList<>();
            legacyClass.getClassOrInterfaceDeclaration().accept(new VoidVisitorAdapter<Object>() {



                @Override
                public void visit(ForeachStmt foreachStmt, Object arg) {
                    super.visit(foreachStmt, arg);
                    isSFL = false;
                    try {
                        CreateFile.createFile(foreachStmt.clone().toString(),smell,NOTSFL+"",isSFL);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    NOTSFL++;

                    Constants.Nothing.add(foreachStmt.clone().toString());

                    Constants.setNo(Constants.A_SLOW_FOR_LOOP,legacyClass.getName(),foreachStmt.clone().toString());
                }

                @Override
                public void visit(ForStmt forStmt, Object javaParserFacade) {
                    super.visit(forStmt, javaParserFacade);
                    if(judge(forStmt)){

                        isSFL = true;
                        try {
                            CreateFile.createFile(forStmt.clone().toString(),smell,ISSFL+"",isSFL);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        ISSFL++;

                        System.out.println(forStmt);

                        forStmts.add(forStmt);
                        total++;
                        //                    ASD.writeMessage("Class: " + legacyClass.getName());
                        ATD.writeMessage("Class Name: " + legacyClass.getName()//通过此寻找
                                + "\nPath: " + legacyClass.getPath() + "\n"
                        );

                        //问题1
                        //                    Constants.CNAME.add(legacyClass.getName());

                        //                    Constants.setHmap(legacyClass.getName(),Constants.A_SLOW_FOR_LOOP);

                        Constants.setHmap(legacyClass.getPath(),Constants.A_SLOW_FOR_LOOP);

                        Constants.setSmell(Constants.A_SLOW_FOR_LOOP,legacyClass.getPath(),forStmt.clone().toString());


                        //                    Helper.writeDoc(table, legacyClass, total);
                        //                    Constants.HMAPI["A_SLOW_FOR_LOOP"]
                        System.out.println("legacyClass: " + legacyClass.getName() + " has traditional slower for loops");
                        boolean exists = true;
                        for (DetectedInstance detectedInstance: detectedInstances){
                            if (detectedInstance.getName().equals(legacyClass.getName())){
                                detectedInstance.increment();
                                exists = false;
                                break;
                            }
                        }
                        if (exists){
                            detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                        }


                    }else{

                        isSFL = false;
                        try {
                            CreateFile.createFile(forStmt.clone().toString(),smell,NOTSFL+"",isSFL);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        NOTSFL++;

                        Constants.Nothing.add(forStmts.clone().toString());

                        Constants.setNo(Constants.A_SLOW_FOR_LOOP,legacyClass.getName(),forStmt.clone().toString());

                    }
                }
            }, null);

//            if (!forStmts.isEmpty()) {
//                total++;
//                ASD.writeMessage("Class: " + legacyClass.getName());
//                System.out.println("legacyClass: " + legacyClass.getName() + " has traditional slower for loops");
//            }
        }

        System.out.println("total: " + total);
        ATD.writeMessage("Total: "+total);
        ATD.detectionDone();
//        Helper.writeFile(doc, "SlowForLoop");
        System.out.println("======================FINISHED-------------------");
        int srNo = 1;
        for (DetectedInstance detectedInstance : detectedInstances) {
            Helper.writeDoc(resultDocument, detectedInstance, srNo++);
        }
        Helper.writeFile(resultDocument);



    }

    /**
     *  判断这个普通for循环，能不能改成for-each，如果能，那才真的算slf的异味，不然就不算
     *
     * @param forStmt
     * @return
     */
    public static boolean judge(ForStmt forStmt){

        //被操作的数组或集合，必须是完整的遍历完的，从下标=0 自增到 length ，如果是从后往前那也算不行
        //下标自增必须一个一个增，也就是++，而且必须从0开始
        //分两种情况： 一个是从0到<= length - 1, 一个是到 < length,如果是-其他数也不行

        if(forStmt.getCompare().isPresent()){
            //获取操作的数组或集合  以及 下标
            List<Node> childNodes = forStmt.getCompare().get().getChildNodes();
            Node value = null,arr = null;
            if(childNodes.size() == 2){
                value = childNodes.get(0);  // 下标变量
                arr = childNodes.get(1);   // 数组或集合, 可如果这个也就是一个计数变量 例如j，那也算不行吧，因为无法判断这个究竟是多大
            }else{
                return false;   //如果判断条件多于两个 那可能就有跟本数组或集合不相关的
            }

            //判断下标必须从0开始 且为 ++
            NodeList<Expression> initialization = forStmt.getInitialization();
            NodeList<Expression> update = forStmt.getUpdate();  //这个是一个++算一个元素
            if(initialization.size() > 0) {
                if (!initialization.get(0).toString().replaceAll(" ", "").contains(value + "=0")) {
                    return false; //如果不存在下标变量=0   之所以只get(0)，是因为好像他里面全部都当做一个整体放在0
                }
            }else{
                return false;
            }

            boolean flag_update = false;
            for(int i = 0; i < update.size(); i++){
                if(update.get(i).toString().equals(value+"++") || update.get(i).toString().equals("++"+value)){
                    flag_update = true;
                    break;
                }
            }
            if(!flag_update){
                return false;
            }
            //---------------------------------

            //判断循环判断的必须为 <= length - 1 或者 < length, 即遍历整个
            String arr_list = (arr.toString().replaceAll(" ",""));
            String compare = forStmt.getCompare().get().toString().replaceAll(" ","");
            if(arr_list.contains("-1")){
                if(!compare.contains("<=")){
                    return false;
                }
            }else{ //不包含 -1，就是没有length - 1，所以只要 <
                //可是如果是 -其他的数也不行
                if(arr_list.contains("-")){   //既然没有-1，那就不应该有减号，否则就是减去了其他数
                    return false;
                }

                if(!compare.contains("<")){
                    return false;
                }
            }

            String set = "";
            //--------------------------------
            //如果循环体中存在 .remove  .add  ,集合的长度就是size()
            String body = forStmt.getBody().toString();
            if(arr.toString().contains(".size()")){
                String list = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                set = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                String compare_add = list+".add";
                String compare_put = list+".put";
                String compare_remove = list+".remove";
                String compare_clear = list+".clear";
                if(body.contains(compare_add) || body.contains(compare_put) || body.contains(compare_remove) || body.contains(compare_clear)){
                    return false;
                }

                //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
                //此处也需要用循环进行判断全部！

            }else{
                if(!arr.toString().contains(".length")){
                    return false;
                }
                set = arr.toString().substring(0,arr.toString().indexOf(".length"));
            }

            //不可以存在使用下标charAt
            if(body.contains(set+".charAt")){
                return false;
            }

            //不可以存在return i;   算使用了下标
            if(!judge_return_index(new StringBuilder(body),"return",value.toString())){
                return false;
            }

            //----------------------------------------
            //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
            //此方法和下面查找 if ( 下标一样，不断以新的起点寻找indexOf（变量）和indexOf(=),看是否有赋值操作
            StringBuilder body3 = new StringBuilder(body);
            int count3 = 0;
            while (count3 < body3.length()){
                String body3_string = body3.toString();
                if(body3_string.contains(set) && body3_string.contains("=")){
//                         && body.indexOf(list) < body.indexOf("=")
                    int index_list = body3_string.indexOf(set,count3);
                    if(index_list + 1 > body3_string.length() - 1){
                        break;
                    }
                    int index_deng = body3_string.indexOf("=",index_list + 1);
                    if(index_deng != -1){
                        if(index_deng - index_list <= set.length() + 5){
                            //防止误判
                            if(judge_frBe(index_list,set.toString().length(),body3_string)){
                                return false;
                            }
                        }
                    }
                    count3 = index_list + 2;
                    if(count3 > body3_string.length() - 1){
                        break;
                    }
                    body3 = new StringBuilder(body3_string.substring(count3));
                    count3 = 0;
                }else{
                    break;
                }
            }

//            List<Character> judge_value = new ArrayList<>();

            //-----------------------------------------
            //如果存在对下标的if判断
            StringBuilder body2 = new StringBuilder(body);
            int count = 0;
            while(count < body2.length()){
                String body2_string = body2.toString();
                if(body2_string.contains("if") && body2_string.contains(value.toString())){
                    int index_if = body2_string.indexOf("if",count);
                    if(index_if + 1 > body2_string.length() - 1){
                        break;
                    }
                    int index_value = body2_string.indexOf(value.toString(),index_if + 1);
                    if(index_value - index_if <= 6){
                        //防止误判
                        if(judge_frBe(index_if,2,body2_string)){
                            if(judge_frBe(index_value,value.toString().length(),body2_string)){
                                return false;
                            }
                        }
                    }
                    count = index_if + 1;
                    if(count > body2_string.length() - 1){
                        break;
                    }
                    body2 = new StringBuilder(body2_string.substring(count));
                    count = 0;
                }else{
                    break;
                }
            }

            //------------------------
            //对 = 下标 进行判断
//            judge_index(body,value.toString(),"=");
            StringBuilder body4 = new StringBuilder(body);
            int count4 = 0;
            while(count4 < body4.length()){
                String body4_string = body4.toString();
                if(body4_string.contains("=") && body4_string.contains(value.toString())){
                    int index_deng = body4_string.indexOf("=",count4);
                    if(index_deng + 1 > body4_string.length() - 1){
                        break;
                    }
                    int index_value = body4_string.indexOf(value.toString(),index_deng + 1);

                    if(index_value - index_deng <= 3){
                        //防止出现 itent = 这种情况 n是下标，但itent不是，但一样算定位到n了
                        if(judge_frBe(index_value,value.toString().length(),body4_string)){
                            return false;
                        }
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 >= 0){
//                            front = body4_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body4_string.length()){
//                            behind = body4_string.charAt(index_value + value.toString().length());
//                        }
//                        if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
//                            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                                return false;
//                            }
//                        }
                    }
                    count4 = index_deng + 1;

                    if(count4 > body4_string.length() - 1){
                        break;
                    }
                    body4 = new StringBuilder(body4_string.substring(count4));
                    count4 = 0;
                }else{
                    break;
                }
            }

            //对 下标 = 进行判断
//            judge_index(body,"=",value.toString());
            StringBuilder body5 = new StringBuilder(body);
            int count5 = 0;
            while(count5 < body5.length()){
                String body5_string = body5.toString();
                if(body5_string.contains("=") && body5_string.contains(value.toString())){
                    int index_value = body5_string.indexOf(value.toString(),count5);
                    if(index_value + 1 > body5_string.length() - 1){
                        break;
                    }
                    int index_deng = body5_string.indexOf("=",index_value + 1);
                    if(index_deng - index_value <= 3) {
                        if(judge_frBe(index_value,value.toString().length(),body5_string)){
                            return false;
                        }
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 > 0){
//                            front = body5_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body5_string.length()){
//                            behind = body5_string.charAt(index_value + value.toString().length());
//                        }
//                        if (!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))) {
//                            if (!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')) {
//                                return false;
//                            }
//                        }
                    }
                    count5 = index_value + 1;

                    if(count5 > body5_string.length() - 1){
                        break;
                    }
                    body5 = new StringBuilder(body5_string.substring(count5));
                    count5 = 0;
                }else{
                    break;
                }
            }

            //对下标被非本次循环遍历的数组或集合使用，也是不行的
            StringBuilder body6 = new StringBuilder(body);
            int count6 = 0;
            while(count6 < body6.length()){
                String body6_string = body6.toString();
                if(body6_string.contains("["+value.toString()+"]") ){
                    int index_value = body6_string.indexOf("["+ value +"]",count6);

                    if(index_value - set.length() > 0){//防止下标跑出合理范围
                        if(!body6_string.substring(index_value - set.length(),index_value).equals(set)){
                            return false;
                        }
                    }else{
                        return false;
                    }
                    count6 = index_value + 2;

                    if(count6 > body6_string.length() - 1){
                        break;
                    }
                    body6 = new StringBuilder(body6_string.substring(count6));
                    count6 = 0;
                }else{
                    break;
                }
            }



//            for(int index = 0; index < body2.length(); index++){
//                if(body2.contains("if") && body.contains(value.toString())){
//                    if(body.indexOf("if") - body.indexOf(value.toString()) <= 3){
//                        return false;
//                    }
//                }
//
//            }

//            if(body.contains("continue")){
//                return false;
//            }




        }else{
            return false;
        }

        return true;
    }

    /*
        传入参数：方法体  需要判断的在前面的变量re  在后面的变量index
        作用：判断在方法体中是否存在  re index
        例如不可以存在 return 循环下标
        不可以        if(循环下标)
        不可以        = 循环下标
        不可以        循环下标 =
     */
    public static boolean judge_return_index(StringBuilder sb,String re,String index){
        int count = 0;
        while(count < sb.length()){
            String body = sb.toString();
            if(body.contains(re) && body.contains(index)){
                int index_re = body.indexOf(re,count);
                //判断真的是完整的这俩 不能是其他的 例如 areturnb 这样也会找到return
//                char front = body.charAt(index_re - 1);
//                char behind = body.charAt(index_re + re.length());
//                if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
//                    if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                        int index_in = body.indexOf(index,index_re + re.length());
//                    }
//                }
                if(judge_frBe(index_re,re.length(),body)){
                    int index_in = body.indexOf(index,index_re + re.length());
                    if(judge_frBe(index_in,index.length(),body)){
                        if(index_in - index_re < re.length() + 3){
                            return false;
                        }
                    }
                }
                count = index_re + 1;
                if(count > sb.length() - 1){
                    break;
                }
                sb = new StringBuilder(sb.substring(count));
                count = 0;
            }else{
                break;
            }
        }
        return true;
    }

    /**
     * 传入三个参数：要判断的值的在body中的下标，判断值的长度，body
     *       作用：判断找到的该值是否是真正的该值，例如找i，不能是找到了 aib
     * @param value_index  下标
     * @param value_length  长度
     * @param body
     * @return
     */
    public static boolean judge_frBe(int value_index,int value_length,String body){
        if(value_index - 1 < 0 || value_index + value_length > body.length() - 1){
            return true;
        }
        char front = body.charAt(value_index - 1);
        char behind = body.charAt(value_index + value_length);
        if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
                return true;
            }
        }
        return false;
    }

//    //             对 = 下标   和 下标 =            index            =
//    public static boolean judge_index(String body,String value1,String value2){
//        StringBuilder body4 = new StringBuilder(body);
//        int count4 = 0;
//        while(count4 < body4.length()){
//            String body4_string = body4.toString();
//            if(body4_string.contains(value2) && body4_string.contains(value1)){
//                int index_deng = body4_string.indexOf(value2,count4);
//                if(index_deng + 1 > body4_string.length() - 1){
//                    break;
//                }
//                int index_value = body4_string.indexOf(value1,index_deng + 1);
//
//                if(index_value - index_deng <= 3){
//                    //防止出现 itent = 这种情况 n是下标，但itent不是，但一样算定位到n了
//                    char front = ' ';
//                    char behind = ' ';
//                    if(index_value - 1 >= 0){
//                        front = body4_string.charAt(index_value - 1);
//                    }
//                    if(index_value + value1.length() < body4_string.length()){
//                        behind = body4_string.charAt(index_value + value1.length());
//                    }
//                    if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
//                        if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                            return false;
//                        }
//                    }
//                }
//                count4 = index_deng + 1;
//
//                if(count4 > body4_string.length() - 1){
//                    break;
//                }
//                body4 = new StringBuilder(body4_string.substring(count4));
//                count4 = 0;
//            }else{
//                break;
//            }
//        }
//        return true;
//    }

}
