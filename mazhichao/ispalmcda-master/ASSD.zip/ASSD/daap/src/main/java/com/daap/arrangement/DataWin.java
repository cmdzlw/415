package com.daap.arrangement;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;

public class DataWin extends JFrame
{

	public DataWin()
	{
		try {//Nimbus
			for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
				if ("Motif".equals(info.getName())) {
					UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		intiComponent();
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}

	private void intiComponent()
	{
		JTable table = new JTable(new TableData());
		DefaultTableCellRenderer r1 = new DefaultTableCellRenderer();
		r1.setHorizontalAlignment(JLabel.CENTER);
		table.setDefaultRenderer(Object.class, r1);
		/* 用JScrollPane装载JTable，这样超出范围的列就可以通过滚动条来查看 */
		JScrollPane scroll = new JScrollPane(table);
		add(scroll);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.pack();
	}



	public static void main(String[] args)
	{
		new DataWin();
	}
}