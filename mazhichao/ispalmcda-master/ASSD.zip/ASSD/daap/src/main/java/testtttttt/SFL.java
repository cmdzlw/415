package testtttttt;

import com.daap.util.DirExplorer;
import com.github.javaparser.JavaParser;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.util.*;

/**
 * @author ZHUWEI
 * @Description
 * @create 2022-04-09-22:21
 */
public class SFL {
    public static List<Node> forStmts;
    public static void main(String[] args) {
        File projectDir = new File("D:\\IdeaProjects\\ImageViewer\\src\\TestSFL\\test");
        //File projectDir = new File("E:\\WANGJINXIN");
        forStmts = new ArrayList<>();
        listSFL(projectDir);
//        Map<String,Integer> map = null;
//        List<Integer> values = (List<Integer>) map.values();
//        Collections.sort(values,(a,b) -> b-a);
//        Set<Map.Entry<String, Integer>> entries = map.entrySet();
//        for(Map.Entry<String,Integer> entry : entries){
//            entry.getKey();
//            entry.getValue();
//        }
//        for(int i = 0; i < values.size(); i++){
//            Integer integer = values.get(i);
//        }
//        String s = "123";
//        map.put(s,map.getOrDefault(s,0) + 1);
//        Collection<Integer> values1 = map.values();
////        StringBuilder sb;
////        sb.toString();
////        map.getOrDefault();
////        sb.delete();
////        sb.length();
//        List l;
//        Set s;
//        Map a;
//        a.
    }
    public static void find(File projectDir){

    }

    public static void listSFL(File projectDir) {
        new DirExplorer((level, path, file) -> path.endsWith(".java"), (level, path, file) -> {
//            System.out.println(path);
//            System.out.println("=============");
            try {
                new VoidVisitorAdapter<Object>() {

//                    @Override
//                    public void visit(ForStmt n, Object arg) {
//                        super.visit(n, arg);
////                        System.out.println(n);//直接输出n，得到传统for循环的整个方法体,增强for循环不会扫描到
////                        System.out.println(n.getInitialization()); //for()里面的初始化
////                        System.out.println(n.getCompare().toString());//for()里面的判断循环条件
////                        System.out.println(n.getUpdate());//for()里面的更新操作
////                        System.out.println(n.);
//                        System.out.println();
//
//                        System.out.println("SFLSFLSFLSFLSFLSFLSFL");

//                    }

                    public void visit(ClassOrInterfaceDeclaration n,Object arg){
                        super.visit(n,arg);
                        System.out.println();
                        n.accept(new VoidVisitorAdapter<Object>() {

//                            @Override
//                            public void visit(MethodCallExpr n, Object arg) {
//                                super.visit(n, arg);
//
//                            }

//                            @Override
//                            public void visit(MethodDeclaration n, Object arg) {
//                                super.visit(n, arg);
//                                n.containsWithin()
//                            }

                            @Override
                            public void visit(ForStmt forStmt,Object args) {
                                super.visit(forStmt, args);
//                                System.out.println(forStmt.getCompare().get().getChildNodes());
//                                System.out.println(forStmt.getCompare().get().toString().replaceAll(" ",""));
//                                System.out.println(forStmt.getCompare().get().getChildNodes().get(1).toString().replaceAll(" ",""));


//                                System.out.println(forStmt.getInitialization());
//                                    System.out.println(forStmt.getCompare().get().getChildNodes());
//                                    System.out.println(forStmt.getBody());
//                                System.out.println(forStmt.getBody().getChildNodes().get(1));
//                                if(forStmt.getInitialization().size() > 0)
//                                    System.out.println(forStmt.getInitialization().get(0));
//                                System.out.println(forStmt.getCompare().get().getChildNodes());
//                                System.out.println(forStmt);
                                if(judge(forStmt)){
                                    System.out.println(forStmt);
                                }

//                                System.out.println(forStmt.getInitialization().get(0).toString().replaceAll(" ",""));
//                                System.out.println(forStmt.getInitialization().get(0));
//                                System.out.println(forStmt.getUpdate().get(0));


//                                NodeList<Expression> update = forStmt.getUpdate();
//                                for(int i = 0; i < update.size(); i++){
//                                    System.out.println(update.get(i));
//                                }

//                                System.out.println(forStmt);


//                                System.out.println(n.getName() + ":");
//                                System.out.println(forStmt.getInitialization()); //必须为=0
//                                System.out.println(forStmt.getUpdate().toString().contains("++")); //必须为++
//                                System.out.println(forStmt.getCompare().get().toString().indexOf("<=")); //必须为 < length 或者 <= length - 1
////                                System.out.println(forStmt.getBody().toString().contains("remove"));
//                                System.out.println(forStmt);
//                                String body = forStmt.getBody().toString();
//                                if(body.contains("remove") || body.contains("delete"))
//
//                                System.out.println();
//                                System.out.println(forStmt.getBody().containsWithin());
                            }
                        },null);
//                        System.out.println(n.getMethods());
                    }

                }.visit(JavaParser.parse(file), null);

                System.out.println(); // empty line

            } catch (IOException e) {
                new RuntimeException(e);
            }
        }).explore(projectDir);
    }


    public static boolean judge(ForStmt forStmt){

        //被操作的数组或集合，必须是完整的遍历完的，从下标=0 自增到 length ，如果是从后往前那也算不行吧
        //下标自增必须一个一个增，也就是++，而且必须从0开始
        //分两种情况： 一个是从0到<= length - 1, 一个是到 < length,如果是-其他数也不行

        if(forStmt.getCompare().isPresent()){
            //获取操作的数组或集合  以及 下标
            List<Node> childNodes = forStmt.getCompare().get().getChildNodes();
            Node value = null,arr = null;
            if(childNodes.size() == 2){
                value = childNodes.get(0);  // 下标变量
                arr = childNodes.get(1);   // 数组或集合, 可如果这个也就是一个计数变量 例如j，那也算不行吧，因为无法判断这个究竟是多大
            }else{
                return false;   //如果判断条件多于两个 那可能就有跟本数组或集合不相关的
            }

            //判断下标必须从0开始 且为 ++
            NodeList<Expression> initialization = forStmt.getInitialization();
            NodeList<Expression> update = forStmt.getUpdate();  //这个是一个++算一个元素
            if(initialization.size() > 0) {
                if (!initialization.get(0).toString().replaceAll(" ", "").contains(value + "=0")) {
                    return false; //如果不存在下标变量=0   之所以只get(0)，是因为好像他里面全部都当做一个整体放在0
                }
            }else{
                return false;
            }

            boolean flag_update = false;
            for(int i = 0; i < update.size(); i++){
                if(update.get(i).toString().equals(value+"++") || update.get(i).toString().equals("++"+value)){
                    flag_update = true;
                    break;
                }
            }
            if(!flag_update){
                return false;
            }
            //---------------------------------

            //判断循环判断的必须为 <= length - 1 或者 < length
            String arr_list = (arr.toString().replaceAll(" ",""));
            String compare = forStmt.getCompare().get().toString().replaceAll(" ","");
            if(arr_list.contains("-1")){
                if(!compare.contains("<=")){
                    return false;
                }
            }else{ //不包含 -1，就是没有length - 1，所以只要 <
                //可是如果是 -其他的数也不行
                if(arr_list.contains("-")){   //既然没有-1，那就不应该有减号，否则就是减去了其他数
                    return false;
                }

                if(!compare.contains("<")){
                    return false;
                }
            }

            String set = "";
            //--------------------------------
            //如果循环体中存在 .remove  .add  ,集合的长度就是size()
            String body = forStmt.getBody().toString();
            if(arr.toString().contains(".size()")){
                String list = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                set = arr.toString().substring(0,arr.toString().indexOf(".size()"));
                String compare_add = list+".add";
                String compare_put = list+".put";
                String compare_remove = list+".remove";
                String compare_clear = list+".clear";
                if(body.contains(compare_add) || body.contains(compare_put) || body.contains(compare_remove) || body.contains(compare_clear)){
                    return false;
                }

                //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
                //此处也需要用循环进行判断全部！

            }else{
                if(!arr.toString().contains(".length")){
                    return false;
                }
                set = arr.toString().substring(0,arr.toString().indexOf(".length"));
            }

            //不可以存在使用下标charAt
            if(body.contains(set+".charAt")){
                return false;
            }

            //不可以存在return i;   算使用了下标
            if(!judge_return_index(new StringBuilder(body),"return",value.toString())){
                return false;
            }

            //----------------------------------------
            //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
            //此方法和下面查找 if ( 下标一样，不断以新的起点寻找indexOf（变量）和indexOf(=),看是否有赋值操作
            StringBuilder body3 = new StringBuilder(body);
            int count3 = 0;
            while (count3 < body3.length()){
                String body3_string = body3.toString();
                if(body3_string.contains(set) && body3_string.contains("=")){
//                         && body.indexOf(list) < body.indexOf("=")
                    int index_list = body3_string.indexOf(set,count3);
                    if(index_list + 1 > body3_string.length() - 1){
                        break;
                    }
                    int index_deng = body3_string.indexOf("=",index_list + 1);
                    if(index_deng != -1){
                        if(index_deng - index_list <= set.length() + 5){
                            return false;
                        }
                    }
                    count3 = index_list + 2;
                    if(count3 > body3_string.length() - 1){
                        break;
                    }
                    body3 = new StringBuilder(body3_string.substring(count3));
                    count3 = 0;
                }else{
                    break;
                }
            }

//            List<Character> judge_value = new ArrayList<>();

            //-----------------------------------------
            //如果存在对下标的if判断
            StringBuilder body2 = new StringBuilder(body);
            int count = 0;
            while(count < body2.length()){
                String body2_string = body2.toString();
                if(body2_string.contains("if") && body2_string.contains(value.toString())){
                    int index_if = body2_string.indexOf("if",count);
                    if(index_if + 1 > body2_string.length() - 1){
                        break;
                    }
                    int index_value = body2_string.indexOf(value.toString(),index_if + 1);
                    if(index_value - index_if <= 6){
                        return false;
                    }
                    count = index_if + 1;
                    if(count > body2_string.length() - 1){
                        break;
                    }
                    body2 = new StringBuilder(body2_string.substring(count));
                    count = 0;
                }else{
                    break;
                }
            }

            //------------------------
            //对 = 下标 进行判断
//            judge_index(body,value.toString(),"=");
            StringBuilder body4 = new StringBuilder(body);
            int count4 = 0;
            while(count4 < body4.length()){
                String body4_string = body4.toString();
                if(body4_string.contains("=") && body4_string.contains(value.toString())){
                    int index_deng = body4_string.indexOf("=",count4);
                    if(index_deng + 1 > body4_string.length() - 1){
                        break;
                    }
                    int index_value = body4_string.indexOf(value.toString(),index_deng + 1);

                    if(index_value - index_deng <= 3){
                        //防止出现 itent = 这种情况 n是下标，但itent不是，但一样算定位到n了
                        char front = ' ';
                        char behind = ' ';
                        if(index_value - 1 >= 0){
                            front = body4_string.charAt(index_value - 1);
                        }
                        if(index_value + value.toString().length() < body4_string.length()){
                            behind = body4_string.charAt(index_value + value.toString().length());
                        }
                        if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
                            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
                                return false;
                            }
                        }
                    }
                    count4 = index_deng + 1;

                    if(count4 > body4_string.length() - 1){
                        break;
                    }
                    body4 = new StringBuilder(body4_string.substring(count4));
                    count4 = 0;
                }else{
                    break;
                }
            }

            //对 下标 = 进行判断
//            judge_index(body,"=",value.toString());
            StringBuilder body5 = new StringBuilder(body);
            int count5 = 0;
            while(count5 < body5.length()){
                String body5_string = body5.toString();
                if(body5_string.contains("=") && body5_string.contains(value.toString())){
                    int index_value = body5_string.indexOf(value.toString(),count5);
                    if(index_value + 1 > body5_string.length() - 1){
                        break;
                    }
                    int index_deng = body5_string.indexOf("=",index_value + 1);
                    if(index_deng - index_value <= 3) {
                        char front = ' ';
                        char behind = ' ';
                        if(index_value - 1 > 0){
                            front = body5_string.charAt(index_value - 1);
                        }
                        if(index_value + value.toString().length() < body5_string.length()){
                            behind = body5_string.charAt(index_value + value.toString().length());
                        }
                        if (!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))) {
                            if (!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')) {
                                return false;
                            }
                        }
                    }
                    count5 = index_value + 1;

                    if(count5 > body5_string.length() - 1){
                        break;
                    }
                    body5 = new StringBuilder(body5_string.substring(count5));
                    count5 = 0;
                }else{
                    break;
                }
            }

            //对下标被非本次循环遍历的数组或集合使用，也是不行的
            StringBuilder body6 = new StringBuilder(body);
            int count6 = 0;
            while(count6 < body6.length()){
                String body6_string = body6.toString();
                if(body6_string.contains("["+value.toString()+"]") ){
                    int index_value = body6_string.indexOf("["+ value +"]",count6);

                    if(index_value - set.length() > 0){//防止下标跑出合理范围
                        if(!body6_string.substring(index_value - set.length(),index_value).equals(set)){
                            return false;
                        }
                    }else{
                        return false;
                    }
                    count6 = index_value + 2;

                    if(count6 > body6_string.length() - 1){
                        break;
                    }
                    body6 = new StringBuilder(body6_string.substring(count6));
                    count6 = 0;
                }else{
                    break;
                }
            }



//            for(int index = 0; index < body2.length(); index++){
//                if(body2.contains("if") && body.contains(value.toString())){
//                    if(body.indexOf("if") - body.indexOf(value.toString()) <= 3){
//                        return false;
//                    }
//                }
//
//            }

//            if(body.contains("continue")){
//                return false;
//            }




        }else{
            return false;
        }

        return true;
    }

    /*
        传入参数：方法体  需要判断的在前面的变量re  在后面的变量index
        作用：判断在方法体中是否存在  re index
        例如不可以存在 return 循环下标
        不可以        if(循环下标)
        不可以        = 循环下标
        不可以        循环下标 =
     */
    public static boolean judge_return_index(StringBuilder sb,String re,String index){
        int count = 0;
        while(count < sb.length()){
            String body = sb.toString();
            if(body.contains(re) && body.contains(index)){
                int index_re = body.indexOf(re,count);
                //判断真的是完整的这俩 不能是其他的 例如 areturnb 这样也会找到return
//                char front = body.charAt(index_re - 1);
//                char behind = body.charAt(index_re + re.length());
//                if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
//                    if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                        int index_in = body.indexOf(index,index_re + re.length());
//                    }
//                }
                if(judge_frBe(index_re,re.length(),body)){
                    int index_in = body.indexOf(index,index_re + re.length());
                    if(judge_frBe(index_in,index.length(),body)){
                        if(index_in - index_re < re.length() + 3){
                            return false;
                        }
                    }
                }
                count = index_re + 1;
                if(count > sb.length() - 1){
                    break;
                }
                sb = new StringBuilder(sb.substring(count));
                count = 0;
            }else{
                break;
            }
        }
        return true;
    }

    /*
    / 传入三个参数：要判断的值的在body中的下标，判断值的长度，body
      作用：判断找到的该值是否是真正的该值，例如找i，不能是找到了 aib
     */
    public static boolean judge_frBe(int value_index,int value_length,String body){
        if(value_index - 1 < 0 || value_index + value_length > body.length() - 1){
            return true;
        }
        char front = body.charAt(value_index - 1);
        char behind = body.charAt(value_index + value_length);
        if(!(front >= 'a' && front <= 'z')|| (front >= 'A' && front <= 'Z')){
            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
                return true;
            }
        }
        return false;
    }







//    public static boolean judge(ForStmt forStmt){
//
//        //被操作的数组或集合，必须是完整的遍历完的，从下标=0 自增到 length ，如果是从后往前那也算不行吧
//        //下标自增必须一个一个增，也就是++，而且必须从0开始
//        //分两种情况： 一个是从0到<= length - 1, 一个是到 < length,如果是-其他数也不行
//
//        if(forStmt.getCompare().isPresent()){
//            //获取操作的数组或集合  以及 下标
//            List<Node> childNodes = forStmt.getCompare().get().getChildNodes();
//            Node value = null,arr = null;
//            if(childNodes.size() == 2){
//                value = childNodes.get(0);  // 下标变量
//                arr = childNodes.get(1);   // 数组或集合, 可如果这个也就是一个计数变量 例如j，那也算不行吧，因为无法判断这个究竟是多大
//            }else{
//                return false;   //如果判断条件多于两个 那可能就有跟本数组或集合不相关的
//            }
//
//            //判断下标必须从0开始 且为 ++
//            NodeList<Expression> initialization = forStmt.getInitialization();
//            NodeList<Expression> update = forStmt.getUpdate();  //这个是一个++算一个元素
//            if(initialization.size() > 0) {
//                if (!initialization.get(0).toString().replaceAll(" ", "").contains(value + "=0")) {
//                    return false; //如果不存在下标变量=0   之所以只get(0)，是因为好像他里面全部都当做一个整体放在0
//                }
//            }else{
//                return false;
//            }
//
//            boolean flag_update = false;
//            for(int i = 0; i < update.size(); i++){
//                if(update.get(i).toString().equals(value+"++") || update.get(i).toString().equals("++"+value)){
//                    flag_update = true;
//                    break;
//                }
//            }
//            if(!flag_update){
//                return false;
//            }
//            //---------------------------------
//
//            //判断循环判断的必须为 <= length - 1 或者 < length
//            String arr_list = (arr.toString().replaceAll(" ",""));
//            String compare = forStmt.getCompare().get().toString().replaceAll(" ","");
//            if(arr_list.contains("-1")){
//                if(!compare.contains("<=")){
//                    return false;
//                }
//            }else{ //不包含 -1，就是没有length - 1，所以只要 <
//                //可是如果是 -其他的数也不行
//                if(arr_list.contains("-")){   //既然没有-1，那就不应该有减号，否则就是减去了其他数
//                    return false;
//                }
//
//                if(!compare.contains("<")){
//                    return false;
//                }
//            }
//
//            String set = "";
//            //--------------------------------
//            //如果循环体中存在 .remove  .add  ,集合的长度就是size()
//            String body = forStmt.getBody().toString();
//            if(arr.toString().contains(".size()")){
//                String list = arr.toString().substring(0,arr.toString().indexOf(".size()"));
//                set = arr.toString().substring(0,arr.toString().indexOf(".size()"));
//                String compare_add = list+".add";
//                String compare_put = list+".put";
//                String compare_remove = list+".remove";
//                String compare_clear = list+".clear";
//                if(body.contains(compare_add) || body.contains(compare_put) || body.contains(compare_remove) || body.contains(compare_clear)){
//                    return false;
//                }
//
//                //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
//                //此处也需要用循环进行判断全部！
//
//            }else{
//                if(!arr.toString().contains(".length")){
//                    return false;
//                }
//                set = arr.toString().substring(0,arr.toString().indexOf(".length"));
//            }
//
//            //不可以存在使用下标charAt
//            if(body.contains(set+".charAt")){
//                return false;
//            }
//
//            //----------------------------------------
//            //如果方法体中存在对集合或数组的赋值，即 数组/集合 = xxx
//            //此方法和下面查找 if ( 下标一样，不断以新的起点寻找indexOf（变量）和indexOf(=),看是否有赋值操作
//            StringBuilder body3 = new StringBuilder(body);
//            int count3 = 0;
//            while (count3 < body3.length()){
//                String body3_string = body3.toString();
//                if(body3_string.contains(set) && body3_string.contains("=")){
////                         && body.indexOf(list) < body.indexOf("=")
//                    int index_list = body3_string.indexOf(set,count3);
//                    if(index_list + 1 > body3_string.length() - 1){
//                        break;
//                    }
//                    int index_deng = body3_string.indexOf("=",index_list + 1);
//                    if(index_deng != -1){
//                        if(index_deng - index_list <= set.length() + 5){
//                            return false;
//                        }
//                    }
//                    count3 = index_list + 2;
//                    if(count3 > body3_string.length() - 1){
//                        break;
//                    }
//                    body3 = new StringBuilder(body3_string.substring(count3));
//                    count3 = 0;
//                }else{
//                    break;
//                }
//            }
//
////            List<Character> judge_value = new ArrayList<>();
//
//            //-----------------------------------------
//            //如果存在对下标的if判断
//            StringBuilder body2 = new StringBuilder(body);
//            int count = 0;
//            while(count < body2.length()){
//                String body2_string = body2.toString();
//                if(body2_string.contains("if") && body2_string.contains(value.toString())){
//                    int index_if = body2_string.indexOf("if",count);
//                    if(index_if + 1 > body2_string.length() - 1){
//                        break;
//                    }
//                    int index_value = body2_string.indexOf(value.toString(),index_if + 1);
//                    if(index_value - index_if <= 6){
//                        return false;
//                    }
//                    count = index_if + 1;
//                    if(count > body2_string.length() - 1){
//                        break;
//                    }
//                    body2 = new StringBuilder(body2_string.substring(count));
//                    count = 0;
//                }else{
//                    break;
//                }
//            }
//
//            //------------------------
//            //对 = 下标 进行判断
//            StringBuilder body4 = new StringBuilder(body);
//            int count4 = 0;
//            while(count4 < body4.length()){
//                String body4_string = body4.toString();
//                if(body4_string.contains("=") && body4_string.contains(value.toString())){
//                    int index_deng = body4_string.indexOf("=",count4);
//                    if(index_deng + 1 > body4_string.length() - 1){
//                        break;
//                    }
//                    int index_value = body4_string.indexOf(value.toString(),index_deng + 1);
//
//                    if(index_value - index_deng <= 3){
//                        //防止出现 itent = 这种情况 n是下标，但itent不是，但一样算定位到n了
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 >= 0){
//                            front = body4_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body4_string.length()){
//                            behind = body4_string.charAt(index_value + value.toString().length());
//                        }
//                        if(!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))){
//                            if(!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')){
//                                return false;
//                            }
//                        }
//                    }
//                    count4 = index_deng + 1;
//
//                    if(count4 > body4_string.length() - 1){
//                        break;
//                    }
//                    body4 = new StringBuilder(body4_string.substring(count4));
//                    count4 = 0;
//                }else{
//                    break;
//                }
//            }
//
//            //对 下标 = 进行判断
//            StringBuilder body5 = new StringBuilder(body);
//            int count5 = 0;
//            while(count5 < body5.length()){
//                String body5_string = body5.toString();
//                if(body5_string.contains("=") && body5_string.contains(value.toString())){
//                    int index_value = body5_string.indexOf(value.toString(),count5);
//                    if(index_value + 1 > body5_string.length() - 1){
//                        break;
//                    }
//                    int index_deng = body5_string.indexOf("=",index_value + 1);
//                    if(index_deng - index_value <= 3) {
//                        char front = ' ';
//                        char behind = ' ';
//                        if(index_value - 1 > 0){
//                            front = body5_string.charAt(index_value - 1);
//                        }
//                        if(index_value + value.toString().length() < body5_string.length()){
//                            behind = body5_string.charAt(index_value + value.toString().length());
//                        }
//                        if (!((front >= 'a' && front <= 'z') || (front >= 'A' && front <= 'Z'))) {
//                            if (!(behind >= 'a' && behind <= 'z') || (behind >= 'A' && behind <= 'Z')) {
//                                return false;
//                            }
//                        }
//                    }
//                    count5 = index_value + 1;
//
//                    if(count5 > body5_string.length() - 1){
//                        break;
//                    }
//                    body5 = new StringBuilder(body5_string.substring(count5));
//                    count5 = 0;
//                }else{
//                    break;
//                }
//            }
//
//            //对下标被非本次循环遍历的数组或集合使用，也是不行的
//            StringBuilder body6 = new StringBuilder(body);
//            int count6 = 0;
//            while(count6 < body6.length()){
//                String body6_string = body6.toString();
//                if(body6_string.contains("["+value.toString()+"]") ){
//                    int index_value = body6_string.indexOf("["+ value +"]",count6);
//
//                    if(index_value - set.length() > 0){//防止下标跑出合理范围
//                        if(!body6_string.substring(index_value - set.length(),index_value).equals(set)){
//                            return false;
//                        }
//                    }else{
//                        return false;
//                    }
//                    count6 = index_value + 2;
//
//                    if(count6 > body6_string.length() - 1){
//                        break;
//                    }
//                    body6 = new StringBuilder(body6_string.substring(count6));
//                    count6 = 0;
//                }else{
//                    break;
//                }
//            }
//
//
//
////            for(int index = 0; index < body2.length(); index++){
////                if(body2.contains("if") && body.contains(value.toString())){
////                    if(body.indexOf("if") - body.indexOf(value.toString()) <= 3){
////                        return false;
////                    }
////                }
////
////            }
//
////            if(body.contains("continue")){
////                return false;
////            }
//
//
//
//
//        }
//
//        return true;
//    }
}
