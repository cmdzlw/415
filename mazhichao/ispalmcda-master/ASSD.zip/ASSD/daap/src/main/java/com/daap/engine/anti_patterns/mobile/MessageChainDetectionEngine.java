package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ATD;
import com.daap.util.CreateFile;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.stmt.Statement;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MessageChainDetectionEngine {

	// MessageChain检测的常量
	private static final int MAX_MESSAGE_CHAIN_LENGTH = 5;

	// 存储有和没有MessageChain异味的方法列表
	private static ArrayList<MethodDeclaration> hasMessageChainList = new ArrayList<>();
	private static ArrayList<MethodDeclaration> noMessageChainList = new ArrayList<>();

	// 统计计数器
	private static int totalMethods;
	private static int totalMessageChainMethods;

	// 异味详细信息
	private static final String smell = "MessageChain";
	private static boolean hasMessageChain;
	private static int messageChainCount;
	private static int noMessageChainCount;

	// 重置方法，用于重置计数器和列表
	public static void reset() {
		hasMessageChain = false;
		messageChainCount = 0;
		noMessageChainCount = 0;
		hasMessageChainList.clear();
		noMessageChainList.clear();
		totalMethods = 0;
		totalMessageChainMethods = 0;
	}

	// 构造函数
	public MessageChainDetectionEngine() {
	}

	// 检测MessageChain异味的方法
	public static void detect() {
		reset();

		ATD.writeMessage("Message Chain:\n");
		ResultDocument resultDocument = new ResultDocument(Constants.A_MESSAGE_CHAIN);

		System.out.println("======================STARTED-------------------");

		// 遍历所有LegacyClass
		for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
			hasMessageChainList.clear();
			noMessageChainList.clear();

			// 遍历LegacyClass中的所有MethodDeclaration
			for (MethodDeclaration methodDeclaration : legacyClass.getMethodDeclarations()) {
				totalMethods++;

				// 检查方法是否是静态的、具有空体或是重写的（排除这些情况不进行MessageChain检查）
				if (methodDeclaration.isStatic() || isNullMethod(methodDeclaration) || isOverride(methodDeclaration)) {
					noMessageChainList.add(methodDeclaration);
					continue;
				}

				// 检查MessageChain异味
				NodeList<Statement> methodStatements = getMethodStatements(methodDeclaration);
				if (hasMessageChain(methodStatements)) {
					hasMessageChainList.add(methodDeclaration);
					continue;
				}

				noMessageChainList.add(methodDeclaration);
			}

			// 处理有MessageChain异味的方法
			for (MethodDeclaration methodDeclaration : hasMessageChainList) {
				processMethodWithMessageChain(legacyClass, methodDeclaration);
			}

			// 处理没有MessageChain异味的方法
			for (MethodDeclaration methodDeclaration : noMessageChainList) {
				processMethodWithoutMessageChain(legacyClass, methodDeclaration);
			}

			totalMessageChainMethods += hasMessageChainList.size();
		}

		System.out.println("Total Methods: " + totalMethods + " | Total MessageChain Methods: " + totalMessageChainMethods);

		ATD.writeMessage("Total: " + messageChainCount);
		ATD.detectionDone();

		System.out.println("======================FINISHED-------------------");

		// 将检测结果写入结果文档
		int srNo = 1;
		for (DetectedInstance detectedInstance : getDetectedInstances(hasMessageChainList)) {
			Helper.writeDoc(resultDocument, detectedInstance, srNo++);
		}
		Helper.writeFile(resultDocument);
	}

	// 检查方法是否有MessageChain异味的方法
	private static boolean hasMessageChain(NodeList<Statement> methodStatements) {
		// 为简单起见，假设如果语句数量超过阈值，就存在MessageChain异味
		return methodStatements.size() > MAX_MESSAGE_CHAIN_LENGTH;
	}

	// 处理有MessageChain异味的方法
	private static void processMethodWithMessageChain(LegacyClass legacyClass, MethodDeclaration methodDeclaration) {
		ATD.writeMessage("Class Name: " + legacyClass.getName()
				+ "\nPath: " + legacyClass.getPath() + "\n");

		Constants.setHmap(legacyClass.getPath(), Constants.A_MESSAGE_CHAIN);
		Constants.setSmell(Constants.A_MESSAGE_CHAIN, legacyClass.getPath(), methodDeclaration.clone().toString());

		System.out.println("LegacyClass: " + legacyClass.getName() + "   " + "MethodDeclaration: " + methodDeclaration.getNameAsString());
		System.out.println(methodDeclaration);

		hasMessageChain = true;
		try {
			CreateFile.createFile(methodDeclaration.clone().toString(), smell, messageChainCount + "", hasMessageChain);
		} catch (Exception e) {
			e.printStackTrace();
		}
		messageChainCount++;
	}

	// 处理没有MessageChain异味的方法
	private static void processMethodWithoutMessageChain(LegacyClass legacyClass, MethodDeclaration methodDeclaration) {
		try {
			CreateFile.createFile(methodDeclaration.clone().toString(), smell, noMessageChainCount + "", hasMessageChain);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Constants.Nothing.add(methodDeclaration.clone().toString());
		Constants.setNo(Constants.A_MESSAGE_CHAIN, legacyClass.getName(), methodDeclaration.clone().toString());

		noMessageChainCount++;
	}

	// 从方法声明中获取语句的方法
	private static NodeList<Statement> getMethodStatements(MethodDeclaration methodDeclaration) {
		NodeList<Statement> statements = new NodeList<>();

		try {
			statements = methodDeclaration.getBody().get().getStatements();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return statements;
	}

	// 检查方法是否具有空体的方法
	private static boolean isNullMethod(MethodDeclaration methodDeclaration) {
		try {
			return methodDeclaration.getBody().get().getStatements().isEmpty();
		} catch (Exception e) {
			return true;
		}
	}

	// 检查方法是否带有@Override注解的方法
	private static boolean isOverride(MethodDeclaration methodDeclaration) {
		for (int i = 0; i < methodDeclaration.getAnnotations().size(); i++) {
			if (methodDeclaration.getAnnotations().get(i).toString().contains("@Override")) {
				return true;
			}
		}
		return false;
	}

	// 从具有MessageChain异味的方法中获取DetectedInstances的方法
	private static List<DetectedInstance> getDetectedInstances(ArrayList<MethodDeclaration> methodDeclarations) {
		List<DetectedInstance> detectedInstances = new ArrayList<>();
		for (MethodDeclaration methodDeclaration : methodDeclarations) {
			boolean exists = false;
			for (DetectedInstance detectedInstance : detectedInstances) {
				if (detectedInstance.getName().equals(methodDeclaration.getNameAsString())) {
					detectedInstance.increment();
					exists = true;
					break;
				}
			}
			if (!exists) {
				detectedInstances.add(new DetectedInstance(methodDeclaration.getNameAsString(), "", 1));
			}
		}
		return detectedInstances;
	}
}
