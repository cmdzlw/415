package com.daap.engine.anti_patterns.mobile;

import com.daap.model.DetectedInstance;
import com.daap.model.LegacyClass;
import com.daap.model.LegacySystem;
import com.daap.ui.ATD;
import com.daap.util.Constants;
import com.daap.util.Helper;
import com.daap.util.ResultDocument;
import com.github.javaparser.ast.body.MethodDeclaration;

import java.util.ArrayList;

public class LPLDetectionEngine {
    private static final int PARAMETER_THRESHOLD = 4; // 参数数量阈值
    private static ArrayList<MethodDeclaration> longParamListMethods = new ArrayList<>();
    private static ArrayList<MethodDeclaration> normalParamMethods = new ArrayList<>();
    private static int totalDetected = 0;

    public static String smell = "Long Parameter List";
    private static boolean isLongParam = false;
    private static int IS_LONG_PARAM = 0;
    private static int NOT_LONG_PARAM = 0;

    public static void reset() {
        isLongParam = false;
        IS_LONG_PARAM = 0;
        NOT_LONG_PARAM = 0;
        longParamListMethods.clear();
        normalParamMethods.clear();
        totalDetected = 0;
    }

    public LPLDetectionEngine() {
    }

    public static void detect() {
        reset();
        ATD.writeMessage("Long Parameter List Detection:\n");
        ResultDocument resultDocument = new ResultDocument(Constants.A_LONG_PARAMETER_LIST);
        ArrayList<DetectedInstance> detectedInstances = new ArrayList<>();

        for (LegacyClass legacyClass : LegacySystem.getInstance().getAllClasses()) {
            longParamListMethods.clear();
            normalParamMethods.clear();

            for (MethodDeclaration method : legacyClass.getMethodDeclarations()) {
                // 检查参数数量是否超过阈值
                if (method.getParameters().size() > PARAMETER_THRESHOLD) {
                    longParamListMethods.add(method);
                    totalDetected++;
                } else {
                    normalParamMethods.add(method);
                }
            }

            // 处理检测到的方法
            for (MethodDeclaration method : longParamListMethods) {
                ATD.writeMessage("Class: " + legacyClass.getName() +
                        "\nMethod: " + method.getNameAsString() +
                        "\nParameters: " + method.getParameters().size() +
                        "\nPath: " + legacyClass.getPath() + "\n");

                Constants.setHmap(legacyClass.getPath(), Constants.A_LONG_PARAMETER_LIST);
                Constants.setSmell(Constants.A_LONG_PARAMETER_LIST, legacyClass.getPath(), method.getNameAsString());

                // 记录检测实例
                boolean exists = false;
                for (DetectedInstance instance : detectedInstances) {
                    if (instance.getName().equals(legacyClass.getName())) {
                        instance.increment();
                        exists = true;
                        break;
                    }
                }
                if (!exists) {
                    detectedInstances.add(new DetectedInstance(legacyClass.getName(), legacyClass.getPath(), 1));
                }

                // 写入结果文件
                isLongParam = true;
                try {
                    com.daap.util.CreateFile.createFile(
                            method.clone().toString(),
                            smell,
                            IS_LONG_PARAM + "",
                            isLongParam
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
                IS_LONG_PARAM++;
            }

            // 处理正常方法
            for (MethodDeclaration method : normalParamMethods) {
                try {
                    com.daap.util.CreateFile.createFile(
                            method.clone().toString(),
                            smell,
                            NOT_LONG_PARAM + "",
                            false
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
                NOT_LONG_PARAM++;
            }
        }

        ATD.writeMessage("Total Methods with Long Parameter List: " + totalDetected);
        ATD.detectionDone();

        // 写入结果文档
        int srNo = 1;
        for (DetectedInstance instance : detectedInstances) {
            Helper.writeDoc(resultDocument, instance, srNo++);
        }
        Helper.writeFile(resultDocument);
    }

    // 复用的辅助方法（来自MIM检测）
    private static boolean isOverride2(MethodDeclaration methodDeclaration) {
        return methodDeclaration.getAnnotations()
                .stream()
                .anyMatch(a -> a.toString().contains("@Override"));
    }
}