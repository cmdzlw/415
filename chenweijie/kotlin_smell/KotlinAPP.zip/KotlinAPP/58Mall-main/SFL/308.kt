for (activity in activityStack) {
            finishActivity(activity)
        }