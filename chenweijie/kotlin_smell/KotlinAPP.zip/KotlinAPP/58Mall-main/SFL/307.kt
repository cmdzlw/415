for (text in data) {
            mFlipperView.addView(buildView(text))
        }