for (i in contacts.indices) {
            DataFactory.addContact(contacts[i], this)
            if (i == contacts.size - 1) {
                isCreating = false
                val activity = this
                GlobalScope.launch(Dispatchers.Main) {
                    actionButton.text = "完成"
                    Toast.makeText(activity, "生成联系人完成，请到通讯录查看（结果可能存在短暂延迟）", Toast.LENGTH_LONG)
                        .show()
                }
            }
        }