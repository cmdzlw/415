for (item in found){
                bestBucket=item.toInt()
                if (bestBucket>=width) break
            }