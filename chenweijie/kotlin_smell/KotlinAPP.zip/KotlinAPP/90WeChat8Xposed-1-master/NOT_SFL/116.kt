findObservers(event)?.forEach {
            tryVerbosely { action(it) }