 (0 until processors).map { section ->
            thread(start = true) {
                for (offset in 0 until sectionSize) {
                    val idx = section * sectionSize + offset
                    main[section].add(transform(this[idx]))
                }
            }
        }.forEach { it.join() }