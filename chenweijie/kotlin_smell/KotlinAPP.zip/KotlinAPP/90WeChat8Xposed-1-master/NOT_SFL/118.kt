centers.parallelForEach { center ->
            center.interfaces.forEach { `interface` ->
                observers.forEach { plugin ->
                    val assignable = `interface`.isAssignableFrom(plugin::class.java)
                    if (assignable) {
                        center.register(`interface`, plugin)
                    }
                }
            }
        }