currentMenuItems?.forEach {
                        if (title == it.title) {
                            it.onClickListener(context)
                        }
                    }