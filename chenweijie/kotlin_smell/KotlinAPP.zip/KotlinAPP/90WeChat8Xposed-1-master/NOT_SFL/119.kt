 (providers + listOf(ListViewHider, MenuAppender)).parallelForEach { provider ->
            (provider as HookerProvider).provideStaticHookers()?.forEach { hooker ->
                if (!hooker.hasHooked) {
                    XposedUtil.postHooker(hooker)
                }
            }
        }