fields.forEach {
            when (it.first) {
                "var1" -> assertEquals(1, it.second)
                "var2" -> assertEquals(2, it.second)
                "var3" -> assertEquals(3, it.second)
                else -> throw Exception("Unknown key: ${it.first}")
            }
        }