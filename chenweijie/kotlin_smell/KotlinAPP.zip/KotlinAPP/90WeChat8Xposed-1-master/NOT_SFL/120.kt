inface.methods.forEach { method ->
            register(method.name, plugin)
        }