fields.forEach {
            when (it.first) {
                "var1" -> assertEquals(lazy { 1 }.toString(), it.second.toString())
                "var2" -> assertEquals(lazy { 2 }.toString(), it.second.toString())
                else -> throw Exception("Unknown key: ${it.first}")
            }
        }