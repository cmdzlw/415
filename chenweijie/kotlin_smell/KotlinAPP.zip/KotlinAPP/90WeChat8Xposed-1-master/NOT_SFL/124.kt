currentMenuItems?.forEach {
                    val item = menu.add(it.groupId, it.itemId, it.order, it.title)
                    item.setOnMenuItemClickListener { _ ->
                        it.onClickListener(param.thisObject as Activity)
                        return@setOnMenuItemClickListener true
                    }
                }