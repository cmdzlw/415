 tabs.forEachIndexed { index, tabInfo ->
            Tab(selected = selectedIndex == index, onClick = {
                onTabClick(index)
            }, text = {
                Text(text = tabInfo.name, fontSize = 14.sp)
            }, selectedContentColor = Color.Black, unselectedContentColor = UnselectedItemColor)
        }