for ((i, winner) in winnerResultList.withIndex()) {
                    handler.postDelayed(Runnable {
                        winnerViewModel.winnerList.add(winner)
                        winnerListAdapter.notifyDataSetChanged()
                    }, (6000 * i).toLong())
                }