list.forEach {
                tvshow.append(
                    it.code + " " + it.name
                            + " " + it.unit + " " + it.price + "\r\n"
                )
            }