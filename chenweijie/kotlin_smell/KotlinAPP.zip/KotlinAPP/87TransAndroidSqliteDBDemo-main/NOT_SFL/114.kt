getlist.forEach {
            tvshow.append(
                it.code + " " + it.barcode
                        + " " + it.qty + "\r\n"
            )
        }