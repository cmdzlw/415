list.forEach {
            for (i in 1..3) {
                val item = ProductItem()
                item.code = it.code
                item.barcode = it.code + i.toString()
                item.qty = 1
                itemlist.add(item)
            }
        }