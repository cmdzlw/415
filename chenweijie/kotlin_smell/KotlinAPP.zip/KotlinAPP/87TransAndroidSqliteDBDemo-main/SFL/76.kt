for (i in 0 until columnqty) {
                                    when (it.getType(i)) {
                                        Cursor.FIELD_TYPE_STRING -> {
                                            sb.append(it.getString(i))
                                        }
                                        Cursor.FIELD_TYPE_INTEGER -> {
                                            sb.append(it.getInt(i))
                                        }
                                        Cursor.FIELD_TYPE_FLOAT -> {
                                            sb.append(it.getFloat(i))
                                        }
                                        Cursor.FIELD_TYPE_BLOB -> {
                                            sb.append(it.getBlob(i))
                                        }
                                        else -> {
                                            sb.append(it.getString(i))
                                        }
                                    }
                                    sb.append(",")
                                }