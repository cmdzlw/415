for (str in strs) {
            //找到文件的路径  /data/data/包名/databases/数据库名称
            val dbFile = applicationContext.getDatabasePath(str)
            val dstFile = applicationContext.filesDir.path + "/" + str
            var fis: FileInputStream? = null
            var fos: FileOutputStream? = null
            try {
                //文件复制到sd卡中
                fis = FileInputStream(dbFile)
                fos = FileOutputStream(dstFile)
                var len = 0
                val buffer = ByteArray(2048)
                while (-1 != fis.read(buffer).also({ len = it })) {
                    fos.write(buffer, 0, len)
                }
                fos.flush()
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                //关闭数据流
                try {
                    fos?.close()
                    fis?.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }