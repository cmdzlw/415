for (i in 0 until columnqty) {
                                sb.append("[${it.columnNames[i]}]").append(",")
                            }