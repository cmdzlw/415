 for (str in files) {
                            var dbFile = it.getDatabasePath(str.name)
                            dbFile.delete()

                            var fis: FileInputStream? = null
                            var fos: FileOutputStream? = null
                            try {
                                //文件复制到sd卡中
                                fis = FileInputStream(str)
                                fos = FileOutputStream(dbFile)
                                var len = 0
                                val buffer = ByteArray(2048)
                                while (-1 != fis.read(buffer).also({ len = it })) {
                                    fos.write(buffer, 0, len)
                                }
                                fos.flush()
                                emit("${str}数据库还原完成。。。")
                            } catch (e: Exception) {
                                throw e
                            } finally {
                                //关闭数据流
                                try {
                                    fos?.close()
                                    fis?.close()
                                } catch (e: IOException) {
                                    throw e
                                }
                            }
                        }