for (i in 1..5) {
            val item = Product()
            item.code = "0000$i"
            item.name = "产品$i"
            item.unit = "套"
            item.price = 99f
            //写入数据
            db.ProductDao().add(item)
        }