for ((first, second) in travelsDict(o as Map<String?, *>)) {
                    items.add(Pair<String?, Any?>(String.format("%s_%s", key, first), second))
                }