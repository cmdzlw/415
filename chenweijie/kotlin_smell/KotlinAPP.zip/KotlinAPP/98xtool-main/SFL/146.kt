for (element in s) {
            ret = (ret * 31 + element.toInt()) and 0xffffffffL
        }