for (i in 0 until size) {
            bytes[i] = list[i]
        }