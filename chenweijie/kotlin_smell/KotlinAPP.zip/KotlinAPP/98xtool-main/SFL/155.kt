for (i in 1..3) {
            val keyWord = mavenKeyWordList[i]
            val result = mavenStr.subStringBetween("<$keyWord>", "</$keyWord>")
            list.add(result)
        }