for ((first, second) in travelsDict(o as Map<String?, *>)) {
                    items.add(Pair<String?, Any?>(String.format("%d_%s", i, first), second))
                }