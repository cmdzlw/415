for (message in messages) {
      text(message)
}