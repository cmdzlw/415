for (matcher in customMimeTypes) {
            if (matcher.match(data!!)) {
                return "." + matcher.getExt()
            }
        }