for (b in slice) {
                tmpkey = (65535L and ((2531011 + (214013L * tmpkey)) shr 16)) and 0xffffffffL
                list.add(((tmpkey and 0xff) xor b.toLong()).toByte())
            }