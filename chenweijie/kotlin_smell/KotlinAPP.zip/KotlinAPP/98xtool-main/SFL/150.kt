for ((first, second) in travelsList(o)) {
                    items.add(Pair<String?, Any?>(String.format("%s_%s", key, first), second))
                }