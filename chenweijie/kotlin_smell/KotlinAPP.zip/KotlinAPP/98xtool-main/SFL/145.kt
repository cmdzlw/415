for (k in trans.keys) {
                out = out.replace(k, trans[k].toString())
            }