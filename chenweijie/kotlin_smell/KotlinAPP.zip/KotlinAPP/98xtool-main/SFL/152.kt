for ((first, second) in travelsList(o)) {
                    items.add(Pair<String?, Any?>(String.format("%d_%s", i, first), second))
                }