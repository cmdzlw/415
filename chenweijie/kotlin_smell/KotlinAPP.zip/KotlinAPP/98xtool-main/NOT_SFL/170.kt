lines.forEach {
            val arr = it.trim().replace("\t", "").split("|")
            val arr1 = arr[1].split("=")
            println(arr1.first())
            println(arr1.last())
            val item = AndroidInstallErrorInfo(arr1.last().trim().toInt(), arr1.first().trim(), arr[2].trim())
            list.add(item)
            sb.append("${arr1.first()}|${arr1.last()}|${arr[2]}")
            sb.appendln()
        }