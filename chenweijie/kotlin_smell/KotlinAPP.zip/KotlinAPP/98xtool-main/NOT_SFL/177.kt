lines.forEach { line ->
                        if (line.contains("name")) {
                            wifiInfo.name = line.subStringBetween("<name>", "</name>")
                        }
                        if (line.contains("keyMaterial")) {
                            wifiInfo.pwd = line.subStringBetween("<keyMaterial>", "</keyMaterial>")
                        }
                    }