list.forEach {
            val imgFile = it
            val png1 = Image.getInstance(imgFile.toURI().toURL())

            val heigth: Float = png1.height
            val width: Float = png1.width
            val percent: Int = getPercent2(heigth, width)
            png1.alignment = Image.MIDDLE
            png1.scalePercent(percent.plus(3).toFloat()) // 表示是原来图像的比例;
            doc.add(png1)
        }