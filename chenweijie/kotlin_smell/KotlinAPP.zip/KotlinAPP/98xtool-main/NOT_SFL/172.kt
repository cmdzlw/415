mavenKeyWordList.forEach {
                mavenTemplateList.add("<$it>")
                mavenTemplateList.add("</$it>")
            }