dirFiles.forEach {
                       val tempFiles =  FileUtil.loopFiles(it) {
                           it.extension.toLowerCase() == "ncm"
                       }
                        controller.addFiles(tempFiles)
                    }