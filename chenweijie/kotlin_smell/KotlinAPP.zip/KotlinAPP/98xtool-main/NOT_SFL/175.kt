lines.forEach {
       val flag = it.substring(19, 20)
       if (flag.isNotBlank()) {
            val color = viewModel.map[flag]
            text(it) {
                 style {
                    fill = color!!
                    fontSize = 16.px
                 }
             }
         }
}