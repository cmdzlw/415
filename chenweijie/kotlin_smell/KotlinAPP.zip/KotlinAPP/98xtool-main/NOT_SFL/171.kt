cmd.lines().forEach {
                    runCmd("cmd /c $it")
                }