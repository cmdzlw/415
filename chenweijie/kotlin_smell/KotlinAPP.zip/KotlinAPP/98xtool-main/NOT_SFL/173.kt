it.list.forEach { plugin ->
                        vbox {
                            padding = insets(5)
                            button(plugin.name).apply {
                                addClass(Styles.optionMenu)
                                action {
                                    val viewClass = Class.forName(plugin.mainClass)
                                    val method = viewClass.getMethod("openModal")
                                    val myObject = viewClass.newInstance()
                                    method.invoke(myObject)

                                    //todo 使用openModal导致文件选择对话框会置于底层...
                                }
                            }
                        }
                    }