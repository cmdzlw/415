LpkUtils.travelsDict(entry).forEach {
            val name = it.first
            val value = it.second
            if (value is String && LpkUtils.isEncryptedFile(value)) {
                if (!trans.containsKey(value)) {
                    val tempName = name + "_" + id
                    val suffix = recovery(value, subdir + tempName)
                    trans[value] = tempName + suffix
                }

            }
        }