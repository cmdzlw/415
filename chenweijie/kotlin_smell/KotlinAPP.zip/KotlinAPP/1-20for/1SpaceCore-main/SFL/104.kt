for (key in mapping.keys) {
        if (mapping[key] == value) {
            return key
        }
    }
