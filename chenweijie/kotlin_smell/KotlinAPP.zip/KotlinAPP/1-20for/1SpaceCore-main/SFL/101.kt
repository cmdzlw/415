for (b in byteArray) {
    val i = b.toInt() and 0xff
    var hexString = Integer.toHexString(i)
    if (hexString.length < 2) {
        hexString = "0$hexString"
    }
    sb.append(hexString)
}