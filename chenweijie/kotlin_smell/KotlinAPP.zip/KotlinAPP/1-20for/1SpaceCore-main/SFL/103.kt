for (app in list) {
        app.packageInfo ?: continue
        val applicationInfo = app.packageInfo!!.applicationInfo
        val name = applicationInfo.loadLabel(packageManager).toString()
        val icon = applicationInfo.loadIcon(packageManager)
        val bean = BoxAppBean(userID, applicationInfo.packageName, name, icon)
        appList.add(bean)
    }
}