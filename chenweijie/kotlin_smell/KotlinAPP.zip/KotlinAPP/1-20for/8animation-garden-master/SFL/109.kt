for (s in listOf("HEVC-10bit", "AAC")) {
    TagButton({ Text(s) }, null, containerColorEffect = Color.Unspecified)
}