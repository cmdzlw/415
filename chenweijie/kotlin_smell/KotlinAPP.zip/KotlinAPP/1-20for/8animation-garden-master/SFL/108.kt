for (value in values) {
    if (text.contains(value.id, ignoreCase = true)
             value.otherNames.any { text.contains(it, ignoreCase = true) }
    ) {
        return value
    }