for (it in list) {
    ElevatedFilterChip(
            selected = isSelected(it),
            onClick = { currentOnClick?.invoke(it) },
            label = {
                ProvideTextStyle(LocalTextStyle.current.copy(lineHeight = textHeight)) {
                    content(it)
                }
            },
            enabled = enabled.invoke(it),
            elevation = elevation,
            modifier = Modifier.height(cardHeight),
               modifier = Modifier.animateItemPlacement(tween(200, 100)),
    )
}