for (commitFile in folder.listFiles().orEmpty().filter { it.extension == "commit" }) {
    if (commitFile.isFile) {
        logger.info { "${commitFile.nameWithoutExtension.takeLast(8)}: ${commitFile.readText()}" }
    }
}