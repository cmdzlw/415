for (i in 0 until childCount) {
    val child = parent.getChildAt(i)
    val layoutParams = child.layoutParams as RecyclerView.LayoutParams

    val top = child.bottom + layoutParams.bottomMargin
    val intrinsicHeight = divider?.intrinsicHeight ?: 0
    val bottom = top + intrinsicHeight

    divider?.setBounds(left, top, right, bottom)
    divider?.draw(c)
}