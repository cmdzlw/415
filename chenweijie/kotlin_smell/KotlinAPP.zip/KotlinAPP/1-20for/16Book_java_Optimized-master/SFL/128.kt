for (police in polices){
        police.unpdate("不好了，小偷偷东西了")
    }
