for (featureApplication in featureApplications) {
        featureApplication.onConfigurationChanged(newConfig)
    }
