for (entry in headerMap) {
    builder.addHeader(entry.key, entry.value)
}