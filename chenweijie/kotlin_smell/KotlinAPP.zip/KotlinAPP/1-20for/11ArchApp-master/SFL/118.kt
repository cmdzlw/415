for (featureApplication in featureApplications) {
        featureApplication.onTrimMemory(level)
    }
