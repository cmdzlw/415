for (activity in activityStack) {
        if (activity.javaClass == T::class.java) {
            return activity as T
        }
    }
    
