for (fragment in fragments) {
    if (fragment.tag == tag) {
        beginTransaction.show(fragment)
        beginTransaction.setMaxLifecycle(fragment, Lifecycle.State.RESUMED)
        isSelectFinish = true
    } else if (!fragment.isHidden && tags.contains(fragment.tag)) {
        beginTransaction.hide(fragment)
        beginTransaction.setMaxLifecycle(fragment, Lifecycle.State.STARTED)
    }
}