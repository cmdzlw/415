for (featureApplication in featureApplications) {
        featureApplication.onLowMemory()
    }
