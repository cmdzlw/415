for (i in 0 until sz) {
    if (!Character.isDigit(get(i))) {
        return false
    }
}