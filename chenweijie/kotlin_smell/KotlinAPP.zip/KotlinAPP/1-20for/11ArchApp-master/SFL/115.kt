for (featureApplication in featureApplications) {
        featureApplication.onCreate()
    }
