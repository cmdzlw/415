for (featureApplication in featureApplications) {
        featureApplication.attachBaseContext(base)
    }
