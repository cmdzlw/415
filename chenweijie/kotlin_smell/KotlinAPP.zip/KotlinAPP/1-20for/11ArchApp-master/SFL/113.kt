for (activity in activityStack) {
    if (activity.javaClass == T::class.java) {
        activities.add(activity as T)
    }
}