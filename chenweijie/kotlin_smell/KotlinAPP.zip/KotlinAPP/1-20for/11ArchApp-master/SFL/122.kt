for (i in categoryNameArray.indices) {
    fragments[i] = GankCategoryFragment.newInstance(
            categoryNameArray.get(i)
    )
}