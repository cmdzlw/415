for (operator in values()) {
        if (key.operator == operator.operator) {
            return operator
        }
    }
    
