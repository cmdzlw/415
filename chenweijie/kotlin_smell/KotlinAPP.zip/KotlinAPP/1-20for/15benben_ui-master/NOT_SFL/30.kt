answer.forEach { c ->
    testHistory[0][1] += c.toString()
    Thread.sleep(100)
    historyLastUpdateTime = Date()
}