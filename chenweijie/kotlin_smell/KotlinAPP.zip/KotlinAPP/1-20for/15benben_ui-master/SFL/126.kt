for (jsonObject in result) {
    sb.append(jsonObject.getString("text"))
    sb.append("\n")
}