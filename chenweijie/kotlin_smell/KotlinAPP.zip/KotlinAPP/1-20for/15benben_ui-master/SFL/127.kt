for (list in history) {
    var question = list[0].replace("\n", "<br/>")
    var answer = list[1].replace("\n", "<br/>").replace("🐂", "")
    sb.append(meBlockTemplate.replace("CONTENT", question))
    sb.append(benbenBlockTemplate.replace("CONTENT", answer))
}