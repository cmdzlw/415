for (btn in btnRow) {
            val isAvailable = if (btn.isAvailable) {
                btn.index !in viewState.inputBase.forbidBtn
            }
            else {
                false
            }

            Row(modifier = Modifier.weight(1f)) {
                KeyBoardButton(
                        text = btn.text,
                        onClick = { viewModel.dispatch(ProgrammerAction.ClickBtn(btn.index)) },
                        isAvailable = isAvailable,
                        backGround = btn.background,
                        isFilled = btn.isFilled,
                        paddingValues = PaddingValues(0.5.dp)
                )
            }
}
    