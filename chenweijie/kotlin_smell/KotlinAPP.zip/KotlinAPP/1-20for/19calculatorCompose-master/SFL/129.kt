for (i in integer.length-splitLength downTo end step splitLength) {
    integer.insert(i, addSplitChar)
    addCharCount++
}