for (btn in btnRow) {
            Row(modifier = Modifier.weight(1f)) {
                KeyBoardButton(
                        text = btn.text,
                        onClick = { viewModel.dispatch(StandardAction.ClickBtn(btn.index)) },
                        backGround = btn.background,
                        paddingValues = PaddingValues(0.5.dp),
                        isFilled = btn.isFilled
                )
            }
}

    