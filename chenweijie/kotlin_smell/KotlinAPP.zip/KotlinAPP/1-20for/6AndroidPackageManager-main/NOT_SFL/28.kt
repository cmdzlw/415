apksRecord.forEach {
                    val exec = Utils.exec("dumpsys package ${it.packageName}")
                    LogUtils.i("${it.packageName} -> \n $exec")
                }


