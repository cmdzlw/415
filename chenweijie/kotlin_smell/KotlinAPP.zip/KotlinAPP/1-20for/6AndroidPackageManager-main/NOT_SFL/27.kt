apks.forEach { it ->
                  it.activities?.forEach {
                        LogUtils.i("Activity:${it.name} , isEnabled:${it.isEnabled}")
                    }
                }