for (i in data.indices) {
    val t = data[i]
    if (t === model) return i
}