ForLoop@ for (i in allTextFromBufferedReader.indices) {
    //Every question start with [I]LK....
    if (allTextFromBufferedReader[i].length < 2
            || allTextFromBufferedReader[i][1] != 'I') {
        continue@ForLoop
    }
    //Add a new question to questionList
    val aQuestion = QuestionModel(
            qid = ind.toString(),
            lk = allTextFromBufferedReader[i].removePrefix("[I]"),
            question = allTextFromBufferedReader[i + 1].removePrefix("[Q]"),
            ansA = allTextFromBufferedReader[i + 2],
            ansB = allTextFromBufferedReader[i + 3],
            ansC = allTextFromBufferedReader[i + 4],
            ansD = allTextFromBufferedReader[i + 5],
            status = 0.toString()
    )
    db.insertQuestion(aQuestion)
    ind++
}