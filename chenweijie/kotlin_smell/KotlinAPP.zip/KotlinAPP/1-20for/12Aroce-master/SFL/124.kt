for (i in 0 until options.size) {
        val ranInt = Random().nextInt(4)
        val tempS = options[ranInt]
        options[ranInt] = options[0]
        options[0] = tempS
    }