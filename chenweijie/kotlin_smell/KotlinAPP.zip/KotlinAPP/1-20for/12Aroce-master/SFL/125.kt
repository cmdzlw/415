for (i in 0 until options.size) {
    if (reg.matches(options[i])) {
        correctAns = mlist[i]
    }