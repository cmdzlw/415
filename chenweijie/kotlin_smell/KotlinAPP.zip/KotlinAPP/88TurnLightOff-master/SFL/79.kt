for (m in solves.indices) {
            val solvePress = solves[m].solvePress
            sb.append("第").append((m + 1).toString()).append("个解：开关次数").append(solves[m].count).append("\n")
            for (i in solvePress.indices) {
                for (j in 0 until solvePress[i].size) {
                    sb.append(solvePress[i][j].toString()).append(" ")
                }
                sb.append("\n")
            }
            sb.append("\n")
        }