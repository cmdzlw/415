for (p in 0 until rows) {
     for (q in 0 until colum) {
          press!![p][q] = 0
     }
}