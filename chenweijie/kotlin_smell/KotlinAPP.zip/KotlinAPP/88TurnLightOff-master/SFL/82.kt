for (i in 0 until rowCount) {

            val rowLinearLayout = LinearLayout(activity)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT)
            if (i == 0) {
                params.topMargin = 10
            }
            params.weight = 1f
            rowLinearLayout.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until columnCount) {
                if (j == columnCount - 1) {
                    params.bottomMargin = 0
                    params.bottomMargin = 0
                }
                val l = LightKT(activity, i, j)
                l.setmOnClickListener(this)
                rowLinearLayout.addView(l, params)
            }

            if (i != rowCount - 2) {
                rootParams.bottomMargin = width / rowCount / 2 / 2
            } else if (i == rowCount - 1) {
                rootParams.bottomMargin = 0
            }
            rootView.addView(rowLinearLayout, rootParams)
        }