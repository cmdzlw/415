for (k in 0 until 16 - re.length) {
     sb.append("0")
}