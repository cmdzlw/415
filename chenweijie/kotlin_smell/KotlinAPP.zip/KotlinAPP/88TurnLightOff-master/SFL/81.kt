for (i in 0 until rowCount) {
            val rowLinearLayout = LinearLayout(activity)
            val params = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT)
            params.weight = 1f
            if (i == 0) {
                params.topMargin = 10
            }
            rowLinearLayout.orientation = LinearLayout.HORIZONTAL
            for (j in 0 until columnCount) {
                val l = LightKT(activity, i, j)
                l.setmOnClickListener(this)
                rowLinearLayout.addView(l, params)
            }

            if (i != rowCount - 2) {
                rootParams.bottomMargin = width / rowCount / 2
            } else {
                rootParams.bottomMargin = 0
            }
            rootView.addView(rowLinearLayout, rootParams)
        }