for (b in press!!) {
                                for (c in b) {
                                    if (c.toInt() == 1) {
                                        pressCount++
                                    }
                                }
                            }