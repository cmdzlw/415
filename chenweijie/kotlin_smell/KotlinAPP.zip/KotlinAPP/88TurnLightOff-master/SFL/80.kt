for (j in 0 until columnCount) {
                    if (((rootView.getChildAt(i) as LinearLayout).getChildAt(j) as LightKT).isLightOn) {
                        isAllLightOff = false
                        break@Out
                    }
                }