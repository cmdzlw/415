for (i in 0 until rowCount) {
            for (j in 0 until columnCount) {
                if (pressArr[i][j].toInt() == 1) {
                    ((rootView.getChildAt(i) as LinearLayout).getChildAt(j) as LightKT).setPressStatus(true)
                }
            }
        }