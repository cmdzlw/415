 for (aChessBoardStatu in chessBoardStatu) {
                            if (aChessBoardStatu.toInt() == 1) {
                                haveLight = true
                                break@OUT
                            }
                        }