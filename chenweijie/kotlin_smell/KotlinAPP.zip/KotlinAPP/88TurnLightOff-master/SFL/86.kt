for (i in 0 until rowCount) {
            for (j in 0 until columnCount) {
                ((rootView.getChildAt(i) as LinearLayout).getChildAt(j) as LightKT).setPressStatus(false)
            }
        }