for (i in status.indices) {
            for (j in 0 until status[i].size) {
                if (status[i][j].toInt() == 1) {
                    ((rootView.getChildAt(i) as LinearLayout).getChildAt(j) as LightKT).setLightStatus(true)
                }
            }
        }