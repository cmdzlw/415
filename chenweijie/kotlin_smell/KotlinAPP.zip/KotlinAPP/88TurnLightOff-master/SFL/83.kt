for (i in 0 until rowCount) {
            for (j in 0 until columnCount) {
                chArr[i][j] = if (((rootView.getChildAt(i) as LinearLayout).getChildAt(j) as LightKT).isLightOn) 1.toByte() else 0.toByte()
            }
        }