for (k in 0 until rows) {
                            tempArr[k] = rootArr[k].clone()
                        }