for (i in 0 until n) {
            val attr = a.getIndex(i)
            when (attr) {
                R.styleable.CustomView_isChecked -> isLightOn = a.getBoolean(attr, false)
            }

        }