for (kk in 0..1) {
                            for (n in 0 until colum) {
                                if (press!![kk][n].toInt() == 1) {//只对按下的灯和它的周边感兴趣
                                    tempArr[kk]!![n] = (if (tempArr[kk]!![n].toInt() == 1) 0 else 1).toByte()
                                    if (n + 1 < colum) {//存在下一列
                                        tempArr[kk]!![n + 1] = (if (tempArr[kk]!![n + 1].toInt() == 1) 0 else 1).toByte()
                                    }
                                    if (n - 1 >= 0) {//存在上一列
                                        tempArr[kk]!![n - 1] = (if (tempArr[kk]!![n - 1].toInt() == 1) 0 else 1).toByte()
                                    }
                                    if (kk + 1 < rows) {//存在下一行
                                        tempArr[kk + 1]!![n] = (if (tempArr[kk + 1]!![n].toInt() == 1) 0 else 1).toByte()
                                    }
                                }
                            }
                            break
                        }