for (jj in 0 until colum) {
      press!![0][colum - jj - 1] = java.lang.Byte.parseByte(reResult.substring(reResult.length - 1 - jj, reResult.length - jj))
}