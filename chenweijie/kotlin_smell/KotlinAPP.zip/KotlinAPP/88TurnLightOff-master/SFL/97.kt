for (b in press!!.indices) {
                                temp[b] = press!![b].clone()
                            }