for (ii in tempArr.indices) {
                            for (jj in 0 until tempArr[ii]!!.size) {
                                if (tempArr[ii]!![jj].toInt() == 1) {
                                    isOK = false
                                }
                            }
                            if (!isOK) break
                        }