 for (m in 1..rows - 1) {
                            for (n in 0 until colum) {

                                if (tempArr[m - 1]!![n].toInt() == 1) {
                                    press!![m][n] = 1
                                } else {
                                    press!![m][n] = 0
                                }


                                if (press!![m][n].toInt() == 1) {//只对按下的灯和它的周边感兴趣
                                    tempArr[m]!![n] = (if (tempArr[m]!![n].toInt() == 1) 0 else 1).toByte()
                                    if (n + 1 < colum) {
                                        tempArr[m]!![n + 1] = (if (tempArr[m]!![n + 1].toInt() == 1) 0 else 1).toByte()
                                    }
                                    if (n - 1 >= 0) {
                                        tempArr[m]!![n - 1] = (if (tempArr[m]!![n - 1].toInt() == 1) 0 else 1).toByte()
                                    }
                                    if (m + 1 < rows) {
                                        tempArr[m + 1]!![n] = (if (tempArr[m + 1]!![n].toInt() == 1) 0 else 1).toByte()
                                    }
                                    if (m - 1 >= 0) {
                                        tempArr[m - 1]!![n] = (if (tempArr[m - 1]!![n].toInt() == 1) 0 else 1).toByte()
                                    }
                                }
                            }

                        }