for (i in solves.indices) {
            if (solves[i].count > max) {
                max = solves[i].count
                maxIndex = i
            }
        }