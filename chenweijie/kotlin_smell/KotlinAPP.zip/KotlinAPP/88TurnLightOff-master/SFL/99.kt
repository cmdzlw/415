for (i in solves.indices) {
            if (solves[i].count < min) {
                min = solves[i].count
                minIndex = i
            }
        }