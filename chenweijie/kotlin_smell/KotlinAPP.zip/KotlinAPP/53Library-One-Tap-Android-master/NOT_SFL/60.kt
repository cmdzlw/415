semester.courses.forEach {
          val head = "${it.name} : ${it.type}"
          val desc = R.string.gr_template.getStringAndFormat(
            it.code,
            it.grade,
            it.credit,
            it.gp
          )
          add(
            Clickable(
              head,
              desc,
              passed = it.gp >= 1.0
            )
          )
        }