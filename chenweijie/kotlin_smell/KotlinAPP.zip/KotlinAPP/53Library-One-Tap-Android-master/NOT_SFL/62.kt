hex.forEach {
        append(
          "%04d".format(it.toString().toInt(16).toString(2).toInt())
        )
      }