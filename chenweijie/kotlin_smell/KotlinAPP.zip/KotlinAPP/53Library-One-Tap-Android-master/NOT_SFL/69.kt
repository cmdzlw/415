fragmentList.forEach {
      it.dismiss()
    }