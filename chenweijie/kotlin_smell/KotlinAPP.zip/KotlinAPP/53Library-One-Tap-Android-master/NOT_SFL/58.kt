semesters.forEach {
                    if (it.id != Int.MAX_VALUE) {
                      addAll(it.courses)
                    }
                  }