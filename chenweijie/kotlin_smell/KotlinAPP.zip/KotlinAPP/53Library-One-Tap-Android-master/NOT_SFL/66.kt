grades.forEach {
      runCatching {
        totalWeightedSum += it.grade.toDouble() * it.credit
      }.onFailure { _ ->
        totalCredits -= it.credit
      }
    }