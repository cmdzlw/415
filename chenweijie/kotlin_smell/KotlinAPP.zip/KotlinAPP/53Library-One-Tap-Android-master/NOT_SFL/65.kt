grades.forEach {
      runCatching {
        totalWeightedGP += when (algorithm) {
          GPAAlgorithm.DLUT -> it.gp * it.credit
          GPAAlgorithm.STD5 -> getGpByStandard5(it.grade.toInt()) * it.credit
          GPAAlgorithm.STD4 -> getGpByStandard4(it.grade.toInt()) * it.credit
          GPAAlgorithm.PK4 -> getGpByPeking4(it.grade.toInt()) * it.credit
        }
      }.onFailure { _ ->
        totalCredits -= it.credit
      }
    }