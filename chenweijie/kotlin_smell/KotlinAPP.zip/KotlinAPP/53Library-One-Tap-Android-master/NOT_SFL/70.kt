activityList.forEach {
      it.finish()
    }