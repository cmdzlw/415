semesters.forEach { semester ->
        add(Category(semester.name))
        if (semester.courses.isEmpty()) {
          if (semester.needsEvaluationTasks.isEmpty()) {
            add(Card(R.string.gr_empty.getString()))
          } else {
            add(
              Clickable(
                R.string.gr_eval_first.getString(),
                semester.needsEvaluationTasks.joinToString()
              )
            )
          }
          return@forEach
        }