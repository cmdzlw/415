exams.filter { it.startTime > now }.forEach { pending ->
        val name = pending.name
        val desc = R.string.ex_template.getStringAndFormat(
          pending.time,
          pending.room
        )
        add(
          Clickable(
            name,
            desc
          )
        )
      }