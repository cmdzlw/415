lessons.forEach {
        val head = "${it.type}  ${it.name}"
        val desc = R.string.ls_template.getStringAndFormat(
          it.teacher,
          it.code,
          it.credit,
          it.compulsory
        )
        add(
          Clickable(
            head,
            desc
          )
        )
      }