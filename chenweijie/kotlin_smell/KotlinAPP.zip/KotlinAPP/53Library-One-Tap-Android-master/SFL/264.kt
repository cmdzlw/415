for (k in 0 until 32) {
      ipLeft[k] = ipByte[k]
      ipRight[k] = ipByte[32 + k]
    }