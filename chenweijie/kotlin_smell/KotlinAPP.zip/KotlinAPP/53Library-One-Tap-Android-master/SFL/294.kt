for (j in 0 until width * height) {
      color = oldPx[j]
      r = Color.red(color)
      g = Color.green(color)
      b = Color.blue(color)
      a = Color.alpha(color)
      var gray = (r.toFloat() * 0.3 + g.toFloat() * 0.59 + b.toFloat() * 0.11).toInt()
      gray = if (gray < 128) {
        0
      } else {
        255
      }
      newPx[j] = Color.argb(a, gray, gray, gray)
    }