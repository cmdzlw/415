for (k in 0 until evalTasksObj.length()) {
                val currentTask = evalTasksObj.optJSONObject(k)!!
                needsEvaluationTasks.add(
                  currentTask.optJSONObject("lesson")!!.optJSONObject("course")!!
                    .optString("nameZh")
                )
              }