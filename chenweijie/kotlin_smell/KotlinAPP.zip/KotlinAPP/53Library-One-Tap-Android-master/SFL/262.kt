for (j in 0 until 4) {
            append(byteData[i * 4 + j])
          }