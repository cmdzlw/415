for (file in files) {
        if (file.isFile) {
          if (!file.delete()) return false
        } else if (file.isDirectory) {
          if (!deleteDir(file)) return false
        }
      }