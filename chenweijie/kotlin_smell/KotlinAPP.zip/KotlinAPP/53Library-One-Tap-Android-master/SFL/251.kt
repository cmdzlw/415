for (i in 0 until lessonArray.length()) {
        val lesson = lessonArray.optJSONObject(i)
        val lessonId = lesson.optInt("id")
        lessons.add(
          Lesson(
            lessonId,
            lesson.optString("code"),
            when (lesson.optJSONArray("compulsorys")!!.optString(0)) {
              "COMPULSORY" -> R.string.ls_compulsory.getString()
              "ELECTIVE" -> R.string.ls_elective.getString()
              else -> throw IllegalStateException("Illegal compulsory state")
            },
            lesson.optJSONObject("course")!!.optString("nameZh"),
            lesson.optJSONObject("course")!!.optDouble("credits"),
            lesson.optJSONArray("teacherAssignmentList")!!.let {
              buildString {
                for (t in 0 until it.length()) {
                  append(
                    it.optJSONObject(t)!!.optJSONObject("person")!!
                      .optString("nameZh")
                  )
                  append(",")
                }
              }.trim(',')
            },
            cultivateType.optJSONObject(lessonId.toString())!!.optString("nameZh")
          )
        )
      }