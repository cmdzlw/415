for (x in thirdLength - 1 downTo 0) {
              tempBt = dec(tempBt, thirdKeyBt[x]!!)
            }