for (k in 0 until 27) {
            key[k] = key[k + 1]
            key[28 + k] = key[29 + k]
          }