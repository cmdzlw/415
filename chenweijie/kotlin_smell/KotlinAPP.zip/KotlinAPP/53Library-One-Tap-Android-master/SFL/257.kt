for (m in 0 until 8) {
      val i = expandByte[m * 6] * 2 +
        expandByte[m * 6 + 5]
      val j = expandByte[m * 6 + 1] * 2 * 2 * 2 +
        expandByte[m * 6 + 2] * 2 * 2 +
        expandByte[m * 6 + 3] * 2 +
        expandByte[m * 6 + 4]
      when (m) {
        0 -> getBoxBinary(s1[i][j])
        1 -> getBoxBinary(s2[i][j])
        2 -> getBoxBinary(s3[i][j])
        3 -> getBoxBinary(s4[i][j])
        4 -> getBoxBinary(s5[i][j])
        5 -> getBoxBinary(s6[i][j])
        6 -> getBoxBinary(s7[i][j])
        7 -> getBoxBinary(s8[i][j])
        else -> ""
      }.let {
        sBoxByte[m * 4] = it.substring(0, 1).toByte()
        sBoxByte[m * 4 + 1] = it.substring(1, 2).toByte()
        sBoxByte[m * 4 + 2] = it.substring(2, 3).toByte()
        sBoxByte[m * 4 + 3] = it.substring(3, 4).toByte()
      }
    }