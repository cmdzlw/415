for (x in secondLength - 1 downTo 0) {
              tempBt = dec(tempBt, secondKeyBt[x]!!)
            }