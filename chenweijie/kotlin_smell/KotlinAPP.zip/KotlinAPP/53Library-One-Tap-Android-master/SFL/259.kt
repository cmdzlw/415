for (q in 0 until 16) {
          bt[16 * p + q] = 0.toByte()
        }