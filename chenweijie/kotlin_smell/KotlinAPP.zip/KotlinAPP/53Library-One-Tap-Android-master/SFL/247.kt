for (element in amList) {
          if (element == targetSeat) {
            val i = amList.indexOf(element)
            if (amList[i + 4] == Constants.RESERVE_VALID || amList[i + 4] == Constants.RESERVE_HAS_PERSON) {
              seat_id =
                amList[amList.indexOf(element) - 1].replace(
                  "\"seat_id\":",
                  ""
                ).replace("\"", "")
              break
            }
          }
        }
