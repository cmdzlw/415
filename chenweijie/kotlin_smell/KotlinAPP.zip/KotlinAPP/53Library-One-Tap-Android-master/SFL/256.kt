for (i in byteOne.indices) {
        set(i, (byteOne[i].toInt() xor byteTwo[i].toInt()).toByte())
      }