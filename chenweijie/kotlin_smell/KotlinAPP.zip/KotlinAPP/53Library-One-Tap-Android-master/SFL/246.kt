for (list in mClass?.rows!!) {
      if (list.order_process == "暂离" && list.order_type == mode.toString()) {
        if (list.back_time != "00:00:00") {
          return R.string.df_temp_end_time.getStringAndFormat(list.back_time)
        }
        break
      }
    }