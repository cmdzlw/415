for (j in 0 until 32) {
        tempLeft[j] = ipLeft[j]
        ipLeft[j] = ipRight[j]
      }