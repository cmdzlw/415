for (i in 0 until 32) {
      finalData[i] = ipRight[i]
      finalData[32 + i] = ipLeft[i]
    }