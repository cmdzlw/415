for (list in mClass?.rows!!) {
      if (orderIsValid(list.order_process, list.order_type, mode.toString())) {
        return list.order_id!!
      }
    }