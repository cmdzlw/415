for (j in 0 until count) {
                  val currentCourse = currentSemester.optJSONObject(j)!!
                  gradesIds.add(currentCourse.optInt("id"))
                  add(
                    Grade(
                      currentCourse.optInt("id"),
                      currentCourse.optJSONObject("course")!!
                        .optString("nameZh"),
                      currentCourse.optJSONObject("course")!!
                        .optString("code"),
                      currentCourse.optJSONObject("course")!!
                        .optDouble("credits"),
                      currentCourse.optString("gaGrade"),
                      currentCourse.optDouble("gp"),
                      currentCourse.optJSONObject("studyType")!!
                        .optString("text")
                    )
                  )
                }