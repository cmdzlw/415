for ((j, k) in (0 until 8).zip(7 downTo 0)) {
        key[i * 8 + j] = keyByte[8 * k + i]
      }