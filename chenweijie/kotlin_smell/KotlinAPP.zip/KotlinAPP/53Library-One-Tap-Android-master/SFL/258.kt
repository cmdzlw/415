for (m in 15 downTo j + 1) {
            pow *= 2
          }