for ((j, k) in (7 downTo 0).zip(0..7)) {
        ipByte[i * 8 + k] = originalData[j * 8 + pair.first]
        ipByte[i * 8 + k + 32] = originalData[j * 8 + pair.second]
      }