for (j in 0 until 64) {
        intByte[j] = strByte.substring(j, j + 1).toByte()
      }