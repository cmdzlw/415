for (y in 0 until secondLength) {
                tempBt = enc(tempBt, secondKeyBt[y]!!)
              }