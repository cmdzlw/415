for (list in mClass?.rows!!) {
      if (orderIsValid(
          list.order_process,
          list.order_type,
          mode.toString(),
          list.order_date
        )
      ) {
        return list.order_process!!
      }
    }