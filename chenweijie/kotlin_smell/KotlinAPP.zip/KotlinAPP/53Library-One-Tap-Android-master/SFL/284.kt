for (z in 0 until thirdLength) {
                  tempBt = enc(tempBt, thirdKeyBt[z]!!)
                }