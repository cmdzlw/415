for (z in firstLength - 1 downTo 0) {
              tempBt = dec(tempBt, firstKeyBt[z]!!)
            }