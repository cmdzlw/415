for (i in fileList.indices) {
          size += if (fileList[i].isDirectory) {
            getFolderSize(fileList[i])
          } else {
            fileList[i].length()
          }
        }