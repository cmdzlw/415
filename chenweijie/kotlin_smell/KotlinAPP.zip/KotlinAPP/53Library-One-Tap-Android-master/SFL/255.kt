for (i in 0 until 8) {
      epByte[i * 6 + 0] = rightData[
        if (i == 0) {
          31
        } else {
          i * 4 - 1
        }
      ]
      epByte[i * 6 + 1] = rightData[i * 4]
      epByte[i * 6 + 2] = rightData[i * 4 + 1]
      epByte[i * 6 + 3] = rightData[i * 4 + 2]
      epByte[i * 6 + 4] = rightData[i * 4 + 3]
      epByte[i * 6 + 5] = rightData[
        if (i == 7) {
          0
        } else {
          i * 4 + 4
        }
      ]
    }