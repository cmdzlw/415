for (i in 0 until majorArray.length()) {
        val course = majorArray.optJSONObject(i)!!
        val time = course.optString("examTime")
        val datetime = time.split(" ")
        exams.add(
          Exam(
            course.optJSONObject("course")!!.optString("nameZh"),
            time,
            "${datetime[0]} ${datetime[1].substringBefore("~")}".toDatetime(),
            "${datetime[0]} ${datetime[1].substringAfter("~")}".toDatetime(),
            if (!course.isNull("examPlace")) {
              course.optJSONObject("examPlace")!!.optJSONObject("room")!!
                .optString("nameZh")
            } else {
              R.string.ex_empty_room.getString()
            }
          )
        )
      }