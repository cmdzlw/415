for (x in 0 until firstLength) {
                  tempBt = enc(tempBt, firstKeyBt[x]!!)
                }