for (i in 0 until iterator) {
      keyBytes[i] = strToBt(key.substring(i * 4, i * 4 + 4))
    }