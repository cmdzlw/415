for (i in 0 until numBytes) {
                    val tmp = mmBuffer[i]
                    if (tmp in 1..127)
                        receiveString += tmp.toInt().toChar()
                }