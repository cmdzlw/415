 for (productid in keys) {
            val p = dao.findById(productid)!!
            data[idx][0] = p.productid// 商品编号
            data[idx][1] = p.cname// 商品名

            data[idx][2] = p.unitcost// 商品单价
            data[idx][3] = cart[productid]// 数量
            // 计算商品应付金额
            val amount = p.unitcost * BigDecimal(cart[productid]!!)
            data[idx][4] = amount
            idx++
        }