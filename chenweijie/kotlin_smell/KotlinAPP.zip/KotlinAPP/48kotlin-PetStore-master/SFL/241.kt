for (i in data.indices) {

            val orderDetail = OrderDetail().apply {
                orderid = order.orderid
                productid = data[i][0] as String
                quantity = data[i][3] as Int
                unitcost = data[i][2] as BigDecimal
            }
            // 创建订单详细
            orderDetailDao.create(orderDetail)
        }