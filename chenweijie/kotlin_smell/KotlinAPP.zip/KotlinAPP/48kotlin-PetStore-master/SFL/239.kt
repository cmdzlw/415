for (i in data.indices) {
                // 商品编号
                val productid = data[i][0] as String
                // 数量
                val quantity = data[i][3] as Int
                cart[productid] = quantity
            }