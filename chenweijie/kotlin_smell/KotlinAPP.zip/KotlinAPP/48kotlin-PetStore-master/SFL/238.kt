for (i in data.indices) {
                totalAmount += data[i][4] as BigDecimal
            }