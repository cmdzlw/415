variable.getStores().forEach { store ->
            val from = dataManager.getCSVariable(context, store.getFrom())
            pts.forEach { baseObj ->
                val instanceField = dataManager.getInstanceField(baseObj, store.getField())
                addPFGEdge(from, instanceField, PointerFlowEdge.Kind.INSTANCE_STORE)
            }
        }