pointsToSet.sequence().forEach { obj ->
            if (pointer.pointsToSet!!.addObject(obj)) {
                diff.addObject(obj)
            }
        }