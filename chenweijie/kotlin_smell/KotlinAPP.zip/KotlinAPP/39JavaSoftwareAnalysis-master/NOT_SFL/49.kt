  body.units.forEach {
            val callUnit = unitToString(up, it)
            val expected = expectedCallEdges[callUnit]
            val callees = callGraph.getCallees(it)
            val given = CallGraphPrinter.calleesToString(callees)
            if (expected != null) {
                if (expected != given) {
                    mismatches.add("\nCallees of $callUnit, expected: $expected, given: $given")
                }
            } else if (callGraph.getCallees(it).isNotEmpty()) {
                mismatches.add("\nCallees of $callUnit, expected: [], given: $given")
            }
        
    