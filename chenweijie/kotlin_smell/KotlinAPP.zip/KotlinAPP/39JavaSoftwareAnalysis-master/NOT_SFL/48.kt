 pta.callGraph.getAllEdges().forEach {
                Logger.i(TAG, it.toString())
            }