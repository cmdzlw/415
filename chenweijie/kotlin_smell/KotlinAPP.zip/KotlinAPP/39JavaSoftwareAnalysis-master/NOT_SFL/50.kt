units.forEach {
            val lineNumber = it.javaSourceStartLineNumber
            if (it !is NopStmt && isLastUnitOfItsLine(units, it)) {
                result[it]?.let { map ->
                    doCompare(method, lineNumber, map)
                }
            }