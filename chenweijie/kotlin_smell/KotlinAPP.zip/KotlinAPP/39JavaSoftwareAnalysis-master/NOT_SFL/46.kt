variable.getLoads().forEach { load ->
            val to = dataManager.getCSVariable(context, load.getTo())
            pts.forEach { baseObj ->
                val instanceField = dataManager.getInstanceField(baseObj, load.getField())
                addPFGEdge(instanceField, to, PointerFlowEdge.Kind.INSTANCE_LOAD)
            }
        }