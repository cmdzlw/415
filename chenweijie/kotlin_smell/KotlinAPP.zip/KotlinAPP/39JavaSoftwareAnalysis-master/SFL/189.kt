 for (i in 0 until ARRAY_SIZE) {
                if (it[i] != null && it[i] == element) {
                    it[i] = null
                    numberOfUsedArrayEntries--
                    return true
                }
            }