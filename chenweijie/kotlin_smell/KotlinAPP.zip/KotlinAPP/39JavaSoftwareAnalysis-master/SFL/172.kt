  for (ret in callee.getReturnVariables()) {
                    val retVar = dataManager.getCSVariable(calleeCtx, ret)
                    addPFGEdge(retVar, lhs, PointerFlowEdge.Kind.RETURN)
                }