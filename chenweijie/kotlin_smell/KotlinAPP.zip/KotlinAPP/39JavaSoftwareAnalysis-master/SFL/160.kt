 for (unit in cfg) {
            if (!reachable.contains(unit)) {
                ret.add(unit)
            }
        }