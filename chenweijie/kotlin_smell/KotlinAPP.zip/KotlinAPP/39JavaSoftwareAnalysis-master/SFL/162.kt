 for (entry in it.entries) {
                changed = changed or update(entry.key, entry.value)
            }