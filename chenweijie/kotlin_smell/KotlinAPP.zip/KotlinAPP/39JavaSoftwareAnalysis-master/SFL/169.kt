 for (stmt in method.getStatements()) {
                when (stmt) {
                    is Allocation -> processAllocation(csMethod, context, stmt)
                    is Assign -> processLocalAssign(context, stmt)
                    is Call -> processStaticCalls(context, stmt.callSite)
                }
            }