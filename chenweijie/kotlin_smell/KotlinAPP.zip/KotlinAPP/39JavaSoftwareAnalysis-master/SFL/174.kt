 for (unit in body.units) {
                unit.apply(sw)
                if (sw.relevant) {
                    when(unit) {
                        is AssignStmt -> build(method, unit)
                        is InvokeStmt -> build(method, unit)
                        is IdentityStmt -> build(method, unit)
                        is ReturnStmt -> build(method, unit)
                        else -> {
                            if (unit !is ThrowStmt) {
                                throw RuntimeException("Cannot handle statement: $unit")
                            }
                            build(method, unit)
                        }
                    }
                }
            }