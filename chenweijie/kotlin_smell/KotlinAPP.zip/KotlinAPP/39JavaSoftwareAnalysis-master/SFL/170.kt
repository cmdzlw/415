for (recvObj in pts) {
                val callee = resolveCallee(recvObj.obj, callSite)
                val csCallSite = dataManager.getCSCallSite(context, callSite)
                val calleeContext = contextSelector.selectContext(csCallSite, recvObj, callee)
                val callKind = callSite.callKind()
                val csCallee = dataManager.getCSMethod(calleeContext, callee)
                workList.addCallEdge(Edge(callKind, csCallSite, csCallee))
                val thisVar = dataManager.getCSVariable(calleeContext, callee.getThis())
                workList.addPointerEntry(thisVar, pointsToSetFactory.makePointsToSet(recvObj))
            }
       