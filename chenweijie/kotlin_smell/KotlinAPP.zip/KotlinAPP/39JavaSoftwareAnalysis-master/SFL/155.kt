 for (childClass in hierarchy.getSubclassesOf(parent)) {
                        classes.add(childClass)
                    }