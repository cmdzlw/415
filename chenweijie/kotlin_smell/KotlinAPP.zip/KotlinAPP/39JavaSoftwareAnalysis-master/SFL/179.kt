for (line in Files.readAllLines(filePath)) {
                if (isPointsToSet(line)) {
                    val splits = line.split(" -> ")
                    val pointer = splits[0]
                    val pts = splits[1]
                    resultMap[pointer] = pts
                }
            }