for (line in Files.readAllLines(filePath)) {
                if (isMethodSignature(line)) {
                    currentMethod = line
                } else if (!isEmpty(line)) {
                    val splits = line.split(" -> ")
                    val callUnit = splits[0]
                    val callees = splits[1]
                    resultMap.addToMapMap(currentMethod, callUnit, callees)
                }
            }