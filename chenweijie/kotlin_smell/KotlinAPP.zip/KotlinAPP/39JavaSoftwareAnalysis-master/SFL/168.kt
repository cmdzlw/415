for (entry in programManager.getEntryMethods()) {
            val csMethod = dataManager.getCSMethod(contextSelector.getDefaultContext(), entry)
            processNewMethod(csMethod)
            onFlyCallGraph.addEntryMethod(csMethod)
        }