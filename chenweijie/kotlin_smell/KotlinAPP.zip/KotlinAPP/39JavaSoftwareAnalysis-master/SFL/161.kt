 for (unit in body.units) {
            if (unit is AssignStmt) {
                val left = unit.leftOp as Local
                liveVarMap[unit]?.let {
                    if (!it.contains(left) && !mayHaveSideEffect(unit)) {
                        deadAssigns.add(unit)
                    }
                }
            }
        }