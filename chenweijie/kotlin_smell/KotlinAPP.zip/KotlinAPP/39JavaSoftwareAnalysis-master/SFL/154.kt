for (targetMethod in target) {
                        callGraph.addEdge(callSite, targetMethod, kind)
                        workList.add(targetMethod)
                    }
               