for (o in elements) {
            changed = changed or remove(o)
        }