 for (unit in cfg) {
            if (unit is IfStmt) {
                val result = ConstantPropagation.computeValue(unit.condition, constantMap[unit]!!)
                if (result.isConstant) {
                    if (result.getConstant() == CONDITION_TRUE) {
                        unreachableBranches.addEdge(unit, body.units.getSuccOf(unit))
                    } else {
                        unreachableBranches.addEdge(unit, unit.target)
                    }
                }else {
                    Logger.d(TAG, "result is $result")
                }
            }
        }
         return unreachableBranches
    }