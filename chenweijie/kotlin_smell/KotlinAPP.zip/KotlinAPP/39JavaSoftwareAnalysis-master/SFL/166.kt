 for (element in context.elementList) {
            changed = changed || addElement(element as T)
        }