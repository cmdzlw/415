  for (unit in p0.units) {
                    val callees = callGraph.getCallees(unit)
                    if (callees.isNotEmpty()) {
                        if (!hasCallees) {
                            hasCallees = true
                            Logger.i(TAG, "------ ${p0.method} [call graph] ------")
                        }
                        Logger.i(TAG, "${unitToString(up, unit)} -> ${calleesToString(callees)}")
                    }
                }