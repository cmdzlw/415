for (line in Files.readAllLines(filePath)) {
                if (isMethodSignature(line)) {
                    currentMethod = line
                } else if (!isEmpty(line)) {
                    parseLine(currentMethod, line)
                }
            }