 for (vb in valueBoxes) {
            val value = vb.value
            if (value is Local) {
                variableSet.add(value)
            }
        }