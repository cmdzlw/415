for (entry in v2.entries) {
            val key = entry.key
            result[key] =
                if (result.containsKey(key)) {
                    meetValue(entry.value, result[key])
                } else {
                    entry.value
                }
        }
