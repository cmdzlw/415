 for (i in params.indices) {
                val arg = dataManager.getCSVariable(calleeCtx, args[i])
                val param = dataManager.getCSVariable(calleeCtx, params[i])
                addPFGEdge(arg, param, PointerFlowEdge.Kind.PARAMETER_PASSING)
            }