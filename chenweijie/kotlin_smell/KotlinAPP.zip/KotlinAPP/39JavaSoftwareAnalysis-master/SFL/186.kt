for (v in elements) {
            if (v == null) {
                throw NullPointerException(NULL_KEY)
            }
        }