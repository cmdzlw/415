for (pair in pairs) {
            val varValue = pair.split("=")
            addValue(method, lineNumber, varValue[0], varValue[1])
        }