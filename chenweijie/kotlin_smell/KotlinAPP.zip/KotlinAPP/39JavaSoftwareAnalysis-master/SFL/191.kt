for (i in 0 until ARRAY_SIZE) {
                it[i]?.let { element ->
                    h += element.hashCode()
                }