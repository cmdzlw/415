for (i in 0 until ARRAY_SIZE) {
                if (it[i] == null) {
                    it[i] = element
                    numberOfUsedArrayEntries++
                    return true
                }
            }