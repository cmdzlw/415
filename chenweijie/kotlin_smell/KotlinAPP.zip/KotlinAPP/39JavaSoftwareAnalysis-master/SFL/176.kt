 for (entry in analysisResult.entries) {
                if (entry.key.name == t) {
                    found = true
                    val value = entry.value
                    if (value.toString() != expected) {
                        mismatches.add("\n${method}:L${lineNumber}, '${t}', expected: ${expected}, given: $value")
                    }
                }
            }