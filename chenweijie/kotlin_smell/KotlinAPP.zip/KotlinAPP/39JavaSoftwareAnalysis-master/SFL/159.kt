for (child in cfg.getSuccsOf(parent)) {
                    if (!filterEdges.containsEdge(parent, child)) {
                        deque.addFirst(child)
                    }
                }