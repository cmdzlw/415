 for (node in cfg) {
                var inVar: Domain?
                if (cfg.heads.contains(node)) {
                    inVar = inFlow[node]
                } else {
                    inVar = cfg.getPredsOf(node)
                        .stream()
                        .map(outFlow::get)
                        .reduce(analysis.newInitialFlow()){sum, succ ->
                            analysis.meet(sum!!, succ!!)
                        }

                    inFlow[node] = inVar!!
                }
                val outVar = outFlow[node]
                changed = changed or analysis.transfer(node, inVar!!, outVar!!)
            }