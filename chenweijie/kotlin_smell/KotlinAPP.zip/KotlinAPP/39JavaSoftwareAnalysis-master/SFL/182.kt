 for (v in m) {
                    if (v == null) {
                        throw NullPointerException(NULL_KEY)
                    }
                }