 for (node in cfg) {
            if (cfg.heads.contains(node)) {
                inFlow[node] = analysis.getEntryInitialFlow(node)
            }
            outFlow[node] = analysis.newInitialFlow()
        }