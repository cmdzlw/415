  for (o in elements) {
            if (!contains(o)) {
                return false
            }
        }