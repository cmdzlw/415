for (stmt in method.getStatements()) {
                if (stmt is Call) {
                    val callSite = stmt.callSite
                    val csCallSite = dataManager.getCSCallSite(context, callSite)
                    callSiteToContainer[csCallSite] = csMethod
                    callSiteIn.addToMapSet(csMethod, csCallSite)
                }
            }