for (i in 0 until ARRAY_SIZE) {
            array!![i]?.let {
                hashSet!!.add(it)
            }
        }