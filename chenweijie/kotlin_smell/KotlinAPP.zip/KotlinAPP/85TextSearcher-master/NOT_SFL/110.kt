lines.forEach {
    Text(
        text = it,
        fontStyle = FontStyle.Italic,
        style = MaterialTheme.typography.bodySmall
        ）
}