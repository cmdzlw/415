it.forEach {
     setHeader(it.key.toString(), it.value.toString())
}