it.listFiles().forEachIndexed { index, documentFile ->
    context.contentResolver.openFileDescriptor(documentFile.uri, "r")?.use { pfd ->
        runCatching {
            val ff = FontFamily(Font(pfd))
            ffResolver.resolve(ff)

            fontList.add(
                FontItem(
                    uri = documentFile.uri,
                    key = documentFile.uri.toString() + index,
                    name = documentFile.name ?: "",
                    fontFamily = ff
                 )
            )
         }
     }
}