pages.forEachIndexed { index, title ->
                        val selected = index == pagerState.currentPage
                        Tab(
                            text = {
                                Text(
                                    title,
                                    fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            selected = selected,
                            onClick = {
                                scope.launch {
                                    pagerState.animateScrollToPage(index)
                                }
                            },
                        )
                    }