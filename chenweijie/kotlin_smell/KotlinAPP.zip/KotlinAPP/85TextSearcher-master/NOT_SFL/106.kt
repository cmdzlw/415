pages.forEachIndexed { index, title ->
                Tab(
                    text = { Text(title) },
                    selected = index == pagerState.currentPage,
                    onClick = {
                        scope.launch { pagerState.animateScrollToPage(index) }
                    },
                )
}