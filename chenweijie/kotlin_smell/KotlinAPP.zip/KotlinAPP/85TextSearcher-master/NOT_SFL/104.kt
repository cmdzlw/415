 this.ids.forEach { id ->
            if (id is String) {
                val v = this[id]
                val value = when (v) {
                    is NativeObject -> v.show(deep + 1)
                    is NativeArray -> v.show
                    else -> v?.javaClass?.name
                }
                //println("$id->${this[id]?.javaClass?.name}")
                for (i in 0 until deep) stringBuilder.append("\t")
                stringBuilder.append("${id}:${value},\n") //删去多余的","
            }
        }