values.forEachIndexed { index, text ->
                    val checked = key == keys[index]
                    DropdownMenuItem(
                        text = {
                            Text(
                                text,
                                fontWeight = if (checked) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        onClick = {
                            expanded = false
                            selectedText = text
                            onKeyChange.invoke(keys[index])
                        }/*, modifier = Modifier.background(
                        if (checked) MaterialTheme.colorScheme.surfaceVariant
                        else Color.TRANSPARENT*/
                    )
                }