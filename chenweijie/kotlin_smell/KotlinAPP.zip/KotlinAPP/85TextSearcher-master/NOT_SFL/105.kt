list.toList().forEachIndexed { index, searchSource ->
     list[index] = searchSource.copy(order = index)
}