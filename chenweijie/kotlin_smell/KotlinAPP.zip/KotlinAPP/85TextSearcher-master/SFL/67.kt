for (bit in 0..7) {
                        child = if ((0x80 shr bit).toByte()
                                .toInt() and raw[i].toInt() == (0x80 shr bit).toByte()
                                .toInt()
                        ) {
                            bit
                        } else {
                            break
                        }
                    }