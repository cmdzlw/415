for (listener in listenerSet) {
     listener.log(text, level)
}