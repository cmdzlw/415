for (i in 1..50) { // 5s
     if (status == TextToSpeech.SUCCESS) break
     else if (i == 50) return false
     delay(100)
            
}