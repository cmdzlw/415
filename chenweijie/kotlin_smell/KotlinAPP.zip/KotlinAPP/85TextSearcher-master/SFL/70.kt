for (i in 0..1) {
            val tryToString: Boolean =
                if (typeHint == ScriptRuntime.StringClass) {
                    i == 0
                } else {
                    i == 1
                }
            var methodName: String
            var args: Array<Any?>
            if (tryToString) {
                methodName = "toString"
                args = ScriptRuntime.emptyArgs
            } else {
                methodName = "valueOf"
                args = arrayOfNulls(1)
                val hint: String = when {
                    typeHint == null -> {
                        "undefined"
                    }
                    typeHint == ScriptRuntime.StringClass -> {
                        "string"
                    }
                    typeHint == ScriptRuntime.ScriptableClass -> {
                        "object"
                    }
                    typeHint == ScriptRuntime.FunctionClass -> {
                        "function"
                    }
                    typeHint != ScriptRuntime.BooleanClass && typeHint != java.lang.Boolean.TYPE -> {
                        if (typeHint != ScriptRuntime.NumberClass
                            && typeHint != ScriptRuntime.ByteClass
                            && typeHint != java.lang.Byte.TYPE
                            && typeHint != ScriptRuntime.ShortClass
                            && typeHint != java.lang.Short.TYPE
                            && typeHint != ScriptRuntime.IntegerClass
                            && typeHint != Integer.TYPE
                            && typeHint != ScriptRuntime.FloatClass
                            && typeHint != java.lang.Float.TYPE
                            && typeHint != ScriptRuntime.DoubleClass
                            && typeHint != java.lang.Double.TYPE
                        ) {
                            throw Context.reportRuntimeError("Invalid JavaScript value of type $typeHint")
                        }
                        "number"
                    }
                    else -> {
                        "boolean"
                    }
                }
                args[0] = hint
            }