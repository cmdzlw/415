for (pair in channel) {
                updateLastTime()

                val config = pair.second
                val text = pair.first
                mTtsEngine?.apply {
                    setEngine(config.engine)
                    val locale =
                        if (config.locale.isBlank()) null else Locale.forLanguageTag(config.locale)
                    val voice = mTtsEngine?.voices?.find { it.name == config.voice }
                    mTtsEngine?.speak(
                        text = text,
                        locale = locale,
                        voice = voice,
                        speechRate = config.speechRate,
                        pitch = config.pitch
                    )
}