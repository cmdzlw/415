for (index in array.indices) {
     res[index] = mapToId(array[index])
}