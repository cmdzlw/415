for (i in res.indices) {
     res[i] = Context.javaToJS(args[i], topLevel)
 }