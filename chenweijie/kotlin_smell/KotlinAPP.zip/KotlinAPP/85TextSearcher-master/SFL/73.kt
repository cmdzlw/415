for (index in 0 until methodsSize) {
                        val method = methods[index]
                        if (method.declaringClass != Any::class.java) {
                            if (ScriptableObject.getProperty(
                                    localScope,
                                    method.name
                                ) !is Function
                            ) {
                                return false
                            }
                        }
                    }