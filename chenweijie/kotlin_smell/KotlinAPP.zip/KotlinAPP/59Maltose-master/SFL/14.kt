for (i in 0 until dataList.length()) {
                                    val item = dataList.get(i) as JSONObject
                                    //如果资源文件校验不合法，则重新下载资源
                                    if (!SecurityUtils.isPathFilesValid("${Config.APP_DATA_PATH}/${item.getString("playInfoId")}", item.getString("fileMd5"))){
                                        DownloadUtils.downloadResources(context, item.getString("playInfoId"))
                                    }
                                }