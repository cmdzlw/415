for ((key, value) in infos) {
            sb.append("$key=$value\n")
        }