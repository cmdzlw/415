for (file in fileList) {
                zipFile(file, zipout, rootpath)
            }