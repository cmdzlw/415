for (i in 0 until dataList.length()) {
                                val item = dataList.get(i) as JSONObject
                                if (it.name == item.getString("playInfoId")){
                                    isNotContain = false
                                    break
                                }
                            }