for (f in files) {
                if (f.isDirectory && f.name != "."
                        && f.getName() != "..") {
                    stack.push(f.path)
                }
            }