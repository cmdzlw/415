for (i in 0 until playInfos.length()) {
                            val item = playInfos.get(i) as JSONObject
                            var playInfo = oldPlayInfos.find { it.playInfoId == item.getString("playInfoId") }
                            if (playInfo != null){
                                playInfo.launcher = item.getString("launcher")
                                playInfo.duration = item.getLong("duration")
                                playInfo.fileMd5 = item.getString("fileMd5")
                                playInfo.type = PlayInfoType.valueOf(item.getString("type"))
                                oldPlayInfos.remove(playInfo)
                            }
                            else{
                                playInfo = PlayInfoModel(
                                        playInfoId = item.getString("playInfoId"),
                                        launcher = item.getString("launcher"),
                                        duration = item.getLong("duration"),
                                        fileMd5 = item.getString("fileMd5"),
                                        type = PlayInfoType.valueOf(item.getString("type"))
                                )
                            }
                            playInfo.save(context)
                        }