for (i in 0 until dataList.length()) {
                            val item = dataList.get(i) as JSONObject

                            val remoteVersionName = item.optString("versionName")
                            val remoteVersionCode = item.optInt("versionCode")
                            val remotePackageName = item.optString("packageName")

                            if (DeviceSettingUtils.getVersionName(context) != remoteVersionName ||
                                DeviceSettingUtils.getVersionCode(context) != remoteVersionCode ||
                                DeviceSettingUtils.getPackageName(context) != remotePackageName){
                                DownloadUtils.downloadApk(context, item.optString("id"))
                            }
                        }