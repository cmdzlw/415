for (i in 0 until dataList.length()) {
                            val item = dataList.get(i) as JSONObject
                            val operationDictionary = OperationDictionaryBean(
                                    key = item.getString("key"),
                                    type = OperateType.values()[item.getInt("type")],
                                    method = item.getString("method")
                            )
                            OperationDictionaryDbManager.insert(context, operationDictionary)
                        }