 for (i in 0 until dataList.length()) {
                            val item = dataList.get(i) as JSONObject
                            val player = PlayerModel(
                                    playerId = item.getString("playerId"),
                                    width = item.getInt("width"),
                                    height = item.getInt("height"),
                                    x = item.getDouble("x").toFloat(),
                                    y = item.getDouble("y").toFloat(),
                                    sort = item.getInt("sort")
                            )
                            player.save(context)
                        }