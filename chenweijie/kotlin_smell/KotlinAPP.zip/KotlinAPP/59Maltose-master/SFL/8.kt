for ((key, value) in paramMap) {
            paramString.append("&$key=${URLDecoder.decode(value, "UTF-8")}")
        }