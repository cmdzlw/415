 for (i in array.indices) {
            }