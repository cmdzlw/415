for (i in 0..15) { // 从第一个字节开始，对 MD5 的每一个字节
            // 转换成 16 进制字符的转换
            val byte0 = tmp[i] // 取第 i 个字节
            str[k++] = hexdigits[byte0.toInt().ushr(4) and 0xf] // 取字节中高 4 位的数字转换,
            // >>> 为逻辑右移，将符号位一起右移
            str[k++] = hexdigits[byte0.toInt() and 0xf] // 取字节中低 4 位的数字转换
        }