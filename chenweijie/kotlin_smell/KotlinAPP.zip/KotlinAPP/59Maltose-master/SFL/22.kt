for (resFile in resFileList) {
            zipFile(resFile, zipout, "")
        }