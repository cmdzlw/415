for (i in 0 until mObservers.size) {
            val sfo = mObservers[i]
            sfo.stopWatching()
        }