for (i in 0 until playerPlayInfos.length()) {
                            val item = playerPlayInfos.get(i) as JSONObject
                            val playerPlayInfo = PlayerPlayInfoModel(
                                    playInfoId = item.getString("playInfoId"),
                                    playerId = item.getString("playerId"),
                                    sort = item.getInt("sort")
                            )
                            //PlayerPlayInfoDbManager.insert(context, playerPlayInfo)
                            playerPlayInfo.save(context)
                        }