for (i in buf.indices) {
            appendHex(result, buf[i])
        }