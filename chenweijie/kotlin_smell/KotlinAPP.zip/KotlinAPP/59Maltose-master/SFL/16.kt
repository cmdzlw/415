for (i in 0 until dataList.length()) {
                            val item = dataList.get(i) as JSONObject
                            val alarm = AlarmModel(
                                    alarmId = item.getString("alarmId"),
                                    sign = item.getString("sign"),
                                    time = item.getString("time"),
                                    dateSetting = item.getString("dateSetting"),
                                    notifyUrl = item.getString("notifyUrl"),
                                    key = item.getString("key")
                            )

                            if (item.has("params")) {
                                alarm.params = ConvertHelper.gson.fromJson(item.getString("params"), object : TypeToken<SortedMap<String, String?>>() {}.type)
                            }
                            if (item.has("content")) {
                                alarm.content = ConvertHelper.gson.fromJson(item.getString("content"), object : TypeToken<SortedMap<String, String?>>() {}.type)
                            }
                            AlarmDbManager.insert(context, alarm)
                        }