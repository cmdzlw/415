for (num in arrayOfString) {
                Log.i(str2, num + "\t")
            }