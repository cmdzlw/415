for (i in 0..fileList.size) {
                zipFiles(folderPath, filePath + java.io.File.separator + fileList[i], zipOut);
            }