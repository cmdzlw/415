playerList.forEach {
            var newPlayer = newPlayerList.find { nit -> nit.playerId == it.playerId }
            if (newPlayer != null){
                it.width = newPlayer.width
                it.height = newPlayer.height
                it.x = newPlayer.x
                it.y = newPlayer.y
                it.sort = newPlayer.sort
            }
        }