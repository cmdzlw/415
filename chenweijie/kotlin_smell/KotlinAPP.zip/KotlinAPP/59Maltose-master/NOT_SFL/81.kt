apkDownloadingMap.filterValues { it == itemId }.entries.forEach {
                downManager.remove(it.key)
                apkDownloadingMap.remove(it.key)
            }