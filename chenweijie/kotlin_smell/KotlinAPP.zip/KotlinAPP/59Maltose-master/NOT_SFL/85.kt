 isNotContain
                        }.forEach {
                            PlayerDbManager.delete(context,it.playerId)
                        }