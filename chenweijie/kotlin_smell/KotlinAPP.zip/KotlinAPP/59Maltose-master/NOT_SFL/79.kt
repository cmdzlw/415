 pps.forEach {
            var playInfo = PlayInfoDbManager.get(context, it.playInfoId)
            if (playInfo != null){
                playInfo.sort = pps.indexOf(it)
                playList.add(playInfo)
            }
        }