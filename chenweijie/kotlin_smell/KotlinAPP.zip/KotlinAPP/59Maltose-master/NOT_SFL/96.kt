manager!!.databases.forEach { s, sqLiteDatabase ->
                    if (sqLiteDatabase != null)
                        sqLiteDatabase.close()
                }