PlayerListManager.playerList.forEach {
                            if (it.playInfo?.playInfoId == playInfoId) {
                                it.skip(context, ResultBean(ResultCode.PLAY_INFO_INVALID))
                            }
                        }