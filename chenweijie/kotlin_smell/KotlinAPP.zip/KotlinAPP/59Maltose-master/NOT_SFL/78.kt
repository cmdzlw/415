dateList.forEach {
                    val d = SimpleDateFormat(Config.DATE_TIME_FORMAT_PATTERN).parse("$it $time")
                    if (d > Date() && (recentSingleDate == null || recentSingleDate!!.time > d.time )){
                        recentSingleDate = d
                    }
                }