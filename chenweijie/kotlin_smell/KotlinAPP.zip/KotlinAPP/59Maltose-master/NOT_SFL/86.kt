oldPlayInfos.forEach { it.delete(context) }
