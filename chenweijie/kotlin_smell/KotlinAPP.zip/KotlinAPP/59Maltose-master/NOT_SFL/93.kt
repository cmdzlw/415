 playerList.forEach {
            App.mCurrentActivity!!.runOnUiThread{
                it.stopLoop(context)
            }
        }