 params.forEach( action = {
            if(it.value is File){
                builder.addFormDataPart(it.key, (it.value as File).name,
                        RequestBody.create(null, (it.value as File)))
            }else{
                builder.addFormDataPart(it.key,it.value.toString())
            }
        })