 playerList.forEach {
            App.mCurrentActivity!!.runOnUiThread{
                it.startLoop(context)
            }
        }