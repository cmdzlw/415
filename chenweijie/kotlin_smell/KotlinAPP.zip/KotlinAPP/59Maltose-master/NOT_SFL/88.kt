 fileList.forEach {
                        it.delete()
                    }