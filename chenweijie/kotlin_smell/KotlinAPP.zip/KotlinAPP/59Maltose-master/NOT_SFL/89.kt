playerList.forEach {
            it.destroy()
        }