Config.PLAY_FILE_TYPE.forEach { item ->
            if (fileType == item) {
                success = true
            }
        }