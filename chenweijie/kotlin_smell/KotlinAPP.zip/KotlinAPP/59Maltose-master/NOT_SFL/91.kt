newPlayerList.forEach {
            if(!playerList.map { it.playerId }.contains(it.playerId)){
                playerList.add(it)
            }
        }