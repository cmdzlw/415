this.forEach { i ->
        if (predicate(i)) {
            return i
        }
    }