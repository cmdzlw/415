this.split("\n")
            .forEach { line ->
                val choose = listOf(line.head(), line.li(), line.quoteBlock(), Result(true, line.text.processLine())).takeFirst { result -> result.ok }