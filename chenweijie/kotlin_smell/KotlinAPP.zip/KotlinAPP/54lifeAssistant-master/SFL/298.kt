for (user in userDao.loadAllUsers()) {
                   Log.d("111MainActivity", user.toString())
                }