for(i  in  0..10){
        println(i)
    }