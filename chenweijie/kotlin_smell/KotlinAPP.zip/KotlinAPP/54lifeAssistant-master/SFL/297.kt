for (node in fruitDao.loadAllFruits()) {
                    Log.d("111MainActivity", node.toString())
                }