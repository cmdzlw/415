for (book in bookDao.loadAllBooks()) {
                   Log.d("111MainActivity", book.toString())
               }