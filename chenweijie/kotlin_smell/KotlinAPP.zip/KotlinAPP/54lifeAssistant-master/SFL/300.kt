for (activity in activities) {
            if (!activity.isFinishing) {
                activity.finish()
            }
        }