localInventoryAssets.filter { !it.isLocal }.forEach {
                                val errors = InventoryErrorDbManager.queryByInventoryAssetsId(context, it.id)
                                errors.forEach { it.delete(context) }
                                it.delete(context)
                            }