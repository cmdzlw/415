errors.forEach {
      it.save(context)
}