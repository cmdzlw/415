inventoryErrorTypeItems.forEach { it.save(applicationContext) }
