errors.forEach {
                    if(!it.correctInfo.isNullOrEmpty()){
                        sb.append("${it.getErrorType(context)?.name}：${it.correctInfo}")
                        sb.append("\n")
                    }
                }