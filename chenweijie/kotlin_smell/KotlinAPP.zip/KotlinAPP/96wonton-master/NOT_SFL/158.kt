items.forEach {
                if (it != null){
                    val values = ContentValues()
                    values.put(BARCODE, it.barcode)
                    values.put(ASSETS_ID, it.assetsId)
                    values.put(NAME, it.name)
                    values.put(MODEL, it.model)
                    values.put(DEPT_ID, it.deptId)
                    values.put(DEPT, it.dept)
                    values.put(USER, it.user)
                    values.put(PLACE, it.place)
                    values.put(STATUS, it.status)
                    values.put(COMPANY, it.company)
                    db.insert(DB_TABLE, "", values)
                }
            }