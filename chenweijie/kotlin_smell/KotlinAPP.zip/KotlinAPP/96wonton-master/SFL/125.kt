for (i in 0 until taskObjs.length()) {
                            val taskObj = taskObjs.get(i) as JSONObject
                            val item = InventoryPlanModel(
                                    id = taskObj.optString("planId"),
                                    company = taskObj.optString("company"),
                                    name = taskObj.optString("name")
                            )
                            items.add(item)
                        }