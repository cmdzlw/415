for (j in rowBegin..newheight) {
                    //Log.v("hello", "width?:"+i+"  rowBegin?:"+j);
                    if (j >= height) {
                        colorValue = 0
                    } else {
                        rgb = rgbArray[offset + (j - startY) * width + (i - startX)]
                        if (rgb == -1) {
                            colorValue = 0
                        } else {
                            colorValue = 1
                        }
                    }
                    //Log.d("hello", "rgbArray?:"+(offset + (j - startY)
                    //		* scansize + (i - startX)));
                    //Log.d("hello", "colorValue?:"+colorValue);
                    tmpValue = tmpValue + (colorValue shl leftPos)
                    leftPos = leftPos - 1

                }