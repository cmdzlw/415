for (i in 0 until width) {
            for (j in 0 until height) {
                //得到当前像素的值
                val col = binarymap!!.getPixel(i, j)
                //得到alpha通道的值
                val alpha = col and -0x1000000
                //得到图像的像素RGB的值
                val red = col and 0x00FF0000 shr 16
                val green = col and 0x0000FF00 shr 8
                val blue = col and 0x000000FF
                // 用公式X = 0.3×R+0.59×G+0.11×B计算出X代替原来的RGB
                var gray = (red.toFloat() * 0.3 + green.toFloat() * 0.59 + blue.toFloat() * 0.11).toInt()
                //对图像进行二值化处理
                if (gray <= 95) {
                    gray = 0
                } else {
                    gray = 255
                }
                // 新的ARGB
                val newColor = alpha or (gray shl 16) or (gray shl 8) or gray
                //设置新图像的当前像素值
                binarymap.setPixel(i, j, newColor)
            }
        }