for (i in 0 until width) {
            for (j in 0 until height) {
                val `in` = j * width + i
                if (gray[i][j] and 0x0000ff < index + backvalue) {
                    pix[`in`] = Color.rgb(0, 0, 0)
                } else {
                    pix[`in`] = Color.rgb(255, 255, 255)
                }
            }
        }