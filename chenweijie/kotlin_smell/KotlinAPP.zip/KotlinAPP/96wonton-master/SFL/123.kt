for (i in buffer.indices) {
                        if (buffer[i].toInt() == 0x0D) {
                            sb.append("\n")
                        } else {
                            sb.append(buffer[i].toChar())
                        }
                    }