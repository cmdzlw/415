for (j in 0 until height) {
                if (gray[i][j] and 0x0000ff < graymean) {
                    graybackmean += gray[i][j] and 0x0000ff
                    back++
                } else {
                    grayfrontmean += gray[i][j] and 0x0000ff
                    front++
                }
            }