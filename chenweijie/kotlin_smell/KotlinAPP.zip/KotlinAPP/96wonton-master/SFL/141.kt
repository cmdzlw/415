 for (i in 0 until height) {
            for (j in 0 until width) {
                var grey = pixels[width * i + j]

                val red = grey and 0x00FF0000 shr 16
                val green = grey and 0x0000FF00 shr 8
                val blue = grey and 0x000000FF

                grey = (red * 0.3 + green * 0.59 + blue * 0.11).toInt()
                //grey = alpha | (grey << 16) | (grey << 8) | grey;
                if (grey < 128) {
                    b = 1
                } else {
                    b = 0
                }
                //pixels[width * i + j] = grey;
                pixels[width * i + j] = b.toInt()
            }
        }