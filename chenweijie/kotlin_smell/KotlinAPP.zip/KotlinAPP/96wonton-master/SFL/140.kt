for (i in mTabs.indices) {
            val tab = mTabs[i]
            if (tab.tag == tabId) {
                newTab = tab
            }
        }
        if (newTab == null) {
            throw IllegalStateException("No tab known for tag $tabId")
        }
        if (mLastTab != newTab) {
            if (ft == null) {
                ft = mFragmentManager!!.beginTransaction()
            }
            if (mLastTab != null) {
                if (mLastTab!!.fragment != null) {
                    //                  ft.detach(mLastTab.fragment);
                    ft!!.hide(mLastTab!!.fragment)
                }
            }
            if (newTab != null) {
                if (newTab.fragment == null) {
                    newTab.fragment = Fragment.instantiate(mContext,
                            newTab.clss.name, newTab.args)
                    ft!!.add(mContainerId, newTab.fragment, newTab.tag)
                } else {
                    //                  ft.attach(newTab.fragment);
                    ft!!.show(newTab.fragment)
                }
            }

            mLastTab = newTab
        }