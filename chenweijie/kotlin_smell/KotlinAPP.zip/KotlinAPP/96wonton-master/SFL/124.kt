for (tab in tabs) {
            val tabSpec = tabhost.newTabSpec(getString(tab.textResId))
            tabSpec.setIndicator(getTabSpecView(tab))
            tabhost.addTab(tabSpec, tab.tabFragment, null)
        }