for (i in 1 until width) { // 不算边界行和列，为避免越界
            for (j in 1 until height) {
                val x = j * width + i
                val r = pix[x] shr 16 and 0xff
                val g = pix[x] shr 8 and 0xff
                val b = pix[x] and 0xff
                pixelGray = (0.3 * r + 0.59 * g + 0.11 * b).toInt()// 计算每个坐标点的灰度
                gray[i][j] = (pixelGray shl 16) + (pixelGray shl 8) + pixelGray
                graysum += pixelGray
            }
        }