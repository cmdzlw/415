for (item in items) {
            if (!listItems.contains(item)) {
                listItems.add(0, item)
            }
        }