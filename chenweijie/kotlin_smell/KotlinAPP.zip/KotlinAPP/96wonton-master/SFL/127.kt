for (i in 0 until taskObjs.length()) {
                            val taskObj = taskObjs.get(i) as JSONObject
                            val item = InventoryErrorTypeModel(
                                    id = taskObj.optString("id"),
                                    name = taskObj.optString("name")
                            )
                            item.save(applicationContext)
                        }