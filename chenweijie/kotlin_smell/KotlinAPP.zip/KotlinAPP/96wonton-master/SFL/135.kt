for (i in 1 until frontvalue - backvalue + 1) {
            if (max < G[i]) {
                max = G[i]
                index = i
            }
        }