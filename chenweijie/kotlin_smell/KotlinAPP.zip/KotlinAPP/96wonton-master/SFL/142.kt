for (j in rowBegin..newheight) {
                    if (j >= height) {
                        colorValue = 0
                    } else {
                        rgb = rgbArray[offset + (j - startY) * width + (i - startX)]
                        if (rgb == -1) {
                            colorValue = 0
                        } else {
                            colorValue = 1
                        }
                    }
                    tmpValue = tmpValue + (colorValue shl leftPos)
                    leftPos = leftPos - 1

                }