for (i in 0 until width) {
                for (j in 0 until height) {
                    if (gray[i][j] and 0x0000ff < i1 + 1) {
                        graybackmean += gray[i][j] and 0x0000ff
                        back++
                    } else {
                        grayfrontmean += gray[i][j] and 0x0000ff
                        front++
                    }
                }
            }