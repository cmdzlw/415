for (i in 0 until taskObjs.length()) {
                            val taskObj = taskObjs.get(i) as JSONObject
                            val item = AssetsModel(
                                    barcode = taskObj.optString("barcode"),
                                    assetsId = taskObj.optString("assetsId"),
                                    name = taskObj.optString("name"),
                                    deptId = taskObj.optString("deptId"),
                                    dept = taskObj.optString("dept"),
                                    place = taskObj.optString("place"),
                                    user = taskObj.optString("user"),
                                    model = taskObj.optString("model"),
                                    company = taskObj.optString("company"),
                                    status = taskObj.optInt("status")>0
                            )
                            items.add(item)
                        }