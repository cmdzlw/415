for (i in 0 until width) {
                val r = rgba[index] and -0x1000000 shr 24
                val g = rgba[index] and 0xFF0000 shr 16
                val b = rgba[index] and 0xFF00 shr 8

                val y = (66 * r + 129 * g + 25 * b + 128 shr 8) + 16
                val u = (-38 * r - 74 * g + 112 * b + 128 shr 8) + 128
                val v = (112 * r - 94 * g - 18 * b + 128 shr 8) + 128

                val temp = (if (y > 255) 255 else if (y < 0) 0 else y).toByte()
                yuv420sp[index++] = (if (temp > 0) 1 else 0).toByte()
            }