for ((index, article) in articleList.withIndex()) {
                        Log.d(Constant.DEBUG_TAG, "title$index: ${article.title}")
                    }