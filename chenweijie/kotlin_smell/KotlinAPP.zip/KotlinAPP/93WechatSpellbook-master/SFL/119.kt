for (i in 0 until len) {
            val a = buffer.get().toInt()
            when {
                a and 0x80 == 0 -> {    // ascii char
                    chars[i] = a.toChar()
                }
                a and 0xe0 == 0xc0 -> { // read one more
                    val b = buffer.get().toInt()
                    chars[i] = (a and 0x1F shl 6 or (b and 0x3F)).toChar()
                }
                a and 0xf0 == 0xe0 -> {
                    val b = buffer.get().toInt()
                    val c = buffer.get().toInt()
                    chars[i] = (a and 0x0F shl 12 or (b and 0x3F shl 6) or (c and 0x3F)).toChar()
                }
                else -> {
                    // throw UTFDataFormatException()
                }
            }
        }