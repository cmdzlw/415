 predicates.forEach { predicate ->
                    if (predicate(item)) {
                        return@filter true
                    }
                }