 findObservers(event)?.parallelForEach { observer ->
            tryVerbosely { action(observer) }
        }