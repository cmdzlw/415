clazz.declaredFields.forEach {
            it.isAccessible = true
            it.set(copy, it.get(obj))
        }