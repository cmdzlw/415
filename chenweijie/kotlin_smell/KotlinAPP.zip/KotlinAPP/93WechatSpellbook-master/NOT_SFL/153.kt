report1.forEach {
            when (it.first) {
                "$TestObject1Name.var1" -> assertEquals("1", it.second)
                "$TestObject1Name.var2" -> assertEquals("2", it.second)
                "$TestObject1Name.var3" -> assertEquals("3", it.second)
                "$TestObject2Name.var1" -> assertEquals(lazy { 1 }.toString(), it.second)
                "$TestObject2Name.var2" -> assertEquals(lazy { 2 }.toString(), it.second)
                else -> throw Exception("Unknown key: ${it.first}")
            }
        }