record.sections.forEach { section ->
                        if (index in section) {
                            param.args[0] = section.base + (index - section.start)
                            return
                        }
                    }