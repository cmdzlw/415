 @JvmStatic inline fun <T> Iterable<T>.parallelForEach(crossinline action: (T) -> Unit) {
        val pool = createThreadPool()
        val iterator = iterator()
        while (iterator.hasNext()) {
            val item = iterator.next()
            pool.execute {
                tryVerbosely { action(item) } // 避免进程崩溃
            }
        }
        pool.shutdown()
        pool.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS)
    }