instance::class.java.declaredFields.forEach { field ->
            if (Lazy::class.java.isAssignableFrom(field.type)) {
                field.isAccessible = true
                val lazyObject = field.get(instance)
                if (lazyObject is WechatGlobal.UnitTestLazyImpl<*>) {
                    lazyObject.refresh()
                }
            }
        }