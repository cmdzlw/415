objects.forEach { instance ->
                MirrorUtil.clearUnitTestLazyFields(instance)
}