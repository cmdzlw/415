 issue.itemList.forEach {
            if (it.type == VIDEO_SMALL_CARD_TYPE) {
                it.itemType = VideoRelateAdapter.TYPE_VIDEO
            } else {
                it.itemType = VideoRelateAdapter.TYPE_TITLE
            }
        }