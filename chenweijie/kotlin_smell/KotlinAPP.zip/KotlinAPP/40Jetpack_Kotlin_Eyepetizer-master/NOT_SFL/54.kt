list.forEach {
                    if (it.type == TEXT_HEADER_TYPE) {
                        providerMultiModels.add(
                            ProviderMultiModel(
                                type = ProviderMultiModel.Type.TYPE_TITLE,
                                item = it
                            )
                        )
                    } else {
                        providerMultiModels.add(
                            ProviderMultiModel(
                                type = ProviderMultiModel.Type.TYPE_IMAGE,
                                item = it
                            )
                        )
                    }
                }