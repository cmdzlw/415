 tags.forEach { tag ->
                val binding =
                    DiscoverItemTopicTagBinding.inflate(activity.layoutInflater, this, false)
                binding.name = tag.name
                addView(binding.root)
            }