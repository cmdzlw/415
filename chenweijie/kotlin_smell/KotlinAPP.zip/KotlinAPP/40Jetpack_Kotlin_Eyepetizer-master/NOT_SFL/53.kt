   keyWordList.forEach { keyword ->
            val chip = layoutInflater.inflate(R.layout.daily_search_chip, mChipGroup, false) as Chip
            chip.text = keyword
            chip.setOnClickListener {
                showLoadingView(keyword)
                getSearchVideo(keyword)
            }
            mChipGroup.addView(chip)
        }