for (y in boardYMin..(boardYMin + 200)) {
            val nodeRgb = image.rgb(boardX, y)
            if (abs(nodeRgb["r"]!! - 245) + abs(nodeRgb["g"]!! - 245) + abs(nodeRgb["b"]!! - 245) == 0) {
                boardY = y
                break
            }
        }