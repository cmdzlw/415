for (y in startY..(h - 1)) {

            var boardXSum = 0 // 所有棋盘点x坐标之和
            var boardCount = 0 // 所有棋盘点总数

            val startRgb = image.rgb(w / 8, y)
            for (x in xStart..xEnd) {
                val nodeRgb = image.rgb(x, y)
                if (abs(x - pieceX) < config.pieceBodyWidth) {
                    // 棋子比下一个棋盘还高的情况（排除将棋子当做棋盘的情况）
                    continue
                }

                if (abs(nodeRgb["r"]!! - startRgb["r"]!!) +
                        abs(nodeRgb["g"]!! - startRgb["g"]!!) +
                        abs(nodeRgb["b"]!! - startRgb["b"]!!) > 20) {
                    // 找到棋盘
                    boardXSum += x
                    boardCount++
                }
            }

            if (boardCount > 0) {
                // 找到棋盘上顶点
                // 由上向下逐行扫描，只要扫到了棋盘，就已经可以计算出棋盘X方向中心点坐标
                boardX = boardXSum / boardCount
                boardYMin = y
                graphics.drawOval(boardX - 5, y - 5, 10, 10)
                break
            }
        }