for (x in 1..(w - 1)) {
                val node = image.getRGB(x, y)
                if (start != node) {
                    startY = y - 50
                    break@findStartY
                }
            }