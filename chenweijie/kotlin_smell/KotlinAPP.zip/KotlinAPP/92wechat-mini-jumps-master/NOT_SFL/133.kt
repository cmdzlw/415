(startY..(h - 1)).forEach { y ->
            (0..(w - 1)).forEach { x ->
                val rgb = image.rgb(x, y)
                if (rgb["r"] in 51..59 && rgb["g"] in 54..62 && rgb["b"] in 96..109) {
                    // 找到棋子
                    pieceXSum += x
                    pieceCount++
                    pieceYMax = max(y, pieceYMax)
                }
            }
        }