for (alias in command.entry.aliases) {
                    if (alias == name) {
                        foundCommand = command
                    }
                }