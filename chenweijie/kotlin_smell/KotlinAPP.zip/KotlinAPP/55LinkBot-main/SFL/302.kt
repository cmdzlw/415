for (i in (page - 1) * Utils.config.setting.helpCountEachPage until page * Utils.config.setting.helpCountEachPage) {
            if (i >= commands.size) {
                break
            }
            message.append(
                Utils.message.info.helpTextTemplate.format(
                    commands[i].entry.name,
                    commands[i].entry.aliases.joinToString(", "),
                    commands[i].entry.usage,
                    commands[i].entry.description
                )
            )
        }