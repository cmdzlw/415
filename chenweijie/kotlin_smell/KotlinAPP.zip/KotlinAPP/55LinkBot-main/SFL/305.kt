for (i in it.indices) {
                        when (it[i]) {
                            "String" -> {
                                // 任何参数都可以
                            }
                            "Int" -> {
                                if (!args[i].matches(Regex("[0-9]+"))) {
                                    return CommandResult.INVALID_USAGE
                                }
                            }
                            "Double" -> {
                                if (!args[i].matches(Regex("[0-9]+\\.[0-9]+"))) {
                                    return CommandResult.INVALID_USAGE
                                }
                            }
                            "Boolean" -> {
                                if (args[i] != "true" && args[i] != "false") {
                                    return CommandResult.INVALID_USAGE
                                }
                            }
                            else -> {
                                return CommandResult.ERROR
                            }
                        }
                    }