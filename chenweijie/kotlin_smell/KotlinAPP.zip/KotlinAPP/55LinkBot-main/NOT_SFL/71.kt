result.permissionTrue.forEach {
            permission.append(it).append(", ")
        }