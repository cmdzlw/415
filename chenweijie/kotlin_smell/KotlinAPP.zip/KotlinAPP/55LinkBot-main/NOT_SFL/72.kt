prefix.forEach {
            if (text.startsWith(it)) {
                isCmd = true
            }
        }