 pluginFiles.forEach { file ->
                    loadPlugin(file, skipError)
                }