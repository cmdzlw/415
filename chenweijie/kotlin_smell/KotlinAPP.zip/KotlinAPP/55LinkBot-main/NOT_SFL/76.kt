path.forEach {
            result.append(
                when (it.last()) {
                    '\\' -> it
                    '/' -> it.removeSuffix("/") + "\\"
                    else -> it + "\\"
                }
            )
        }