 args.forEach {
            if (!skip) {
                argCmd = argCmd.plus(it)
            }
            skip = false
        }