events.forEach { event ->
            registerEvent(event)
        }