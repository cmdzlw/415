 for (i in 0 until listenerCount) {
            mLoginListListener.getBroadcastItem(i)?.loginStatus(status)
        }