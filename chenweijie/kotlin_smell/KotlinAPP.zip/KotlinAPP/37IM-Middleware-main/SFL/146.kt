 for (i in 0 until listenerCount) {
            mListListener.getBroadcastItem(i)?.onMessageReceived(message.toByteArray())
        }