  parallelList.parallelStream().forEach {
            MainScope().launch(Dispatchers.IO) {
                it.init()
            }
        }