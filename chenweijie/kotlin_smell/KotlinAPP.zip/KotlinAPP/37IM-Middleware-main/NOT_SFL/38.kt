seriesList.forEach {
            it.init()
        }