  seriesList.forEach {
            it.init()
        }