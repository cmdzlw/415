fun push(vararg value: T) = value.forEach { push(it) }
    


 