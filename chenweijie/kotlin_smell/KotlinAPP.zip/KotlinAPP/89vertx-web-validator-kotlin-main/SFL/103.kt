for((i, item) in list.withIndex()) {
					var goodType = false
					for(type in allowedTypes!!) {
						if(type.isAssignableFrom(item!!::class.java)) {
							goodType = true
							break
						}
					}

					if(!goodType)
						return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.INVALID_ITEM, "The item at index $i of the JSON array is not the correct type")
				}