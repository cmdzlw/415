for((key, clazz) in reqs.entries) {
				if(!map.containsKey(key)) {
					return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.MISSING_FIELD, "The provided JSON object does not contain the field $key")
				} else if(clazz != null && !clazz.isAssignableFrom(map[key]!!::class.java)) {
					return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.INVALID_FIELD, "The field $key in the provided JSON object is not the correct type")
				}
			}