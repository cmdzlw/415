for((str, bool) in matchStrings)
			if(valLowercase == str.lowercase())
				return ParamValidator.ValidatorResponse(bool)