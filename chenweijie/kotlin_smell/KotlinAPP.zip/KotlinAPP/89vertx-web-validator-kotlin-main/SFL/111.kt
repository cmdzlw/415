for((key, validator) in paramValidators.entries) {
			if(params.contains(key)) {
				val param = ParamValidator.Param(key, params[key]!!, ctx)

				// Validate parameter
				val res = validator.paramValidator.validate(param)

				// Assign parsed value, otherwise add error to list
				if(res.valid)
					parsedParams[key] = res.result
				else
					errorsList.add(RequestValidationError(res.errorType!!, res.errorMessage!!, key))
			} else if(validator.optional) {
				// Assign default value if one is defined
				if(validator.default != null)
					parsedParams[key] = validator.default
			} else {
				// Add missing parameter error to list
				errorsList.add(RequestValidationError(RequestValidationError.DefaultType.MISSING_PARAM, "Missing parameter \"$key\"", key))
			}
		}