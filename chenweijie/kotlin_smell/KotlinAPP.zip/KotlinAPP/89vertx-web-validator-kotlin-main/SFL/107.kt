for(char in str.toCharArray())
				if(!reqChars!!.contains(char))
					return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.INVALID_CHARS, "The provided string contains invalid characters")