for((key, validator) in routeParamValidators.entries) {
			if(routeParams.contains(key)) {
				val param = ParamValidator.Param(key, routeParams[key]!!, ctx)

				// Validate parameter
				val res = validator.paramValidator.validate(param)

				// Assign parsed value, otherwise add error to list
				if(res.valid)
					parsedRouteParams[key] = res.result
				else
					errorsList.add(RequestValidationError(res.errorType!!, res.errorMessage!!, key))
			} else if(validator.optional) {
				// Assign default value if one is defined
				if(validator.default != null)
					parsedRouteParams[key] = validator.default
			} else {
				// Add missing parameter error to list
				errorsList.add(RequestValidationError(RequestValidationError.DefaultType.MISSING_ROUTE_PARAM, "Missing route parameter \"$key\"", key))
			}
		}