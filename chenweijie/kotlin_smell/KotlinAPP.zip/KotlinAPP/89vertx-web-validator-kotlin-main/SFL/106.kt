for((key, validator) in paramValidators.entries) {
				if(!map.containsKey(key)) {
					return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.MISSING_FIELD, "The provided JSON object does not contain the field $key")
				} else {
					// Convert param to string
					@Suppress("UNCHECKED_CAST", "IMPLICIT_CAST_TO_ANY")
					val str = when(val toValidate = map[key]) {
						is LinkedHashMap<*, *> -> JsonObject(toValidate as LinkedHashMap<String, *>).toString()
						is ArrayList<*> -> JsonArray(toValidate).toString()
						else -> toValidate.toString()
					}

					// Create param
					val valParam = ParamValidator.Param("${param.field}[\"$key\"]", str, param.context)

					// Validate
					val res = validator.validate(valParam)

					// Send invalid if it failed validation
					if(!res.valid)
						return res
				}
			}