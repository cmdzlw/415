for((i, item) in list.withIndex()) {
					// Check if this is an array or object, and see if they need to be validated
					if(arrayValidator != null && item is ArrayList<*>) {
						val arrParam = ParamValidator.Param("${param.field}[$i]", JsonArray(item).toString(), param.context)
						val res = arrayValidator!!.validate(arrParam)

						// Send invalid if it failed validation
						if(!res.valid)
							return res
					} else if(objectValidator != null && item is LinkedHashMap<*, *>) {
						@Suppress("UNCHECKED_CAST")
						val arrParam = ParamValidator.Param("${param.field}[$i]", JsonObject(item as LinkedHashMap<String, *>).toString(), param.context)
						val res = objectValidator!!.validate(arrParam)

						// Send invalid if it failed validation
						if(!res.valid)
							return res
					}
				}