for(char in str.toCharArray())
				if(char != char.lowercaseChar())
					return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.INVALID_CASE, "The provided string contains uppercase characters")