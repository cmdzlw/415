for((i, item) in list.withIndex())
   if(item == null)
      return ParamValidator.ValidatorResponse(RequestValidationError.DefaultType.INVALID_ITEM, "The JSON array cannot contain any nulls, and the item at index $i is null")