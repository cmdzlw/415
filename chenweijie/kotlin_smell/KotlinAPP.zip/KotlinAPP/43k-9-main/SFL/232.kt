for (c in this@quoted) {
                if (c.isQText() || c.isWsp()) {
                    append(c)
                } else if (c.isVChar()) {
                    append('\\').append(c)
                } else {
                    throw IllegalArgumentException("Unsupported character: $c")
                }
            }