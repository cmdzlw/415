 for (c in this) {
            if (c.isQText() || c.isWsp()) {
                length++
            } else if (c.isVChar()) {
                length += 2
            } else {
                throw IllegalArgumentException("Unsupported character: $c")
            }
        }