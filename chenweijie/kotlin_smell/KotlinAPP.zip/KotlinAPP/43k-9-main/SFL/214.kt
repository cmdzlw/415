 for (security in connectionSecurities) {
            val port = security.toSmtpDefaultPort()

            assertThat(port).isEqualTo(
                when (security) {
                    ConnectionSecurity.None -> 587L
                    ConnectionSecurity.StartTLS -> 587L
                    ConnectionSecurity.TLS -> 465L
                },
            )
        }