for ((parameterName, parameterValue) in singleParameters) {
            if (parameterName !in parameters) {
                parameters[parameterName] = DecoderUtil.decodeEncodedWords(parameterValue, null)
            } else {
                ignoredParameters.add(parameterName to parameterValue)
            }
        }