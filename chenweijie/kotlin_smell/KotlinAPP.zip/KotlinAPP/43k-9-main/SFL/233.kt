for (c in this@quotedUtf8) {
                if (c == DQUOTE || c == BACKSLASH) {
                    append('\\').append(c)
                } else {
                    append(c)
                }
            }