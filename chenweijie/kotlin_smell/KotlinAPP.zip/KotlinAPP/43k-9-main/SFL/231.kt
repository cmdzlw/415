for ((name, value) in parameters) {
            encodeAndAppendParameter(name, value)
        }