 for (hostname in hostnames) {
            assertThat(testSubject.execute(hostname)).isFalse()
        }