 for (parameterSection in parameterSections) {
                    val originalParameterName = parameterSection.originalName
                    parameters[originalParameterName] = basicParameters[originalParameterName]!!.value
                }