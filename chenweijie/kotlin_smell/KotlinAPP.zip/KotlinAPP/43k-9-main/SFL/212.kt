for (type in types) {
            val authType = type.toAuthType()

            assertThat(authType).isEqualTo(
                when (type) {
                    AuthenticationType.PasswordCleartext -> AuthType.PLAIN
                    AuthenticationType.PasswordEncrypted -> AuthType.CRAM_MD5
                    AuthenticationType.OAuth2 -> AuthType.XOAUTH2
                    AuthenticationType.ClientCertificate -> AuthType.EXTERNAL
                    else -> AuthType.PLAIN
                },
            )
        }