for (subjectAlternativeName in subjectAlternativeNames) {
                    append("- ").append(subjectAlternativeName[1]).append("\n")
                }