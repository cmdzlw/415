for ((parameterName, parameterValue) in basicParameters) {
            val parameterSection = convertToParameterSection(parameterName, parameterValue)

            if (parameterSection == null) {
                singleParameters[parameterName] = parameterValue.value
            } else {
                parameterSectionMap.getOrPut(parameterSection.name) { mutableListOf() }
                    .add(parameterSection)
            }
        }