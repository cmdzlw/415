for (character in encodedWord) {
                if (character == '_') {
                    append("=20")
                } else {
                    append(character)
                }
            }