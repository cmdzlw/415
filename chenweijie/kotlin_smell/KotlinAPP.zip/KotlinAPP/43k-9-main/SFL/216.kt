for (security in securities) {
            val connectionSecurity = security.toConnectionSecurity()

            assertThat(connectionSecurity).isEqualTo(
                when (security) {
                    MailConnectionSecurity.NONE -> ConnectionSecurity.None
                    MailConnectionSecurity.STARTTLS_REQUIRED -> ConnectionSecurity.StartTLS
                    MailConnectionSecurity.SSL_TLS_REQUIRED -> ConnectionSecurity.TLS
                },
            )
        }