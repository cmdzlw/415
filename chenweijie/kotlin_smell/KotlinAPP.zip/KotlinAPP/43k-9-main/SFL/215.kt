 for (security in connectionSecurities) {
            val port = security.toImapDefaultPort()

            assertThat(port).isEqualTo(
                when (security) {
                    ConnectionSecurity.None -> 143L
                    ConnectionSecurity.StartTLS -> 143L
                    ConnectionSecurity.TLS -> 993L
                },
            )
        }