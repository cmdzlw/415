for (algorithm in arrayOf("SHA-1", "SHA-256", "SHA-512")) {
                val digest = try {
                    MessageDigest.getInstance(algorithm)
                } catch (e: NoSuchAlgorithmException) {
                    Timber.e(e, "Error while initializing MessageDigest (%s)", algorithm)
                    null
                }

                if (digest != null) {
                    digest.reset()
                    try {
                        val hash = Hex.encodeHex(digest.digest(certificate.encoded))
                        append("Fingerprint (").append(algorithm).append("): \n").append(hash).append("\n")
                    } catch (e: CertificateEncodingException) {
                        Timber.e(e, "Error while encoding certificate")
                    }
                }
            }