 for (parameterSection in parameterSections) {
                if (parameterSection !is RegularValueParameterSection) throw AssertionError()
                append(parameterSection.text)
            }