for (field in fields) {
            when (field) {
                is RawField -> append(field.raw)
                is NameValueField -> appendNameValueField(field)
            }
            append(CRLF)
        }