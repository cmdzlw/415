for (parameterSection in parameterSections) {
                when (parameterSection) {
                    is ExtendedValueParameterSection -> buffer.writeAll(parameterSection.data)
                    is RegularValueParameterSection -> {
                        append(buffer.readString(charset))
                        append(parameterSection.text)
                    }
                }
            }