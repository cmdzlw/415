for ((index, address) in addresses.withIndex()) {
                val encodedAddress = address.toEncodedString()
                val encodedAddressLength = encodedAddress.length

                if (index > 0 && lineLength + 2 + encodedAddressLength + 1 > RECOMMENDED_MAX_LINE_LENGTH) {
                    append(",$CRLF ")
                    append(encodedAddress)
                    lineLength = encodedAddressLength + 1
                } else {
                    if (index > 0) {
                        append(", ")
                        lineLength += 2
                    }

                    append(encodedAddress)
                    lineLength += encodedAddressLength
                }
            }