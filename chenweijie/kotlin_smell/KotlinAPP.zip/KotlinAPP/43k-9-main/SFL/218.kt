for (domain in domainList) {
            if (hostname.lowercase().endsWith(domain)) {
                return true
            }
        }