for (index in 1 until ipComponentHexStrings.lastIndex) {
            if (ipComponentHexStrings[index] == "") {
                // If we already found an empty component return null.
                if (emptyIndex != -1) {
                    return null
                }

                emptyIndex = index
            }