for (thisMess in remoteMessageArray) {
                    headerProgress.incrementAndGet()
                    listener.syncHeadersProgress(folder, headerProgress.get(), messageCount)

                    val uid = thisMess.uid.toLong()
                    if (uid > highestKnownUid && uid > newHighestKnownUid) {
                        newHighestKnownUid = uid
                    }

                    val localMessageTimestamp = localUidMap!![thisMess.uid]
                    if (localMessageTimestamp == null || localMessageTimestamp >= earliestTimestamp) {
                        remoteMessages.add(thisMess)
                        remoteUidMap[thisMess.uid] = thisMess
                    }
                }