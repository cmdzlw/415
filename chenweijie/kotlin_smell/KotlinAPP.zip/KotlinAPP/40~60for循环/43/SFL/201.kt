for (flag in syncConfig.syncFlags) {
            val flagSetOnServer = flag in remoteFlags
            val flagSetLocally = flag in localFlags
            if (flagSetOnServer != flagSetLocally) {
                backendFolder.setMessageFlag(messageServerId, flag, flagSetOnServer)
            }
        }