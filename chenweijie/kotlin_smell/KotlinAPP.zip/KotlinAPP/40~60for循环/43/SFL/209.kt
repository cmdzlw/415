for ((hostnames, configuration) in configurationFactory.createConfigurations()) {
            for (hostname in hostnames) {
                put(hostname.lowercase(), configuration)
            }
        }
