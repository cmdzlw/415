for (character in input) {
                if (!character.isQtext) {
                    append(BACKSLASH)
                }
                append(character)
            }