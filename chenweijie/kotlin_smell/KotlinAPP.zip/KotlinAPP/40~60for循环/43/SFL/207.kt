for (i in 0..lastIndex) {
            val character = this[i]
            when {
                character == DOT -> if (this[i - 1] == DOT) return false
                character.isAtext -> Unit
                else -> return false
            }
        }