for (event in events) {
            assertThat(getNextEvent()).isEqualTo(event)
        }
