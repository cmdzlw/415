for (runnable in runnables) {
            when (val discoveryResult = runnable.run()) {
                is Settings -> {
                    return discoveryResult
                }
                is NetworkError -> {
                    networkErrorCount++
                    if (networkError == null) {
                        networkError = discoveryResult
                    }
                }
                NoUsableSettingsFound -> { }
                is UnexpectedException -> {
                    Timber.w(discoveryResult.exception, "Unexpected exception")
                }
            }