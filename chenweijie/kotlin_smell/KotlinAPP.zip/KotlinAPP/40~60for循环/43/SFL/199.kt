for (imapMessage in messages) {
            val uid = imapMessage.uid.toLong()

            val flags = messageFlags[uid].orEmpty().toSet()
            imapMessage.setFlags(flags, true)

            val storedMessage = this.messages[uid] ?: error("Message $uid not found")
            for (header in storedMessage.headers) {
                imapMessage.addHeader(header.name, header.value)
            }
            imapMessage.body = storedMessage.body

            listener?.onFetchResponse(imapMessage, isFirstResponse = true)
        }