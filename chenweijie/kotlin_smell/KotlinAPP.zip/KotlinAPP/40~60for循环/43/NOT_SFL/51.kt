folders.forEach { folder ->
                if (this@InMemoryBackendStorage.folders.containsKey(folder.serverId)) {
                    error("Folder ${folder.serverId} already present")
                }

                this@InMemoryBackendStorage.folders[folder.serverId] = InMemoryBackendFolder(folder.name, folder.type)
            }