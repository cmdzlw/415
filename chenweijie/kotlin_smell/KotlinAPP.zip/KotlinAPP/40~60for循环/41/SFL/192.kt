for (a in 0 until LoginData.size){
            val address = getData.getString("address_${a}","null").toString()
            val name = getData.getString("name_${a}","null").toString()
            val phone  = getData.getString("phone_${a}","null").toString()
            Log.d("address",address)
            initData(address,name,phone)
        }
