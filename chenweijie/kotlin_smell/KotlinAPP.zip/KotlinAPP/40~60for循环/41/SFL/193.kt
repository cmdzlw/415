for (activity: Activity in activities) {
                if (!activity.isFinishing) {
                    activity.finish()
                }
            }