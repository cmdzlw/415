 for (i in src.indices) {

            val v = 0xFF and src[i].toInt()
            val hv = Integer.toHexString(v)

            if (hv.length < 2) {
                builder.append(0)
            }
	builder.append(hv)
        }