dAccounts.forEach {
                    updateAccount(it)
                }