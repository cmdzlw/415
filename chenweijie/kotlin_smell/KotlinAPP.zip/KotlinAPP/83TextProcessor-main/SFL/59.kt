for (entry in this) {
            val freq = transform(entry)
            list.add(freq)
        }