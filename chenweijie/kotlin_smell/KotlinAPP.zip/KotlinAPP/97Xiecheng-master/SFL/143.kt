for (i in 5 downTo 1) {
                    withContext(Dispatchers.Main){
                        mBinding.timeTextView.text = i.toString()
                    }
                    delay(1000)
                }