for (i in 5 downTo 1) {
            println(i)
            delay(1000)
        }