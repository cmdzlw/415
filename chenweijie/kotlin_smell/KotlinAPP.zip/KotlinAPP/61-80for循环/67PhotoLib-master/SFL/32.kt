for (i in mSelected.indices) {
    handleImageBeforeKitKat(mSelected[i])
}