for (i in imagePathList.indices) {
    Log.e("-->", imagePathList[i])
    content+=imagePathList[i]
}