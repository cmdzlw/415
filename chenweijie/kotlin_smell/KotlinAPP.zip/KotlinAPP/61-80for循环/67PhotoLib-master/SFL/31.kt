for (i in mSelected.indices) {
    handleImageOnKitKat(mSelected[i])
}