for (s in urlList) {
                try {
                    val durl = restTemplate.postForObject<ResolveResult>("$BASE_URL/resolve", mapOf("url" to s)).durl
                    println("durl=>$durl")
                    resultChannel.send(durl)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            