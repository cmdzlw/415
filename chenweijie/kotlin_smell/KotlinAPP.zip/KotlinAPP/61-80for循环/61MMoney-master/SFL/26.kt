for (i in 0 until years) {
    sum += perMoney
    sum += sum * rate / 100
}