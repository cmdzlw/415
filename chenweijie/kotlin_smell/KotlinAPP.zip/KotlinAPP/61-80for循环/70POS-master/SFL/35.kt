for (i in 0 until constructorSize) {
    if (values[i] === ABSENT_VALUE && !constructor.parameters[i].isOptional) {
        if (!constructor.parameters[i].type.isMarkedNullable) {
            throw JsonDataException(
                    "Required value '${constructor.parameters[i].name}' missing at ${reader.path}")
        }
        values[i] = null // Replace absent with null.
    }
}