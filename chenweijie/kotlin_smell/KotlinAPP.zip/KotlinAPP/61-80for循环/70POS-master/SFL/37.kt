for (binding in bindings) {
    if (binding == null) continue // Skip constructor parameters that aren't properties.

    writer.name(binding.name)
    binding.adapter.toJson(writer, binding.get(value))
}