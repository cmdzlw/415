for (parameter in constructor.parameters) {
    val binding = bindingsByName.remove(parameter.name)
    if (binding == null && !parameter.isOptional) {
        throw IllegalArgumentException("No property for required constructor $parameter")
    }
    bindings += binding
}