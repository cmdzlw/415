for (property in rawTypeKotlin.memberProperties) {
    val parameter = parametersByName[property.name]

    if (Modifier.isTransient(property.javaField?.modifiers ?: 0)) {
        if (parameter != null && !parameter.isOptional) {
            throw IllegalArgumentException(
                    "No default value for transient constructor $parameter")
        }
        continue
    }

    if (parameter != null && parameter.type != property.returnType) {
        throw IllegalArgumentException("'${property.name}' has a constructor parameter of type " +
                "${parameter.type} but a property of type ${property.returnType}.")
    }

    if (property !is KMutableProperty1 && parameter == null) continue

    property.isAccessible = true
    var allAnnotations = property.annotations
    var jsonAnnotation = property.findAnnotation<Json>()

    if (parameter != null) {
        allAnnotations += parameter.annotations
        if (jsonAnnotation == null) {
            jsonAnnotation = parameter.findAnnotation<Json>()
        }
    }

    val name = jsonAnnotation?.name ?: property.name
    val resolvedPropertyType = resolve(type, rawType, property.returnType.javaType)
    val adapter = moshi.adapter<Any>(
            resolvedPropertyType, Util.jsonAnnotations(allAnnotations.toTypedArray()), property.name)

    bindingsByName[property.name] =
            MyKotlinJsonAdapter.Binding(
                    name, adapter,
                    property as KProperty1<Any, Any?>, parameter
            )
}