for (i in constructorSize until bindings.size) {
    val binding = bindings[i]!!
    val value = values[i]
    binding.set(result, value)
}