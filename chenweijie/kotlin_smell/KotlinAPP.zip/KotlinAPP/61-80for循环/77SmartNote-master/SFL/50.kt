for (i in fragments.indices.reversed()) {
    val child = fragments[i]
    if (isFragmentBackHandled(child)) {
        return true
    }
}