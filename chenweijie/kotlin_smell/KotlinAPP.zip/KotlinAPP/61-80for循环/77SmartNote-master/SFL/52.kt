for (trustManager in trustManagers) {
    if (trustManager is X509TrustManager) {
        return trustManager
    }
}