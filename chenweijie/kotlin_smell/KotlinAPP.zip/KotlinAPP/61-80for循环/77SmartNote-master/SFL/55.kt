for (i in 0 until itemCount) {
    val view = recycler?.getViewForPosition(i)
    if (view != null) {
        addView(view)
        measureChildWithMargins(view, 0, 0)
        val width = getDecoratedMeasuredWidth(view)
        val height = getDecoratedMeasuredHeight(view)
        layoutDecorated(view, currentPosition, parentTop, currentPosition + width, parentBottom)
        currentPosition += width
    }
}