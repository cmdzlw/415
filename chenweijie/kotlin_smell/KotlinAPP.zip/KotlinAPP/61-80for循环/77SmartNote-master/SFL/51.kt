for ((index, certificate) in certificates.withIndex()) {
    val certificateAlias = (index).toString()
    keyStore.setCertificateEntry(
            certificateAlias,
            certificateFactory.generateCertificate(certificate)
    )
    try {
        certificate?.close()
    } catch (e: IOException) {
        e.printStackTrace()
    }
}