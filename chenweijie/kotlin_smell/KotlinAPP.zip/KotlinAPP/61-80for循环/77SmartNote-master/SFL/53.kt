for (i in 0 until pagerCount) {
    var startCx = indicatorStartX(i)
    if (isNextFirst) startCx += distanceOffset
    val left = startCx - ratioIndicatorRadius
    val top = midY - indicatorRadius
    val right = startCx + ratioIndicatorRadius
    val bottom = midY + indicatorRadius
    if (selectedPage + 1 <= i) {
        rectF[left + distance, top, right + distance] = bottom
    } else {
        rectF[left, top, right] = bottom
    }
    canvas.drawRoundRect(rectF, indicatorRadius, indicatorRadius, indicatorPaint)
}