for (i in 0 until pagerCount) {
    val startCx = indicatorStartX(i)
    val ratioIndicatorRadius = ratioRadius
    val left = startCx - ratioIndicatorRadius
    val top = midY - indicatorRadius
    val right = startCx + ratioIndicatorRadius
    val bottom = midY + indicatorRadius
    rectF[left, top, right] = bottom
    canvas.drawRoundRect(rectF, indicatorRadius, indicatorRadius, indicatorPaint)
}