for (i in ViewModel.dataList) {
    item {
        DropdownMenuItem(
                onClick = {
                    ViewModel.addPanel.value = false
                    ViewModel.addToList(i)
                }
        ) {
            Text(i.toString())
        }
    }
}