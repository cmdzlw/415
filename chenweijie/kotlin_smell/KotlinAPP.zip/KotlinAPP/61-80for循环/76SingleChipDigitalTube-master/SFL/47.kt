for (i in '0' .. '9') {
    item {
        DropdownMenuItem(
                onClick = {
                    ViewModel.addPanel.value = false
                    ViewModel.addToList(i)
                }
        ) {
            Text(i.toString())
        }
    }
}