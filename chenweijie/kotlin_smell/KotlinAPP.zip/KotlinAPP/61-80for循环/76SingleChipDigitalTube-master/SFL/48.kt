for (i in ViewModel.dataList) ViewModel.addToList(i)
            