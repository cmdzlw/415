for (i in 0 until ViewModel.outList.size) {
    item {
        Row(
                modifier = Modifier.clickable {
                    ViewModel.light(ViewModel.outList[i])
                }.fillParentMaxWidth()
                        .padding(horizontal = 20.dp)
                        .height(44.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            val char = ViewModel.outList[i]
            Text(
                    text = if (char == ' ') "空" else char.toString(),
                    modifier = Modifier.weight(1f, true)
            )
            Image(
                    painter = painterResource("ic_up.png"),
                    contentDescription = "上移",
                    alpha = if (i > 0) 1f else 0.3f,
                    modifier = Modifier.size(22.dp).let {
                        if (i > 0) {
                            return@let it.clickable {
                                ViewModel.moveUp(i)
                            }
                        } else return@let it
                    }
            )
            Image(
                    painter = painterResource("ic_down.png"),
                    contentDescription = "下移",
                    alpha = if (i < ViewModel.outList.size - 1)
                        1f else 0.3f,
                    modifier = Modifier.size(22.dp).let {
                        if (i < ViewModel.outList.size - 1) {
                            return@let it.clickable {
                                ViewModel.moveDown(i)
                            }
                        } else return@let it
                    }
            )
            Image(
                    painter = painterResource("ic_delete.png"),
                    contentDescription = "删除",
                    modifier = Modifier.size(22.dp).clickable {
                        ViewModel.outList.removeAt(i)
                    }
            )
        }
    }
}