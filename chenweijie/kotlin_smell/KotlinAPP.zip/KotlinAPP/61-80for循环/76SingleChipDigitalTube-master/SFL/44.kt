for (i in 'a' .. 'h') {
    DropDownList(
            title = i.toString(),
            selected = ViewModel.segment[i]!!,
            request = { ViewModel.dropdown[i] = it },
            expanded = ViewModel.dropdown[i] == true,
            modifier = Modifier.width(24.dp)
    ) {
        ViewModel.setSegment(i, it)
    }
}