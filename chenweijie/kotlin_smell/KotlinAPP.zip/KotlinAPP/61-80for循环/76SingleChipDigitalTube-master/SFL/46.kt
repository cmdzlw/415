for (i in 0 .. 9) ViewModel.addToList('0' + i)
   