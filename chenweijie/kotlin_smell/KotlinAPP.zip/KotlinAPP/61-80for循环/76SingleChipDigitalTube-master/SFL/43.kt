for (i in outList) {
    out.append(builder.postBuild(i, common.value, segment))
}