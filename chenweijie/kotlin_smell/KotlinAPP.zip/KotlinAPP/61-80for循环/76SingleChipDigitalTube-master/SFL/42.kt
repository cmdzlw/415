for (i in 0 until 8) {
    lighting[i] = tmp and code == 0
    tmp = tmp shl 1
}