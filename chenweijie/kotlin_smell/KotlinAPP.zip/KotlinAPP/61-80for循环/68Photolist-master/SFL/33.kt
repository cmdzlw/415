for (i in 0..3) {
    mResult[i] = mStart[i] + (mEnd[i] - mStart[i]) * value
}