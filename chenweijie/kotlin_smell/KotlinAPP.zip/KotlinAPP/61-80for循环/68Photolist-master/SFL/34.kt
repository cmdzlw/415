for (i in 0..8) {
    mResult[i] = mStart[i] + (mEnd[i] - mStart[i]) * value
}