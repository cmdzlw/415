for (src in walkTopDown().onFail { f, e -> if (onError(f, e) == OnErrorAction.TERMINATE) throw FileSystemException(f) }) {
    if (!src.exists()) {
        if (onError(src, NoSuchFileException(file = src, reason = "The source file doesn't exist.")) ==
                OnErrorAction.TERMINATE)
            return false
    } else {
        val relPath = src.toRelativeString(this)
        val dstFile = File(target, relPath)
        if (dstFile.exists() && !(src.isDirectory && dstFile.isDirectory)) {
            val stillExists = if (!overwrite) true else {
                if (dstFile.isDirectory)
                    !dstFile.deleteRecursively()
                else
                    !dstFile.delete()
            }

            if (stillExists) {
                if (onError(dstFile, FileAlreadyExistsException(file = src,
                                other = dstFile,
                                reason = "The destination file already exists.")) == OnErrorAction.TERMINATE)
                    return false

                continue
            }
        }

        if (src.isDirectory) {
            dstFile.mkdirs()
        } else {
            // 这里改了
            if (copyAttributes) {
                Files.copy(src.toPath(), dstFile.toPath(), StandardCopyOption.COPY_ATTRIBUTES)
            } else {
                if (src.copyTo(dstFile, overwrite).length() != src.length()) {
                    if (onError(src, IOException("Source file wasn't copied completely, length of destination file differs.")) == OnErrorAction.TERMINATE){}
                    return false
                }
            }
        }
    }
}