items.forEach {
        logProgress(it)
        it.srcFileInfo!!.file.copyRecursively(it.destFileInfo.file, overwrite = true, copyAttributes = true)
    }