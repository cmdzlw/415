items.forEach {
        logProgress(it)
        it.srcFileInfo!!.file.copyRecursively(it.destFileInfo.file, overwrite = false, copyAttributes = true)
    }