 for (index in 0..childCount) {
        val child = getChildAt(index)
        if (child != null) {
            if (child is NavigationView) {
                mPopupViewWidth = child.measuredWidth
                try {
                    mNavigationView = getChildAt(index) as NavigationView
                } catch (e: java.lang.Exception) {
                    throw Exception("在{$TAG}布局文件中，中第二个直接子元素必须为：NavigationView！")
                }
                when ((mNavigationView!!.layoutParams as FrameLayout.LayoutParams).gravity) {
                    Gravity.START, Gravity.LEFT -> {
                        child.layout(-mPopupViewWidth, 0, 0, measuredHeight)
                        mContentInLeft = true
                    }
                    Gravity.END, Gravity.RIGHT -> {
                        child.layout(
                                measuredWidth,
                                0,
                                measuredWidth + mPopupViewWidth,
                                measuredHeight
                        )
                        mContentInLeft = false
                    }
                    else -> {
                        child.layout(-mPopupViewWidth, 0, 0, measuredHeight)
                        mContentInLeft = true
                    }
                }
                mNavigationView!!.setNavigationItemSelectedListener(listener)
            } else {
                child.layout(0, 0, measuredWidth, measuredHeight)
            }
        }
    }