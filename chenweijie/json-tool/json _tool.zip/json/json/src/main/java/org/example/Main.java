package org.example;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class Main extends JFrame {
    private JTextArea resultArea;
    private JButton selectFileButton;
    private JButton selectFolderButton;
    public Main() {
        super("Java����תJSON����");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        selectFileButton = new JButton("ѡ�񵥸�Java�ļ�");
        selectFileButton.addActionListener(e -> selectAndProcessFile());
        selectFolderButton = new JButton("ѡ���ļ���");
        selectFolderButton.addActionListener(e -> selectAndProcessFolder());
        buttonPanel.add(selectFileButton);
        buttonPanel.add(selectFolderButton);
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        setContentPane(panel);
    }

    /**
     * ѡ�񲢴�������Java�ļ�
     */
    private void selectAndProcessFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".java");
            }

            @Override
            public String getDescription() {
                return "Java�ļ� (*.java)";
            }
        });

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            processFile(file);
        }
    }

    /**
     * ѡ�񲢴��������ļ���
     */
    private void selectAndProcessFolder() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File folder = fileChooser.getSelectedFile();
            processFolder(folder);
        }
    }

    /**
     * ��������Java�ļ�
     * @param file Java�ļ�
     */
    private void processFile(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            JOptionPane.showMessageDialog(this, "��Ч���ļ�·��", "����", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String javaCode = readJavaFile(file.getAbsolutePath());
        if (javaCode == null) {
            JOptionPane.showMessageDialog(this, "Failed to read Java code from file: " + file.getName(), "����", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // ȥ�������е�ע��
        String cleanedCode = removeComments(javaCode);

        // ɸѡ������������75�еĲ���
        String screenedCode = screenCode(cleanedCode);

        // ����JSON����
        JSONObject json = new JSONObject();
        json.put("instruction", "������´����Ƿ����LIC������ζ");
        json.put("input", screenedCode);
        json.put("output", "������LIC������ζ��");
        json.put("feedback", 1);
        json.put("system", "����һ��������ζ������֣������Ǽ������Ƿ������ζ");
        json.put("history", new JSONArray());

        // �ڽ��������ʾJSON
        resultArea.append("JSON representation of Java code for file: " + file.getName() + "\n");
        resultArea.append(json.toString(4) + "\n\n");

        // ��JSON���浽�ļ�
        saveJsonToFile(json, file.getName().replace(".java", ".json"));
    }

    /**
     * ���������ļ����е�����Java�ļ�
     * @param folder �ļ���
     */
    private void processFolder(File folder) {
        if (folder == null || !folder.exists() || !folder.isDirectory()) {
            JOptionPane.showMessageDialog(this, "��Ч���ļ���·��", "����", JOptionPane.ERROR_MESSAGE);
            return;
        }

        File[] javaFiles = folder.listFiles((dir, name) -> name.endsWith(".java"));

        if (javaFiles == null || javaFiles.length == 0) {
            JOptionPane.showMessageDialog(this, "�ļ�����û���ҵ�Java�ļ�", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JSONArray jsonArray = new JSONArray();

        for (File javaFile : javaFiles) {
            String javaCode = readJavaFile(javaFile.getAbsolutePath());
            if (javaCode == null) {
                JOptionPane.showMessageDialog(this, "Failed to read Java code from file: " + javaFile.getName(), "����", JOptionPane.ERROR_MESSAGE);
                continue;
            }

            // ȥ�������е�ע��
            String cleanedCode = removeComments(javaCode);

            // ɸѡ������������75�еĲ���;

            // ����JSON����
            JSONObject json = new JSONObject();
            json.put("instruction", "Check whether the following code has the code smell of SFL(slow for loop)");
            json.put("input", cleanedCode);
            json.put("output", "SFL code smell is found.");

            jsonArray.put(json);
        }

        // ����ϲ����JSON�ļ�����ǰ·��
        File saveFile = new File("SFL.json");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(saveFile))) {
            writer.write(jsonArray.toString(4));
            resultArea.append("����Java�ļ���JSON��ʾ�ѱ��浽: " + saveFile.getAbsolutePath() + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "�����ļ�ʱ����: " + e.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * ���ļ��ж�ȡJava����
     * @param filePath �ļ�·��
     * @return Java�����ַ���
     */
    private String readJavaFile(String filePath) {
        try {
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            System.err.println("Error reading file: " + filePath + ". Error: " + e.getMessage());
            return null;
        }
    }

    /**
     * ȥ�������е�ע��
     * @param code ԭʼ����
     * @return ȥ��ע�ͺ�Ĵ���
     */
    private String removeComments(String code) {
        StringBuilder cleanedCode = new StringBuilder();
        boolean inBlockComment = false;
        boolean inLineComment = false;

        for (int i = 0; i < code.length(); i++) {
            if (inBlockComment) {
                if (i + 1 < code.length() && code.charAt(i) == '*' && code.charAt(i + 1) == '/') {
                    inBlockComment = false;
                    i++;
                }
            } else if (inLineComment) {
                if (code.charAt(i) == '\n') {
                    inLineComment = false;
                }
            } else {
                if (i + 1 < code.length() && code.charAt(i) == '/' && code.charAt(i + 1) == '*') {
                    inBlockComment = true;
                    i++;
                } else if (i + 1 < code.length() && code.charAt(i) == '/' && code.charAt(i + 1) == '/') {
                    inLineComment = true;
                    i++;
                } else {
                    cleanedCode.append(code.charAt(i));
                }
            }
        }

        return cleanedCode.toString();
    }

    /**
     * ɸѡ������������75�еĲ���
     * @param code ȥ��ע�ͺ�Ĵ���
     * @return ɸѡ��Ĵ���
     */
    private String screenCode(String code) {
        String[] lines = code.split("\n");
        StringBuilder screenedCode = new StringBuilder();
        int count = 0;

        for (String line : lines) {
            if (count >= 75) {
                break;
            }
            screenedCode.append(line).append("\n");
            count++;
        }

        return screenedCode.toString();
    }

    /**
     * ��JSON���浽�ļ�
     * @param json JSON����
     * @param fileName �ļ���
     */
    private void saveJsonToFile(JSONObject json, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(json.toString(4));
            resultArea.append("JSON�ѱ��浽�ļ�: " + fileName + "\n");
        } catch (IOException e) {
            System.err.println("Error saving JSON to file: " + fileName + ". Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        // ����UI����ʾ
        SwingUtilities.invokeLater(() -> {
            Main mainUI = new Main();
            mainUI.setVisible(true);
        });
    }
}