package org.example;

import org.json.JSONArray;
import org.json.JSONObject;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;

public class kotlinjson extends JFrame {
    private JTextArea resultArea;
    private JButton selectFileButton;
    private JButton selectFolderButton;

    public kotlinjson() {
        super("Kotlin代码转JSON工具");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        resultArea = new JTextArea();
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        selectFileButton = new JButton("选择单个Kotlin文件");
        selectFileButton.addActionListener(e -> selectAndProcessKotlinFile());
        selectFolderButton = new JButton("选择文件夹");
        selectFolderButton.addActionListener(e -> selectAndProcessFolder());
        buttonPanel.add(selectFileButton);
        buttonPanel.add(selectFolderButton);
        panel.add(buttonPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        setContentPane(panel);
    }

    private void selectAndProcessKotlinFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fileChooser.setAcceptAllFileFilterUsed(false);
        fileChooser.addChoosableFileFilter(new javax.swing.filechooser.FileFilter() {
            @Override
            public boolean accept(File f) {
                return f.isDirectory() || f.getName().toLowerCase().endsWith(".kt");
            }

            @Override
            public String getDescription() {
                return "Kotlin文件 (*.kt)";
            }
        });

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            processKotlinFile(file);
        }
    }

    private void selectAndProcessFolder() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            File folder = fileChooser.getSelectedFile();
            processFolder(folder);
        }
    }

    private void processKotlinFile(File file) {
        if (file == null || !file.exists() || !file.isFile()) {
            JOptionPane.showMessageDialog(this, "无效的文件路径", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String kotlinCode = readKotlinFile(file.getAbsolutePath());
        if (kotlinCode == null) {
            JOptionPane.showMessageDialog(this, "Failed to read Kotlin code from file: " + file.getName(), "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String cleanedCode = removeComments(kotlinCode);

        JSONObject json = new JSONObject();
        json.put("instruction", "检测以下Kotlin代码是否存在代码异味");
        json.put("input", cleanedCode);
        json.put("output", "不存在代码异味。");
        json.put("feedback", 1);
        json.put("system", "你是一个代码异味检测助手，任务是检测Kotlin代码是否存在异味");
        json.put("history", new JSONArray());

        resultArea.append("JSON representation of Kotlin code for file: " + file.getName() + "\n");
        resultArea.append(json.toString(4) + "\n\n");

        saveJsonToFile(json, file.getName().replace(".kt", ".json"));
    }

    private void processFolder(File folder) {
        if (folder == null || !folder.exists() || !folder.isDirectory()) {
            JOptionPane.showMessageDialog(this, "无效的文件夹路径", "错误", JOptionPane.ERROR_MESSAGE);
            return;
        }

        File[] kotlinFiles = folder.listFiles((dir, name) -> name.endsWith(".kt"));

        if (kotlinFiles == null || kotlinFiles.length == 0) {
            JOptionPane.showMessageDialog(this, "文件夹中没有找到Kotlin文件", "提示", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JSONArray jsonArray = new JSONArray();

        for (File kotlinFile : kotlinFiles) {
            String kotlinCode = readKotlinFile(kotlinFile.getAbsolutePath());
            if (kotlinCode == null) {
                JOptionPane.showMessageDialog(this, "Failed to read Kotlin code from file: " + kotlinFile.getName(), "错误", JOptionPane.ERROR_MESSAGE);
                continue;
            }

            String cleanedCode = removeComments(kotlinCode);

            JSONObject json = new JSONObject();
            json.put("instruction", "Check the following Kotlin code has the code smell of SFL(slow for loop)");
            json.put("input", cleanedCode);
            json.put("output", " SFL code smell is not found.");

            jsonArray.put(json);
        }

        File saveFile = new File("KotlinNOTSFL.json");

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(saveFile))) {
            writer.write(jsonArray.toString(4));
            resultArea.append("所有Kotlin文件的JSON表示已保存到: " + saveFile.getAbsolutePath() + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "保存文件时出错: " + e.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
        }
    }

    private String readKotlinFile(String filePath) {
        try {
            return new String(Files.readAllBytes(Paths.get(filePath)));
        } catch (IOException e) {
            System.err.println("Error reading file: " + filePath + ". Error: " + e.getMessage());
            return null;
        }
    }

    private String removeComments(String code) {
        StringBuilder cleanedCode = new StringBuilder();
        boolean inBlockComment = false;
        boolean inLineComment = false;

        for (int i = 0; i < code.length(); i++) {
            if (inBlockComment) {
                if (i + 1 < code.length() && code.charAt(i) == '*' && code.charAt(i + 1) == '/') {
                    inBlockComment = false;
                    i++;
                }
            } else if (inLineComment) {
                if (code.charAt(i) == '\n') {
                    inLineComment = false;
                }
            } else {
                if (i + 1 < code.length() && code.charAt(i) == '/' && code.charAt(i + 1) == '*') {
                    inBlockComment = true;
                    i++;
                } else if (i + 1 < code.length() && code.charAt(i) == '/' && code.charAt(i + 1) == '/') {
                    inLineComment = true;
                    i++;
                } else {
                    cleanedCode.append(code.charAt(i));
                }
            }
        }

        return cleanedCode.toString();
    }

    private void saveJsonToFile(JSONObject json, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write(json.toString(4));
            resultArea.append("JSON已保存到文件: " + fileName + "\n");
        } catch (IOException e) {
            System.err.println("Error saving JSON to file: " + fileName + ". Error: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            kotlinjson converter = new kotlinjson();
            converter.setVisible(true);
        });
    }
}
